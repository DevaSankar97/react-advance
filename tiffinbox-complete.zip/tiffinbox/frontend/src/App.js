import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './index.css';

import Login         from './components/auth/Login';
import Register      from './components/auth/Register';
import Dashboard     from './components/dashboard/Dashboard';
import Customers     from './components/customers/Customers';
import TodayDelivery from './components/delivery/TodayDelivery';
import Billing       from './components/billing/Billing';
import Settings      from './components/settings/Settings';
import Layout        from './components/Layout';

const PrivateRoute = ({ children }) => {
  const { owner, loading } = useAuth();
  if (loading) return (
    <div className="min-vh-100 d-flex flex-column align-items-center justify-content-center"
      style={{background:'#FFF8F0'}}>
      <div style={{fontSize:'3rem'}} className="mb-3">🍱</div>
      <div className="spinner-border text-primary mb-2"/>
      <p className="text-primary fw-semibold">Loading TiffinBox...</p>
    </div>
  );
  return owner ? children : <Navigate to="/login"/>;
};

const App = () => (
  <AuthProvider>
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{
        style:{background:'#333',color:'#fff'},
        success:{style:{background:'#22c55e',color:'#fff'}},
        error:  {style:{background:'#ef4444',color:'#fff'}}
      }}/>
      <Routes>
        <Route path="/login"    element={<Login/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/" element={<PrivateRoute><Layout/></PrivateRoute>}>
          <Route index              element={<Dashboard/>}/>
          <Route path="delivery"    element={<TodayDelivery/>}/>
          <Route path="customers"   element={<Customers/>}/>
          <Route path="billing"     element={<Billing/>}/>
          <Route path="settings"    element={<Settings/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  </AuthProvider>
);

export default App;

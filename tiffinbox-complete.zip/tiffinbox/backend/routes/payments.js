const express = require('express');
const Razorpay = require('razorpay');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.use(protect);

const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// @route   POST /api/payments/create-order
// @desc    Create Razorpay order for subscription
router.post('/create-order', async (req, res) => {
  try {
    const { plan } = req.body;
    const plans = {
      basic: { amount: 49900,  name: 'Basic Plan' },  // ₹499
      pro:   { amount: 99900,  name: 'Pro Plan' }      // ₹999
    };

    const selectedPlan = plans[plan] || plans.basic;

    const order = await razorpay.orders.create({
      amount:   selectedPlan.amount,
      currency: 'INR',
      receipt:  `receipt_${req.owner._id}_${Date.now()}`,
      notes: {
        ownerId:  req.owner._id.toString(),
        plan:     plan,
        ownerName: req.owner.name
      }
    });

    res.json({
      success: true,
      order,
      key: process.env.RAZORPAY_KEY_ID,
      owner: {
        name:  req.owner.name,
        phone: req.owner.phone,
        email: req.owner.email
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;

# 🍱 TiffinBox — Tiffin Service Management SaaS

> The simplest way for tiffin service owners to manage customers, deliveries, and billing.

## 🚀 Features
- 👥 Customer management (add, edit, pause, stop)
- 🛵 Daily delivery tracking (mark delivered/skipped/holiday)
- 💰 Auto monthly bill generation
- 💬 WhatsApp bill & reminder sending
- 📊 Revenue dashboard with 6-month trend
- 🔐 Secure JWT authentication

## 🛠️ Tech Stack
- **Frontend:** React.js + React Router + Recharts
- **Backend:**  Node.js + Express.js
- **Database:** MongoDB Atlas
- **WhatsApp:** Twilio WhatsApp API
- **Payments:** Razorpay
- **Deploy:**   Docker + Railway/Render

## ⚡ Quick Start

### 1. Clone & Install
```bash
# Backend
cd backend
npm install
cp .env.example .env
# Fill in your .env values

# Frontend
cd ../frontend
npm install
```

### 2. Setup MongoDB Atlas (Free)
1. Go to mongodb.com/atlas → Create free account
2. Create cluster → Get connection string
3. Paste in backend/.env as MONGODB_URI

### 3. Setup Twilio WhatsApp (Free sandbox)
1. Go to twilio.com → Create account
2. Go to Messaging → Try WhatsApp
3. Get Account SID, Auth Token, WhatsApp number
4. Paste in backend/.env

### 4. Run Locally
```bash
# Terminal 1 — Backend
cd backend && npm run dev

# Terminal 2 — Frontend
cd frontend && npm start
```

### 5. Deploy with Docker
```bash
docker-compose up -d
```

### 6. Deploy to Railway (Free tier)
1. Push to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add environment variables
4. Deploy! ✅

## 💰 Pricing Plans
| Plan  | Price     | Customers |
|-------|-----------|-----------|
| Free  | ₹0/month  | 10        |
| Basic | ₹499/month| 100       |
| Pro   | ₹999/month| Unlimited |

## 📱 WhatsApp Bill Format
```
🍱 Kavitha Tiffin Service

Hello Rajesh! 😊

📅 Bill for May 2026
━━━━━━━━━━━━━━
🗓 Delivered Days: 24 days
💰 Rate: ₹58/day
💵 Total Amount: ₹1,392
📌 Payment Pending
━━━━━━━━━━━━━━

Please pay via UPI / Cash
Thank you! 🙏
```

## 🗂️ Project Structure
```
tiffinbox/
├── backend/
│   ├── models/       (Owner, Customer, Delivery, Billing)
│   ├── routes/       (auth, customers, delivery, billing, whatsapp)
│   ├── middleware/   (auth.js)
│   ├── server.js
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── auth/      (Login, Register)
│   │   │   ├── dashboard/ (Dashboard)
│   │   │   ├── customers/ (Customers)
│   │   │   ├── delivery/  (TodayDelivery)
│   │   │   └── billing/   (Billing)
│   │   ├── context/       (AuthContext)
│   │   └── App.js
│   └── package.json
└── docker-compose.yml
```

const express = require('express');
const Razorpay = require('razorpay');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.use(protect);

// Lazy init — only when keys are available
const getRazorpay = () => {
  if (!process.env.RAZORPAY_KEY_ID || process.env.RAZORPAY_KEY_ID === 'rzp_test_xxxxxxxxxx') {
    return null;
  }
  return new Razorpay({
    key_id:     process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET
  });
};

// @route   POST /api/payments/create-order
// @desc    Create Razorpay order for subscription
router.post('/create-order', async (req, res) => {
  try {
    const razorpay = getRazorpay();
    if (!razorpay) {
      return res.status(503).json({ success: false, message: 'Payment gateway not configured yet. Add RAZORPAY_KEY_ID to .env' });
    }
    const { plan } = req.body;
    const plans = {
      basic: { amount: 49900,  name: 'Basic Plan' },
      pro:   { amount: 99900,  name: 'Pro Plan' }
    };
    const selectedPlan = plans[plan] || plans.basic;
    const order = await razorpay.orders.create({
      amount:   selectedPlan.amount,
      currency: 'INR',
      receipt:  `receipt_${req.owner._id}_${Date.now()}`,
      notes: { ownerId: req.owner._id.toString(), plan, ownerName: req.owner.name }
    });
    res.json({
      success: true, order,
      key: process.env.RAZORPAY_KEY_ID,
      owner: { name: req.owner.name, phone: req.owner.phone, email: req.owner.email }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;

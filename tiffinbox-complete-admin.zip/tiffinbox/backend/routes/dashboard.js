const express = require('express');
const Customer = require('../models/Customer');
const Delivery = require('../models/Delivery');
const Billing  = require('../models/Billing');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.use(protect);

// @route   GET /api/dashboard
// @desc    Get dashboard stats
router.get('/', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const month = today.getMonth() + 1;
    const year  = today.getFullYear();

    // Customer stats
    const totalCustomers  = await Customer.countDocuments({ owner: req.owner._id });
    const activeCustomers = await Customer.countDocuments({ owner: req.owner._id, status: 'active' });

    // Today's delivery stats
    const todayDeliveries = await Delivery.find({
      owner: req.owner._id,
      date: { $gte: today, $lt: tomorrow }
    });
    const deliveredToday = todayDeliveries.filter(d => d.status === 'delivered').length;
    const pendingToday   = activeCustomers - deliveredToday;

    // Monthly billing stats
    const monthBills = await Billing.find({
      owner: req.owner._id,
      month, year
    });
    const totalRevenue  = monthBills.reduce((s, b) => s + b.finalAmount, 0);
    const collectedAmt  = monthBills.reduce((s, b) => s + b.paidAmount, 0);
    const pendingAmt    = totalRevenue - collectedAmt;
    const paidCount     = monthBills.filter(b => b.paymentStatus === 'paid').length;
    const unpaidCount   = monthBills.filter(b => b.paymentStatus !== 'paid').length;

    // Monthly revenue trend (last 6 months)
    const trend = [];
    for (let i = 5; i >= 0; i--) {
      const d  = new Date(year, month - 1 - i, 1);
      const m  = d.getMonth() + 1;
      const y  = d.getFullYear();
      const bills = await Billing.find({ owner: req.owner._id, month: m, year: y });
      trend.push({
        month: d.toLocaleDateString('en-IN', { month: 'short' }),
        revenue:   bills.reduce((s, b) => s + b.finalAmount, 0),
        collected: bills.reduce((s, b) => s + b.paidAmount, 0)
      });
    }

    res.json({
      success: true,
      dashboard: {
        customers: { total: totalCustomers, active: activeCustomers },
        today: {
          total: activeCustomers,
          delivered: deliveredToday,
          pending: pendingToday > 0 ? pendingToday : 0
        },
        billing: {
          totalRevenue, collectedAmt, pendingAmt,
          paidCount, unpaidCount
        },
        trend
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;

const express = require('express');
const Billing = require('../models/Billing');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.use(protect);

// Send WhatsApp message via Twilio
const sendWhatsApp = async (to, message) => {
  const client = require('twilio')(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );

  return await client.messages.create({
    from: process.env.TWILIO_WHATSAPP_FROM,
    to: `whatsapp:+91${to}`,
    body: message
  });
};

// @route   POST /api/whatsapp/send-bill/:billId
// @desc    Send bill via WhatsApp to customer
router.post('/send-bill/:billId', async (req, res) => {
  try {
    const bill = await Billing.findOne({
      _id: req.params.billId,
      owner: req.owner._id
    }).populate('customer', 'name phone');

    if (!bill) {
      return res.status(404).json({ success: false, message: 'Bill not found' });
    }

    const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const monthName  = monthNames[bill.month - 1];

    const message = `🍱 *${req.owner.businessName}*

Hello ${bill.customer.name}! 😊

📅 *Bill for ${monthName} ${bill.year}*
━━━━━━━━━━━━━━
🗓 Delivered Days: *${bill.deliveredDays} days*
💰 Rate: *₹${bill.pricePerDay}/day*
💵 Total Amount: *₹${bill.finalAmount}*
${bill.paidAmount > 0 ? `✅ Paid: ₹${bill.paidAmount}\n📌 Balance: ₹${bill.finalAmount - bill.paidAmount}` : '📌 Payment Pending'}
━━━━━━━━━━━━━━

Please pay via:
💳 UPI / Cash / Bank Transfer

Thank you for your continued support! 🙏
${req.owner.businessName}`;

    await sendWhatsApp(bill.customer.phone, message);

    // Mark as sent
    bill.whatsappSent = true;
    await bill.save();

    res.json({
      success: true,
      message: `Bill sent to ${bill.customer.name} on WhatsApp ✅`
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/whatsapp/send-reminder
// @desc    Send payment reminder to unpaid customers
router.post('/send-reminder', async (req, res) => {
  try {
    const { month, year } = req.body;
    const m = parseInt(month) || new Date().getMonth() + 1;
    const y = parseInt(year)  || new Date().getFullYear();

    const unpaidBills = await Billing.find({
      owner: req.owner._id,
      month: m, year: y,
      paymentStatus: { $in: ['unpaid', 'partial'] }
    }).populate('customer', 'name phone');

    let sent = 0;
    for (const bill of unpaidBills) {
      const balance = bill.finalAmount - bill.paidAmount;
      const message = `🍱 *${req.owner.businessName}*

Hello ${bill.customer.name}! 😊

This is a friendly reminder that your tiffin payment of *₹${balance}* is pending.

Please clear at your earliest convenience.

Thank you! 🙏`;

      try {
        await sendWhatsApp(bill.customer.phone, message);
        sent++;
      } catch (err) {
        console.error(`Failed to send to ${bill.customer.phone}:`, err.message);
      }
    }

    res.json({
      success: true,
      message: `Reminders sent to ${sent}/${unpaidBills.length} customers ✅`
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;

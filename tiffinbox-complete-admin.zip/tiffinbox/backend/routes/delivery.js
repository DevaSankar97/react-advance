const express = require('express');
const Delivery = require('../models/Delivery');
const Customer = require('../models/Customer');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.use(protect);

// @route   GET /api/delivery/today
// @desc    Get today's delivery list
router.get('/today', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Get all active customers
    const customers = await Customer.find({
      owner: req.owner._id,
      status: 'active'
    });

    // Get today's deliveries
    const deliveries = await Delivery.find({
      owner: req.owner._id,
      date: { $gte: today, $lt: tomorrow }
    }).populate('customer', 'name phone address plan');

    // Build response — merge customers with delivery status
    const deliveryList = customers.map(customer => {
      const delivery = deliveries.find(
        d => d.customer._id.toString() === customer._id.toString()
      );
      return {
        customer: {
          _id: customer._id,
          name: customer.name,
          phone: customer.phone,
          area: customer.address?.area,
          mealType: customer.plan.type,
          meals: customer.plan.meals
        },
        delivery: delivery || null,
        status: delivery?.status || 'pending'
      };
    });

    const summary = {
      total: deliveryList.length,
      delivered: deliveryList.filter(d => d.status === 'delivered').length,
      pending: deliveryList.filter(d => d.status === 'pending').length,
      skipped: deliveryList.filter(d => d.status === 'skipped').length
    };

    res.json({ success: true, date: today, summary, deliveryList });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/delivery/mark
// @desc    Mark delivery status for a customer
router.post('/mark', async (req, res) => {
  try {
    const { customerId, date, meal, status, notes } = req.body;

    const deliveryDate = new Date(date || Date.now());
    deliveryDate.setHours(0, 0, 0, 0);

    const delivery = await Delivery.findOneAndUpdate(
      {
        owner: req.owner._id,
        customer: customerId,
        date: deliveryDate,
        meal: meal || 'lunch'
      },
      { status, notes },
      { upsert: true, new: true }
    ).populate('customer', 'name phone');

    res.json({
      success: true,
      message: `Marked as ${status} for ${delivery.customer.name}`,
      delivery
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/delivery/mark-all
// @desc    Mark all pending as delivered
router.post('/mark-all', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const customers = await Customer.find({
      owner: req.owner._id,
      status: 'active'
    });

    const updates = customers.map(customer =>
      Delivery.findOneAndUpdate(
        { owner: req.owner._id, customer: customer._id, date: today, meal: 'lunch' },
        { status: 'delivered' },
        { upsert: true, new: true }
      )
    );

    await Promise.all(updates);

    res.json({
      success: true,
      message: `All ${customers.length} deliveries marked as delivered! ✅`
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/delivery/month
// @desc    Get delivery report for a month
router.get('/month', async (req, res) => {
  try {
    const { month, year, customerId } = req.query;
    const m = parseInt(month) || new Date().getMonth() + 1;
    const y = parseInt(year)  || new Date().getFullYear();

    const startDate = new Date(y, m - 1, 1);
    const endDate   = new Date(y, m, 1);

    let query = {
      owner: req.owner._id,
      date: { $gte: startDate, $lt: endDate }
    };
    if (customerId) query.customer = customerId;

    const deliveries = await Delivery.find(query)
      .populate('customer', 'name phone plan');

    res.json({ success: true, month: m, year: y, deliveries });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;

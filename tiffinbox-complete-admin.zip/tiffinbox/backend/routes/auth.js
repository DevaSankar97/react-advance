const express = require('express');
const jwt = require('jsonwebtoken');
const Owner = require('../models/Owner');
const { protect } = require('../middleware/auth');
const router = express.Router();

// Generate JWT token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE });
};

// @route   POST /api/auth/register
// @desc    Register new tiffin owner
router.post('/register', async (req, res) => {
  try {
    const { name, phone, email, businessName, password, city } = req.body;

    // Check if owner exists
    const existing = await Owner.findOne({ phone });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Phone number already registered' });
    }

    const owner = await Owner.create({
      name, phone, email, businessName, password,
      address: { city: city || 'Chennai', state: 'Tamil Nadu' }
    });

    const token = generateToken(owner._id);

    res.status(201).json({
      success: true,
      message: 'Registration successful! 30-day free trial started.',
      token,
      owner: {
        id: owner._id,
        name: owner.name,
        businessName: owner.businessName,
        phone: owner.phone,
        plan: owner.plan,
        planExpiry: owner.planExpiry
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/auth/login
// @desc    Login owner
router.post('/login', async (req, res) => {
  try {
    const { phone, password } = req.body;

    if (!phone || !password) {
      return res.status(400).json({ success: false, message: 'Phone and password required' });
    }

    const owner = await Owner.findOne({ phone }).select('+password');
    if (!owner) {
      return res.status(401).json({ success: false, message: 'Invalid phone or password' });
    }

    const isMatch = await owner.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid phone or password' });
    }

    const token = generateToken(owner._id);

    res.json({
      success: true,
      message: `Welcome back, ${owner.name}! 🍱`,
      token,
      owner: {
        id: owner._id,
        name: owner.name,
        businessName: owner.businessName,
        phone: owner.phone,
        plan: owner.plan,
        planExpiry: owner.planExpiry
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/auth/me
// @desc    Get current owner
router.get('/me', protect, async (req, res) => {
  res.json({ success: true, owner: req.owner });
});

module.exports = router;

const express = require('express');
const Billing = require('../models/Billing');
const Customer = require('../models/Customer');
const Delivery = require('../models/Delivery');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.use(protect);

// @route   POST /api/billing/generate
// @desc    Auto-generate bills for all customers for a month
router.post('/generate', async (req, res) => {
  try {
    const { month, year } = req.body;
    const m = parseInt(month) || new Date().getMonth() + 1;
    const y = parseInt(year)  || new Date().getFullYear();

    const startDate = new Date(y, m - 1, 1);
    const endDate   = new Date(y, m, 1);

    // Get all active customers
    const customers = await Customer.find({
      owner: req.owner._id,
      status: { $in: ['active', 'paused'] }
    });

    const bills = [];

    for (const customer of customers) {
      // Get deliveries for this customer this month
      const deliveries = await Delivery.find({
        owner: req.owner._id,
        customer: customer._id,
        date: { $gte: startDate, $lt: endDate }
      });

      const deliveredDays = deliveries.filter(d => d.status === 'delivered').length;
      const skippedDays   = deliveries.filter(d => d.status === 'skipped').length;
      const totalDays     = deliveredDays;
      const pricePerDay   = customer.plan.pricePerDay || Math.round(customer.plan.pricePerMonth / 26);
      const totalAmount   = deliveredDays * pricePerDay;

      // Upsert bill
      const bill = await Billing.findOneAndUpdate(
        { owner: req.owner._id, customer: customer._id, month: m, year: y },
        {
          totalDays,
          deliveredDays,
          skippedDays,
          pricePerDay,
          totalAmount,
          finalAmount: totalAmount,
          owner: req.owner._id
        },
        { upsert: true, new: true }
      );

      bills.push({ customer: customer.name, bill });
    }

    res.json({
      success: true,
      message: `Bills generated for ${bills.length} customers for ${m}/${y} ✅`,
      bills
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/billing
// @desc    Get all bills - with filters
router.get('/', async (req, res) => {
  try {
    const { month, year, status } = req.query;
    const m = parseInt(month) || new Date().getMonth() + 1;
    const y = parseInt(year)  || new Date().getFullYear();

    let query = { owner: req.owner._id, month: m, year: y };
    if (status) query.paymentStatus = status;

    const bills = await Billing.find(query)
      .populate('customer', 'name phone address plan')
      .sort({ paymentStatus: 1, 'customer.name': 1 });

    const summary = {
      total:        bills.length,
      totalAmount:  bills.reduce((s, b) => s + b.finalAmount, 0),
      paidAmount:   bills.reduce((s, b) => s + b.paidAmount, 0),
      unpaidAmount: bills.filter(b => b.paymentStatus !== 'paid').reduce((s, b) => s + (b.finalAmount - b.paidAmount), 0),
      paid:         bills.filter(b => b.paymentStatus === 'paid').length,
      unpaid:       bills.filter(b => b.paymentStatus === 'unpaid').length,
      partial:      bills.filter(b => b.paymentStatus === 'partial').length
    };

    res.json({ success: true, month: m, year: y, summary, bills });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   PUT /api/billing/:id/payment
// @desc    Mark payment for a bill
router.put('/:id/payment', async (req, res) => {
  try {
    const { paidAmount, paymentMode, notes } = req.body;

    const bill = await Billing.findOne({
      _id: req.params.id,
      owner: req.owner._id
    }).populate('customer', 'name phone');

    if (!bill) {
      return res.status(404).json({ success: false, message: 'Bill not found' });
    }

    bill.paidAmount   = paidAmount;
    bill.paymentMode  = paymentMode || 'cash';
    bill.notes        = notes;
    bill.paidDate     = new Date();

    if (paidAmount >= bill.finalAmount) {
      bill.paymentStatus = 'paid';
    } else if (paidAmount > 0) {
      bill.paymentStatus = 'partial';
    }

    await bill.save();

    res.json({
      success: true,
      message: `Payment of ₹${paidAmount} recorded for ${bill.customer.name} ✅`,
      bill
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/billing/customer/:customerId
// @desc    Get billing history for a customer
router.get('/customer/:customerId', async (req, res) => {
  try {
    const bills = await Billing.find({
      owner: req.owner._id,
      customer: req.params.customerId
    }).sort({ year: -1, month: -1 });

    res.json({ success: true, bills });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;

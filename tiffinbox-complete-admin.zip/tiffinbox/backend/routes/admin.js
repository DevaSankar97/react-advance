const express = require('express');
const jwt     = require('jsonwebtoken');
const Admin   = require('../models/Admin');
const Owner   = require('../models/Owner');
const Customer= require('../models/Customer');
const Billing = require('../models/Billing');
const Delivery= require('../models/Delivery');
const { adminProtect } = require('../middleware/adminAuth');
const router  = express.Router();

const genAdminToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET + '_admin', { expiresIn: '7d' });

// ─────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────

// @route POST /api/admin/setup
// @desc  Create first super admin (run once)
router.post('/setup', async (req, res) => {
  try {
    const exists = await Admin.countDocuments();
    if (exists > 0) return res.status(400).json({ success: false, message: 'Admin already exists. Use login.' });
    const { name, email, password } = req.body;
    const admin = await Admin.create({ name, email, password });
    const token = genAdminToken(admin._id);
    res.status(201).json({ success: true, message: 'Super admin created!', token, admin: { name: admin.name, email: admin.email } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route POST /api/admin/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email }).select('+password');
    if (!admin || !(await admin.comparePassword(password))) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    const token = genAdminToken(admin._id);
    res.json({ success: true, token, admin: { id: admin._id, name: admin.name, email: admin.email } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route GET /api/admin/me
router.get('/me', adminProtect, (req, res) => {
  res.json({ success: true, admin: req.admin });
});

// ─────────────────────────────────────────
// DASHBOARD STATS
// ─────────────────────────────────────────

// @route GET /api/admin/dashboard
router.get('/dashboard', adminProtect, async (req, res) => {
  try {
    const now   = new Date();
    const month = now.getMonth() + 1;
    const year  = now.getFullYear();

    // Start of today, this week, this month
    const startOfDay   = new Date(now); startOfDay.setHours(0,0,0,0);
    const startOfMonth = new Date(year, month-1, 1);
    const startOfWeek  = new Date(now); startOfWeek.setDate(now.getDate() - now.getDay());

    // Core counts
    const totalOwners    = await Owner.countDocuments();
    const activeOwners   = await Owner.countDocuments({ isActive: true });
    const newToday       = await Owner.countDocuments({ createdAt: { $gte: startOfDay } });
    const newThisWeek    = await Owner.countDocuments({ createdAt: { $gte: startOfWeek } });
    const newThisMonth   = await Owner.countDocuments({ createdAt: { $gte: startOfMonth } });
    const totalCustomers = await Customer.countDocuments();
    const totalBills     = await Billing.countDocuments({ month, year });

    // Revenue this month (collected from tiffin owners' customers — proxy for platform usage)
    const bills = await Billing.find({ month, year });
    const totalBilledAmt   = bills.reduce((s,b) => s + (b.finalAmount||0), 0);
    const totalCollectedAmt= bills.reduce((s,b) => s + (b.paidAmount||0), 0);

    // Plan breakdown
    const freePlan  = await Owner.countDocuments({ plan: 'free' });
    const basicPlan = await Owner.countDocuments({ plan: 'basic' });
    const proPlan   = await Owner.countDocuments({ plan: 'pro' });

    // Your platform MRR (paid plans)
    const platformMRR = (basicPlan * 499) + (proPlan * 999);

    // Growth trend — signups per month (last 6 months)
    const trend = [];
    for (let i = 5; i >= 0; i--) {
      const d  = new Date(year, month-1-i, 1);
      const m  = d.getMonth() + 1;
      const y  = d.getFullYear();
      const start = new Date(y, m-1, 1);
      const end   = new Date(y, m, 1);
      const count = await Owner.countDocuments({ createdAt: { $gte: start, $lt: end } });
      trend.push({ month: d.toLocaleDateString('en-IN',{month:'short'}), signups: count });
    }

    res.json({
      success: true,
      stats: {
        owners: { total: totalOwners, active: activeOwners, newToday, newThisWeek, newThisMonth },
        customers: { total: totalCustomers },
        billing: { totalBills, totalBilledAmt, totalCollectedAmt },
        plans: { free: freePlan, basic: basicPlan, pro: proPlan },
        platformMRR,
        trend
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─────────────────────────────────────────
// OWNERS MANAGEMENT
// ─────────────────────────────────────────

// @route GET /api/admin/owners
router.get('/owners', adminProtect, async (req, res) => {
  try {
    const { search, plan, status, page=1, limit=20 } = req.query;
    let query = {};
    if (search) query.$or = [
      { name:         { $regex: search, $options:'i' } },
      { phone:        { $regex: search, $options:'i' } },
      { businessName: { $regex: search, $options:'i' } }
    ];
    if (plan)   query.plan = plan;
    if (status === 'active')   query.isActive = true;
    if (status === 'inactive') query.isActive = false;

    const total  = await Owner.countDocuments(query);
    const owners = await Owner.find(query)
      .sort({ createdAt: -1 })
      .skip((page-1)*limit)
      .limit(parseInt(limit));

    // Enrich with customer count
    const enriched = await Promise.all(owners.map(async o => {
      const customerCount = await Customer.countDocuments({ owner: o._id });
      return { ...o.toObject(), customerCount };
    }));

    res.json({ success: true, total, page: parseInt(page), owners: enriched });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route GET /api/admin/owners/:id
router.get('/owners/:id', adminProtect, async (req, res) => {
  try {
    const owner     = await Owner.findById(req.params.id);
    if (!owner) return res.status(404).json({ success: false, message: 'Owner not found' });

    const customers = await Customer.find({ owner: owner._id });
    const bills     = await Billing.find({ owner: owner._id }).sort({ year:-1, month:-1 }).limit(6);
    const totalRevenue = bills.reduce((s,b) => s + (b.finalAmount||0), 0);

    res.json({ success: true, owner, customers, bills, totalRevenue });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route PUT /api/admin/owners/:id/plan
// @desc  Upgrade/downgrade owner plan
router.put('/owners/:id/plan', adminProtect, async (req, res) => {
  try {
    const { plan, planExpiry } = req.body;
    const owner = await Owner.findByIdAndUpdate(
      req.params.id,
      { plan, planExpiry: planExpiry || new Date(Date.now() + 30*24*60*60*1000) },
      { new: true }
    );
    if (!owner) return res.status(404).json({ success: false, message: 'Owner not found' });
    res.json({ success: true, message: `Plan updated to ${plan} for ${owner.name}`, owner });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route PUT /api/admin/owners/:id/toggle
// @desc  Block/unblock owner
router.put('/owners/:id/toggle', adminProtect, async (req, res) => {
  try {
    const owner = await Owner.findById(req.params.id);
    if (!owner) return res.status(404).json({ success: false, message: 'Owner not found' });
    owner.isActive = !owner.isActive;
    await owner.save();
    res.json({
      success: true,
      message: `${owner.name} has been ${owner.isActive ? 'activated' : 'blocked'}`,
      isActive: owner.isActive
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route DELETE /api/admin/owners/:id
router.delete('/owners/:id', adminProtect, async (req, res) => {
  try {
    await Owner.findByIdAndDelete(req.params.id);
    await Customer.deleteMany({ owner: req.params.id });
    await Billing.deleteMany({ owner: req.params.id });
    await Delivery.deleteMany({ owner: req.params.id });
    res.json({ success: true, message: 'Owner and all data deleted permanently.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─────────────────────────────────────────
// REVENUE & ANALYTICS
// ─────────────────────────────────────────

// @route GET /api/admin/revenue
router.get('/revenue', adminProtect, async (req, res) => {
  try {
    const now   = new Date();
    const month = now.getMonth() + 1;
    const year  = now.getFullYear();

    // Monthly revenue trend
    const revenueTrend = [];
    for (let i = 11; i >= 0; i--) {
      const d = new Date(year, month-1-i, 1);
      const m = d.getMonth() + 1;
      const y = d.getFullYear();
      const basic = await Owner.countDocuments({ plan:'basic', createdAt:{ $lte: new Date(y,m,1) } });
      const pro   = await Owner.countDocuments({ plan:'pro',   createdAt:{ $lte: new Date(y,m,1) } });
      const mrr   = (basic*499) + (pro*999);
      revenueTrend.push({
        month: d.toLocaleDateString('en-IN',{month:'short',year:'2-digit'}),
        mrr, basic, pro
      });
    }

    // Top owners by customer count
    const allOwners = await Owner.find();
    const ownerStats = await Promise.all(allOwners.map(async o => ({
      name: o.name, businessName: o.businessName, plan: o.plan,
      customers: await Customer.countDocuments({ owner: o._id, status:'active' })
    })));
    const topOwners = ownerStats.sort((a,b) => b.customers-a.customers).slice(0,10);

    res.json({ success: true, revenueTrend, topOwners });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;

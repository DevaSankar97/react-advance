const express = require('express');
const Customer = require('../models/Customer');
const { protect } = require('../middleware/auth');
const router = express.Router();

// All routes protected
router.use(protect);

// @route   GET /api/customers
// @desc    Get all customers for owner
router.get('/', async (req, res) => {
  try {
    const { status, search } = req.query;
    let query = { owner: req.owner._id };

    if (status) query.status = status;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } }
      ];
    }

    const customers = await Customer.find(query).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: customers.length,
      customers
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/customers
// @desc    Add new customer
router.post('/', async (req, res) => {
  try {
    const customer = await Customer.create({
      ...req.body,
      owner: req.owner._id
    });

    res.status(201).json({
      success: true,
      message: `${customer.name} added successfully! 🎉`,
      customer
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/customers/:id
// @desc    Get single customer
router.get('/:id', async (req, res) => {
  try {
    const customer = await Customer.findOne({
      _id: req.params.id,
      owner: req.owner._id
    });

    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    res.json({ success: true, customer });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   PUT /api/customers/:id
// @desc    Update customer
router.put('/:id', async (req, res) => {
  try {
    const customer = await Customer.findOneAndUpdate(
      { _id: req.params.id, owner: req.owner._id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    res.json({ success: true, message: 'Customer updated!', customer });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   DELETE /api/customers/:id
// @desc    Delete customer (soft delete)
router.delete('/:id', async (req, res) => {
  try {
    const customer = await Customer.findOneAndUpdate(
      { _id: req.params.id, owner: req.owner._id },
      { status: 'stopped' },
      { new: true }
    );

    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    res.json({ success: true, message: 'Customer stopped.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/customers/stats/summary
// @desc    Get customer stats
router.get('/stats/summary', async (req, res) => {
  try {
    const total    = await Customer.countDocuments({ owner: req.owner._id });
    const active   = await Customer.countDocuments({ owner: req.owner._id, status: 'active' });
    const paused   = await Customer.countDocuments({ owner: req.owner._id, status: 'paused' });
    const stopped  = await Customer.countDocuments({ owner: req.owner._id, status: 'stopped' });

    // Monthly revenue potential
    const activeCustomers = await Customer.find({ owner: req.owner._id, status: 'active' });
    const monthlyRevenue = activeCustomers.reduce((sum, c) => sum + (c.plan.pricePerMonth || 0), 0);

    res.json({
      success: true,
      stats: { total, active, paused, stopped, monthlyRevenue }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;

const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Owner',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Customer name is required'],
    trim: true
  },
  phone: {
    type: String,
    required: [true, 'Phone number is required'],
    match: [/^[6-9]\d{9}$/, 'Enter valid Indian mobile number']
  },
  address: {
    street: String,
    area: String,
    city: { type: String, default: 'Chennai' }
  },
  plan: {
    type: {
      type: String,
      enum: ['veg', 'non-veg', 'both'],
      default: 'veg'
    },
    meals: {
      type: String,
      enum: ['lunch', 'dinner', 'both'],
      default: 'lunch'
    },
    pricePerMonth: {
      type: Number,
      required: true
    },
    pricePerDay: {
      type: Number
    }
  },
  startDate: {
    type: Date,
    required: true,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['active', 'paused', 'stopped'],
    default: 'active'
  },
  notes: String,
  createdAt: { type: Date, default: Date.now }
});

// Auto calculate price per day
customerSchema.pre('save', function(next) {
  if (this.plan.pricePerMonth) {
    this.plan.pricePerDay = Math.round(this.plan.pricePerMonth / 26);
  }
  next();
});

module.exports = mongoose.model('Customer', customerSchema);

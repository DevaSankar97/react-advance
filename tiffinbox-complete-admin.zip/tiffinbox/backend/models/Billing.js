const mongoose = require('mongoose');

const billingSchema = new mongoose.Schema({
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Owner',
    required: true
  },
  customer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true
  },
  month: { type: Number, required: true }, // 1-12
  year:  { type: Number, required: true },
  totalDays:     { type: Number, default: 0 },
  deliveredDays: { type: Number, default: 0 },
  skippedDays:   { type: Number, default: 0 },
  pricePerDay:   { type: Number, required: true },
  totalAmount:   { type: Number, default: 0 },
  discount:      { type: Number, default: 0 },
  finalAmount:   { type: Number, default: 0 },
  paymentStatus: {
    type: String,
    enum: ['unpaid', 'partial', 'paid'],
    default: 'unpaid'
  },
  paidAmount:  { type: Number, default: 0 },
  paidDate:    Date,
  paymentMode: {
    type: String,
    enum: ['cash', 'upi', 'bank', 'other'],
    default: 'cash'
  },
  whatsappSent: { type: Boolean, default: false },
  notes: String,
  createdAt: { type: Date, default: Date.now }
});

// Compound index - one bill per customer per month
billingSchema.index({ owner: 1, customer: 1, month: 1, year: 1 }, { unique: true });

module.exports = mongoose.model('Billing', billingSchema);

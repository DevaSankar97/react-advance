const mongoose = require('mongoose');

const deliverySchema = new mongoose.Schema({
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Owner',
    required: true
  },
  customer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  meal: {
    type: String,
    enum: ['lunch', 'dinner'],
    default: 'lunch'
  },
  status: {
    type: String,
    enum: ['pending', 'delivered', 'skipped', 'holiday'],
    default: 'pending'
  },
  notes: String,
  createdAt: { type: Date, default: Date.now }
});

// Compound index to prevent duplicates
deliverySchema.index({ owner: 1, customer: 1, date: 1, meal: 1 }, { unique: true });

module.exports = mongoose.model('Delivery', deliverySchema);

const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');

const adminProtect = async (req, res, next) => {
  try {
    let token;
    if (req.headers.authorization?.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }
    if (!token) return res.status(401).json({ success: false, message: 'Admin access required.' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET + '_admin');
    req.admin = await Admin.findById(decoded.id);
    if (!req.admin) return res.status(401).json({ success: false, message: 'Admin not found.' });
    next();
  } catch {
    return res.status(401).json({ success: false, message: 'Invalid admin token.' });
  }
};

module.exports = { adminProtect };

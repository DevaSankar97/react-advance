import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './index.css';

// User app
import { AuthProvider, useAuth }   from './context/AuthContext';
import { AdminProvider, useAdmin } from './context/AdminContext';

import Login          from './components/auth/Login';
import Register       from './components/auth/Register';
import Dashboard      from './components/dashboard/Dashboard';
import Customers      from './components/customers/Customers';
import TodayDelivery  from './components/delivery/TodayDelivery';
import Billing        from './components/billing/Billing';
import Settings       from './components/settings/Settings';
import Layout         from './components/Layout';

// Admin panel
import AdminLogin     from './components/admin/AdminLogin';
import AdminLayout    from './components/admin/AdminLayout';
import AdminDashboard from './components/admin/AdminDashboard';
import AdminOwners    from './components/admin/AdminOwners';
import AdminRevenue   from './components/admin/AdminRevenue';
import AdminSettings  from './components/admin/AdminSettings';

// Guards
const PrivateRoute = ({ children }) => {
  const { owner, loading } = useAuth();
  if (loading) return (
    <div className="min-vh-100 d-flex flex-column align-items-center justify-content-center"
      style={{background:'#FFF8F0'}}>
      <div style={{fontSize:'3rem'}} className="mb-3">🍱</div>
      <div className="spinner-border text-primary mb-2"/>
      <p className="fw-semibold" style={{color:'#E07B39'}}>Loading TiffinBox...</p>
    </div>
  );
  return owner ? children : <Navigate to="/login"/>;
};

const AdminRoute = ({ children }) => {
  const { admin, loading } = useAdmin();
  if (loading) return (
    <div className="min-vh-100 d-flex flex-column align-items-center justify-content-center"
      style={{background:'#1e1b4b'}}>
      <div className="spinner-border text-light mb-2"/>
      <p className="text-white-50">Loading Admin Panel...</p>
    </div>
  );
  return admin ? children : <Navigate to="/admin/login"/>;
};

const App = () => (
  <AuthProvider>
    <AdminProvider>
      <BrowserRouter>
        <Toaster position="top-right" toastOptions={{
          style:{background:'#333',color:'#fff'},
          success:{style:{background:'#22c55e',color:'#fff'}},
          error:  {style:{background:'#ef4444',color:'#fff'}}
        }}/>
        <Routes>
          {/* User App */}
          <Route path="/login"    element={<Login/>}/>
          <Route path="/register" element={<Register/>}/>
          <Route path="/" element={<PrivateRoute><Layout/></PrivateRoute>}>
            <Route index             element={<Dashboard/>}/>
            <Route path="delivery"   element={<TodayDelivery/>}/>
            <Route path="customers"  element={<Customers/>}/>
            <Route path="billing"    element={<Billing/>}/>
            <Route path="settings"   element={<Settings/>}/>
          </Route>

          {/* Admin Panel */}
          <Route path="/admin/login" element={<AdminLogin/>}/>
          <Route path="/admin" element={<AdminRoute><AdminLayout/></AdminRoute>}>
            <Route index               element={<AdminDashboard/>}/>
            <Route path="owners"       element={<AdminOwners/>}/>
            <Route path="revenue"      element={<AdminRevenue/>}/>
            <Route path="settings"     element={<AdminSettings/>}/>
          </Route>
        </Routes>
      </BrowserRouter>
    </AdminProvider>
  </AuthProvider>
);

export default App;

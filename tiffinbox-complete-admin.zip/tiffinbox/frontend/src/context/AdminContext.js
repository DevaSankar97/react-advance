import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const AdminContext = createContext();
export const useAdmin = () => useContext(AdminContext);

export const AdminProvider = ({ children }) => {
  const [admin, setAdmin]     = useState(null);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('tiffinbox_admin_token');

  const api = axios.create({ baseURL: '' });
  if (token) api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

  useEffect(() => {
    if (token) fetchMe();
    else setLoading(false);
  }, []);

  const fetchMe = async () => {
    try {
      const { data } = await api.get('/api/admin/me');
      setAdmin(data.admin);
    } catch { logout(); }
    finally { setLoading(false); }
  };

  const login = async (email, password) => {
    const { data } = await axios.post('/api/admin/login', { email, password });
    localStorage.setItem('tiffinbox_admin_token', data.token);
    api.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
    setAdmin(data.admin);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('tiffinbox_admin_token');
    setAdmin(null);
  };

  return (
    <AdminContext.Provider value={{ admin, loading, login, logout, api }}>
      {children}
    </AdminContext.Provider>
  );
};

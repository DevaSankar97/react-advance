import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [owner, setOwner]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken]     = useState(localStorage.getItem('tiffinbox_token'));

  // Set axios default header
  if (token) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  }

  useEffect(() => {
    if (token) {
      fetchMe();
    } else {
      setLoading(false);
    }
  }, []);

  const fetchMe = async () => {
    try {
      const { data } = await axios.get('/api/auth/me');
      setOwner(data.owner);
    } catch {
      logout();
    } finally {
      setLoading(false);
    }
  };

  const login = async (phone, password) => {
    const { data } = await axios.post('/api/auth/login', { phone, password });
    localStorage.setItem('tiffinbox_token', data.token);
    axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
    setToken(data.token);
    setOwner(data.owner);
    return data;
  };

  const register = async (formData) => {
    const { data } = await axios.post('/api/auth/register', formData);
    localStorage.setItem('tiffinbox_token', data.token);
    axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
    setToken(data.token);
    setOwner(data.owner);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('tiffinbox_token');
    delete axios.defaults.headers.common['Authorization'];
    setToken(null);
    setOwner(null);
  };

  return (
    <AuthContext.Provider value={{ owner, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

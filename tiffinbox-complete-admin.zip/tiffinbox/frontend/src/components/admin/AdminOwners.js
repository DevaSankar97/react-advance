import React, { useState, useEffect } from 'react';
import { useAdmin } from '../../context/AdminContext';
import toast from 'react-hot-toast';

const AdminOwners = () => {
  const { api } = useAdmin();
  const [owners, setOwners]   = useState([]);
  const [total, setTotal]     = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');
  const [planFilter, setPlan] = useState('');
  const [page, setPage]       = useState(1);
  const [selected, setSelected] = useState(null);
  const [planModal, setPlanModal] = useState(null);
  const [newPlan, setNewPlan]   = useState('basic');

  const fetchOwners = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/api/admin/owners?search=${search}&plan=${planFilter}&page=${page}&limit=15`);
      setOwners(res.data.owners);
      setTotal(res.data.total);
    } catch { toast.error('Failed to load owners'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchOwners(); }, [search, planFilter, page]);

  const toggleStatus = async (id, name, current) => {
    if (!window.confirm(`${current ? 'Block' : 'Activate'} ${name}?`)) return;
    try {
      const res = await api.put(`/api/admin/owners/${id}/toggle`);
      toast.success(res.data.message);
      fetchOwners();
    } catch { toast.error('Failed'); }
  };

  const upgradePlan = async () => {
    try {
      const res = await api.put(`/api/admin/owners/${planModal._id}/plan`, { plan: newPlan });
      toast.success(res.data.message);
      setPlanModal(null);
      fetchOwners();
    } catch { toast.error('Failed to update plan'); }
  };

  const deleteOwner = async (id, name) => {
    if (!window.confirm(`DELETE ${name} permanently? This cannot be undone!`)) return;
    try {
      await api.delete(`/api/admin/owners/${id}`);
      toast.success('Owner deleted permanently');
      setSelected(null);
      fetchOwners();
    } catch { toast.error('Failed to delete'); }
  };

  const planBadge = { free:'secondary', basic:'warning', pro:'primary' };
  const totalPages = Math.ceil(total/15);

  return (
    <div>
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1">
            <i className="bi bi-people-fill me-2" style={{color:'#6366f1'}}></i>All Owners
          </h4>
          <p className="text-muted small mb-0">{total} registered tiffin businesses</p>
        </div>
      </div>

      {/* Filters */}
      <div className="d-flex gap-2 mb-4 flex-wrap">
        <div className="input-group" style={{maxWidth:300}}>
          <span className="input-group-text bg-white"><i className="bi bi-search text-muted"></i></span>
          <input className="form-control" placeholder="Search name, phone, business..."
            value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}/>
        </div>
        <select className="form-select" style={{width:'auto'}} value={planFilter}
          onChange={e => { setPlan(e.target.value); setPage(1); }}>
          <option value="">All Plans</option>
          <option value="free">Free</option>
          <option value="basic">Basic</option>
          <option value="pro">Pro</option>
        </select>
      </div>

      {/* Table */}
      <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table tb-table align-middle mb-0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Owner / Business</th>
                  <th>Phone</th>
                  <th>Customers</th>
                  <th>Plan</th>
                  <th>Status</th>
                  <th>Joined</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="text-center py-5">
                    <div className="spinner-border" style={{color:'#6366f1'}}/>
                  </td></tr>
                ) : owners.map((o, i) => (
                  <tr key={o._id}>
                    <td className="text-muted small">{(page-1)*15+i+1}</td>
                    <td>
                      <div className="fw-semibold">{o.name}</div>
                      <small className="text-muted"><i className="bi bi-shop me-1"></i>{o.businessName}</small>
                    </td>
                    <td><small>{o.phone}</small></td>
                    <td>
                      <span className="badge bg-light text-dark">
                        <i className="bi bi-people me-1"></i>{o.customerCount||0}
                      </span>
                    </td>
                    <td>
                      <span className={`badge bg-${planBadge[o.plan]||'secondary'} text-${o.plan==='basic'?'dark':'white'}`}>
                        {o.plan==='pro'?'👑':o.plan==='basic'?'⭐':'🆓'} {o.plan}
                      </span>
                    </td>
                    <td>
                      <span className={`badge rounded-pill ${o.isActive?'badge-active':'badge-stopped'}`}>
                        {o.isActive?'Active':'Blocked'}
                      </span>
                    </td>
                    <td><small className="text-muted">{new Date(o.createdAt).toLocaleDateString('en-IN')}</small></td>
                    <td>
                      <div className="d-flex gap-1">
                        <button className="btn btn-sm btn-outline-secondary" title="View Details"
                          onClick={() => setSelected(o)}>
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-sm btn-outline-primary" title="Change Plan"
                          onClick={() => { setPlanModal(o); setNewPlan(o.plan); }}>
                          <i className="bi bi-star"></i>
                        </button>
                        <button onClick={() => toggleStatus(o._id, o.name, o.isActive)}
                          className={`btn btn-sm ${o.isActive?'btn-outline-warning':'btn-outline-success'}`}
                          title={o.isActive?'Block':'Activate'}>
                          <i className={`bi bi-${o.isActive?'slash-circle':'check-circle'}`}></i>
                        </button>
                        <button onClick={() => deleteOwner(o._id, o.name)}
                          className="btn btn-sm btn-outline-danger" title="Delete">
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!loading && !owners.length && (
              <div className="text-center py-5 text-muted">
                <i className="bi bi-people fs-1 d-block mb-2"></i>No owners found.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-3 gap-2">
          <button className="btn btn-sm btn-outline-secondary" disabled={page===1} onClick={() => setPage(p=>p-1)}>
            <i className="bi bi-chevron-left"></i>
          </button>
          <span className="btn btn-sm btn-light disabled">Page {page} of {totalPages}</span>
          <button className="btn btn-sm btn-outline-secondary" disabled={page===totalPages} onClick={() => setPage(p=>p+1)}>
            <i className="bi bi-chevron-right"></i>
          </button>
        </div>
      )}

      {/* Owner Detail Modal */}
      {selected && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered modal-lg">
            <div className="modal-content border-0" style={{borderRadius:16}}>
              <div className="modal-header border-0 pb-0">
                <h5 className="modal-title fw-bold">
                  <i className="bi bi-person-circle me-2" style={{color:'#6366f1'}}></i>
                  {selected.name} — {selected.businessName}
                </h5>
                <button className="btn-close" onClick={() => setSelected(null)}/>
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  {[
                    {label:'Phone',    value:selected.phone},
                    {label:'Email',    value:selected.email||'N/A'},
                    {label:'City',     value:selected.address?.city||'N/A'},
                    {label:'Plan',     value:selected.plan},
                    {label:'Customers',value:selected.customerCount||0},
                    {label:'Joined',   value:new Date(selected.createdAt).toLocaleDateString('en-IN')},
                    {label:'Status',   value:selected.isActive?'✅ Active':'❌ Blocked'},
                    {label:'Plan Expiry', value:selected.planExpiry?new Date(selected.planExpiry).toLocaleDateString('en-IN'):'N/A'},
                  ].map(f => (
                    <div key={f.label} className="col-6 col-md-3">
                      <div className="p-3 rounded-3" style={{background:'#f8f9fa'}}>
                        <div className="text-muted" style={{fontSize:'.72rem'}}>{f.label}</div>
                        <div className="fw-semibold small mt-1">{f.value}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="modal-footer border-0">
                <button className="btn btn-danger btn-sm" onClick={() => deleteOwner(selected._id, selected.name)}>
                  <i className="bi bi-trash me-1"></i>Delete Account
                </button>
                <button className="btn btn-secondary btn-sm" onClick={() => setSelected(null)}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Plan Change Modal */}
      {planModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content border-0" style={{borderRadius:16}}>
              <div className="modal-header border-0">
                <h5 className="modal-title fw-bold">
                  <i className="bi bi-star me-2 text-warning"></i>Change Plan — {planModal.name}
                </h5>
                <button className="btn-close" onClick={() => setPlanModal(null)}/>
              </div>
              <div className="modal-body">
                <p className="text-muted small">Current plan: <strong>{planModal.plan}</strong></p>
                <div className="d-flex flex-column gap-2">
                  {[
                    {value:'free',  label:'🆓 Free — 10 customers, no charge'},
                    {value:'basic', label:'⭐ Basic — 100 customers, ₹499/month'},
                    {value:'pro',   label:'👑 Pro — Unlimited, ₹999/month'},
                  ].map(p => (
                    <label key={p.value} className={`p-3 rounded-3 border-2 border d-flex align-items-center gap-3 cursor-pointer
                      ${newPlan===p.value?'border-primary bg-primary bg-opacity-10':'border-light'}`}
                      style={{cursor:'pointer'}}>
                      <input type="radio" name="plan" value={p.value} checked={newPlan===p.value}
                        onChange={() => setNewPlan(p.value)}/>
                      <span className="fw-semibold small">{p.label}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="modal-footer border-0">
                <button className="btn btn-secondary" onClick={() => setPlanModal(null)}>Cancel</button>
                <button className="btn btn-primary fw-semibold" onClick={upgradePlan}>
                  <i className="bi bi-check-circle me-2"></i>Update Plan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminOwners;

import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import toast from 'react-hot-toast';

const AdminSettings = () => {
  const { admin, api } = useAdmin();
  const [setupForm, setSetupForm] = useState({ name:'', email:'', password:'' });
  const [setupMsg,  setSetupMsg]  = useState('');

  const createAdmin = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/api/admin/setup', setupForm);
      toast.success(res.data.message);
      setSetupMsg('Additional admin created!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed');
    }
  };

  return (
    <div>
      <div className="mb-4">
        <h4 className="fw-bold mb-1">
          <i className="bi bi-gear-fill me-2" style={{color:'#6366f1'}}></i>Admin Settings
        </h4>
        <p className="text-muted small mb-0">Manage platform configuration</p>
      </div>

      <div className="row g-4">
        {/* Admin Info */}
        <div className="col-12 col-lg-5">
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-shield-fill me-2" style={{color:'#6366f1'}}></i>Admin Profile
              </h6>
              <div className="d-flex align-items-center gap-3 p-3 rounded-3 mb-3"
                style={{background:'linear-gradient(135deg,#e0e7ff,#c7d2fe)'}}>
                <div className="rounded-circle d-flex align-items-center justify-content-center"
                  style={{width:52,height:52,background:'linear-gradient(135deg,#6366f1,#4f46e5)'}}>
                  <i className="bi bi-person-fill text-white fs-5"></i>
                </div>
                <div>
                  <div className="fw-bold">{admin?.name}</div>
                  <div className="text-muted small">{admin?.email}</div>
                  <span className="badge mt-1" style={{background:'#6366f1',color:'#fff'}}>Super Admin</span>
                </div>
              </div>

              {/* Platform Info */}
              <h6 className="fw-bold mb-3 mt-4">
                <i className="bi bi-info-circle me-2 text-primary"></i>Platform Info
              </h6>
              {[
                {label:'App Name',    value:'TiffinBox'},
                {label:'Version',     value:'1.0.0'},
                {label:'Stack',       value:'React + Node.js + MongoDB'},
                {label:'Admin Email', value:admin?.email},
              ].map(f => (
                <div key={f.label} className="d-flex justify-content-between py-2 border-bottom border-light">
                  <span className="text-muted small">{f.label}</span>
                  <span className="fw-semibold small">{f.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="col-12 col-lg-7">
          <div className="card border-0 shadow-sm mb-3" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-lightning-charge me-2 text-warning"></i>Quick Admin Actions
              </h6>
              {[
                { icon:'bi-people',        label:'View All Owners',       desc:'See all registered tiffin businesses',  href:'/admin/owners',  color:'#6366f1' },
                { icon:'bi-graph-up',      label:'Revenue Dashboard',     desc:'MRR, growth trends, top owners',        href:'/admin/revenue', color:'#22c55e' },
                { icon:'bi-arrow-clockwise',label:'Refresh Stats',        desc:'Reload all platform metrics',           action:'refresh',      color:'#E07B39' },
              ].map(a => (
                <a key={a.label} href={a.href||'#'}
                  onClick={a.action==='refresh' ? ()=>window.location.reload() : undefined}
                  className="d-flex align-items-center gap-3 p-3 rounded-3 mb-2 text-decoration-none"
                  style={{background:`${a.color}10`,border:`1px solid ${a.color}25`,transition:'transform .2s'}}
                  onMouseEnter={e=>e.currentTarget.style.transform='translateX(4px)'}
                  onMouseLeave={e=>e.currentTarget.style.transform='translateX(0)'}>
                  <div className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                    style={{width:40,height:40,background:`${a.color}20`}}>
                    <i className={`bi ${a.icon}`} style={{color:a.color}}></i>
                  </div>
                  <div>
                    <div className="fw-semibold small" style={{color:a.color}}>{a.label}</div>
                    <div className="text-muted" style={{fontSize:'.78rem'}}>{a.desc}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* API Reference */}
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-code-slash me-2 text-success"></i>Admin API Reference
              </h6>
              <div className="p-3 rounded-3" style={{background:'#1e1b4b',fontFamily:'monospace',fontSize:'.78rem'}}>
                {[
                  {method:'POST', path:'/api/admin/setup',          desc:'Create first admin'},
                  {method:'POST', path:'/api/admin/login',          desc:'Admin login'},
                  {method:'GET',  path:'/api/admin/dashboard',      desc:'Platform stats'},
                  {method:'GET',  path:'/api/admin/owners',         desc:'All owners list'},
                  {method:'PUT',  path:'/api/admin/owners/:id/plan',desc:'Update plan'},
                  {method:'PUT',  path:'/api/admin/owners/:id/toggle',desc:'Block/unblock'},
                  {method:'GET',  path:'/api/admin/revenue',        desc:'Revenue analytics'},
                ].map(r => (
                  <div key={r.path} className="d-flex gap-2 mb-2">
                    <span className={`badge ${r.method==='GET'?'text-bg-success':r.method==='POST'?'text-bg-primary':'text-bg-warning text-dark'}`}
                      style={{minWidth:50,fontSize:'.68rem'}}>{r.method}</span>
                    <span className="text-white-50">{r.path}</span>
                    <span className="text-white-25 ms-auto" style={{fontSize:'.72rem',color:'rgba(255,255,255,.4)'}}>{r.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;

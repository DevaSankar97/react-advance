import React, { useState, useEffect } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, BarChart, Bar } from 'recharts';

const AdminRevenue = () => {
  const { api } = useAdmin();
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/api/admin/revenue')
      .then(res => setData(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{minHeight:300}}>
      <div className="spinner-border" style={{color:'#6366f1'}}/>
    </div>
  );

  const currentMRR = data?.revenueTrend?.[data.revenueTrend.length-1]?.mrr || 0;
  const prevMRR    = data?.revenueTrend?.[data.revenueTrend.length-2]?.mrr || 0;
  const growth     = prevMRR > 0 ? (((currentMRR-prevMRR)/prevMRR)*100).toFixed(1) : 0;
  const annualRun  = currentMRR * 12;

  return (
    <div>
      <div className="mb-4">
        <h4 className="fw-bold mb-1">
          <i className="bi bi-graph-up-arrow me-2" style={{color:'#6366f1'}}></i>Revenue Analytics
        </h4>
        <p className="text-muted small mb-0">Your platform's financial performance</p>
      </div>

      {/* Key Metrics */}
      <div className="row g-3 mb-4">
        {[
          { label:'Current MRR',    value:`₹${currentMRR.toLocaleString('en-IN')}`,  icon:'💰', color:'#6366f1', bg:'#e0e7ff' },
          { label:'MoM Growth',     value:`${growth}%`,                               icon:'📈', color:'#22c55e', bg:'#dcfce7' },
          { label:'Annual Run Rate',value:`₹${annualRun.toLocaleString('en-IN')}`,    icon:'🎯', color:'#E07B39', bg:'#FFF0E8' },
          { label:'Paid Owners',    value:(data?.revenueTrend?.[data.revenueTrend.length-1]?.basic||0)+(data?.revenueTrend?.[data.revenueTrend.length-1]?.pro||0),
            icon:'👑', color:'#f59e0b', bg:'#fef9c3' },
        ].map(s => (
          <div key={s.label} className="col-6 col-md-3">
            <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-start">
                  <div>
                    <p className="text-muted small mb-1">{s.label}</p>
                    <h4 className="fw-bold mb-0" style={{color:s.color}}>{s.value}</h4>
                  </div>
                  <div className="rounded-circle d-flex align-items-center justify-content-center"
                    style={{width:44,height:44,background:s.bg,fontSize:'1.2rem'}}>{s.icon}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="row g-3 mb-4">
        {/* MRR Trend */}
        <div className="col-12 col-lg-8">
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-bar-chart me-2" style={{color:'#6366f1'}}></i>MRR Trend (12 Months)
              </h6>
              <ResponsiveContainer width="100%" height={240}>
                <LineChart data={data?.revenueTrend||[]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="month" tick={{fontSize:11,fill:'#888'}}/>
                  <YAxis tick={{fontSize:11,fill:'#888'}} tickFormatter={v=>`₹${v}`}/>
                  <Tooltip formatter={v=>[`₹${v}`,'']}/>
                  <Legend/>
                  <Line type="monotone" dataKey="mrr" name="MRR" stroke="#6366f1" strokeWidth={3} dot={{r:4}}/>
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Paid plan breakdown */}
        <div className="col-12 col-lg-4">
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-people me-2" style={{color:'#6366f1'}}></i>Paid Plan Growth
              </h6>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={data?.revenueTrend?.slice(-6)||[]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="month" tick={{fontSize:11}}/>
                  <YAxis tick={{fontSize:11}}/>
                  <Tooltip/>
                  <Bar dataKey="basic" name="Basic" fill="#E07B39" radius={[3,3,0,0]}/>
                  <Bar dataKey="pro"   name="Pro"   fill="#6366f1" radius={[3,3,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Top Owners Table */}
      <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
        <div className="card-body">
          <h6 className="fw-bold mb-3">
            <i className="bi bi-trophy me-2" style={{color:'#f59e0b'}}></i>Top Owners by Customer Count
          </h6>
          <div className="table-responsive">
            <table className="table tb-table align-middle mb-0">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Owner</th>
                  <th>Business</th>
                  <th>Plan</th>
                  <th>Active Customers</th>
                  <th>Revenue Potential</th>
                </tr>
              </thead>
              <tbody>
                {(data?.topOwners||[]).map((o,i) => (
                  <tr key={i}>
                    <td>
                      <span className="fw-bold" style={{color:i===0?'#f59e0b':i===1?'#9ca3af':i===2?'#b45309':'#6b7280'}}>
                        {i===0?'🥇':i===1?'🥈':i===2?'🥉':`#${i+1}`}
                      </span>
                    </td>
                    <td className="fw-semibold">{o.name}</td>
                    <td className="text-muted small">{o.businessName}</td>
                    <td>
                      <span className={`badge bg-${o.plan==='pro'?'primary':o.plan==='basic'?'warning text-dark':'secondary'}`}>
                        {o.plan}
                      </span>
                    </td>
                    <td>
                      <span className="badge bg-light text-dark">
                        <i className="bi bi-people me-1"></i>{o.customers}
                      </span>
                    </td>
                    <td className="fw-semibold text-success">
                      ₹{((o.customers||0)*500).toLocaleString('en-IN')}/mo est.
                    </td>
                  </tr>
                ))}
                {!data?.topOwners?.length && (
                  <tr><td colSpan={6} className="text-center py-4 text-muted">No data yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminRevenue;

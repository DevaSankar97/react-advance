import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdmin } from '../../context/AdminContext';
import toast from 'react-hot-toast';

const AdminLogin = () => {
  const [form, setForm]       = useState({ email:'', password:'' });
  const [loading, setLoading] = useState(false);
  const { login } = useAdmin();
  const navigate  = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Welcome back, Admin!');
      navigate('/admin');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid credentials');
    } finally { setLoading(false); }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center"
      style={{background:'linear-gradient(135deg,#1e1b4b,#312e81)'}}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12 col-sm-8 col-md-5 col-lg-4">
            <div className="card border-0 shadow-lg rounded-4 p-4">
              <div className="text-center mb-4">
                <div className="rounded-circle d-inline-flex align-items-center justify-content-center mb-3"
                  style={{width:64,height:64,background:'linear-gradient(135deg,#6366f1,#4f46e5)'}}>
                  <i className="bi bi-shield-lock-fill text-white fs-4"></i>
                </div>
                <h4 className="fw-bold mb-1">TiffinBox Admin</h4>
                <p className="text-muted small">Super Admin Panel</p>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Email Address</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="bi bi-envelope text-muted"></i></span>
                    <input type="email" className="form-control" placeholder="admin@tiffinbox.in"
                      value={form.email} onChange={e => setForm(f=>({...f,email:e.target.value}))} required/>
                  </div>
                </div>
                <div className="mb-4">
                  <label className="form-label fw-semibold small">Password</label>
                  <div className="input-group">
                    <span className="input-group-text"><i className="bi bi-lock text-muted"></i></span>
                    <input type="password" className="form-control" placeholder="Admin password"
                      value={form.password} onChange={e => setForm(f=>({...f,password:e.target.value}))} required/>
                  </div>
                </div>
                <button type="submit" className="btn w-100 fw-semibold text-white"
                  style={{background:'linear-gradient(135deg,#6366f1,#4f46e5)'}} disabled={loading}>
                  {loading
                    ? <><span className="spinner-border spinner-border-sm me-2"/>Logging in...</>
                    : <><i className="bi bi-shield-check me-2"/>Admin Login</>}
                </button>
              </form>

              <div className="mt-4 p-3 rounded-3 text-center" style={{background:'#f8f9fa'}}>
                <small className="text-muted">
                  <i className="bi bi-info-circle me-1"></i>
                  First time? Run <code>POST /api/admin/setup</code> to create admin account
                </small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;

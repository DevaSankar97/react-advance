import React, { useState, useEffect } from 'react';
import { useAdmin } from '../../context/AdminContext';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line } from 'recharts';

const StatCard = ({ icon, label, value, sub, gradient, iconBg }) => (
  <div className="card border-0 shadow-sm h-100" style={{borderRadius:12}}>
    <div className="card-body">
      <div className="d-flex justify-content-between align-items-start">
        <div>
          <p className="text-muted small mb-1">{label}</p>
          <h3 className="fw-bold mb-0">{value}</h3>
          {sub && <small className="text-muted">{sub}</small>}
        </div>
        <div className="rounded-circle d-flex align-items-center justify-content-center"
          style={{width:48,height:48,background:iconBg||'#e0e7ff',fontSize:'1.3rem'}}>
          {icon}
        </div>
      </div>
    </div>
  </div>
);

const AdminDashboard = () => {
  const { api } = useAdmin();
  const [stats, setStats]   = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/api/admin/dashboard')
      .then(res => setStats(res.data.stats))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{minHeight:300}}>
      <div className="spinner-border" style={{color:'#6366f1'}}/></div>
  );

  return (
    <div>
      {/* Header */}
      <div className="mb-4">
        <h4 className="fw-bold mb-1">
          <i className="bi bi-speedometer2 me-2" style={{color:'#6366f1'}}></i>
          Admin Dashboard
        </h4>
        <p className="text-muted small mb-0">Platform overview — all tiffin businesses on TiffinBox</p>
      </div>

      {/* Top Stats */}
      <div className="row g-3 mb-4">
        <div className="col-6 col-md-3">
          <StatCard icon="🏪" label="Total Owners"    value={stats?.owners?.total||0}
            sub={`+${stats?.owners?.newToday||0} today`} iconBg="#e0e7ff"/>
        </div>
        <div className="col-6 col-md-3">
          <StatCard icon="✅" label="Active Owners"   value={stats?.owners?.active||0}
            sub={`+${stats?.owners?.newThisWeek||0} this week`} iconBg="#dcfce7"/>
        </div>
        <div className="col-6 col-md-3">
          <StatCard icon="👥" label="Total Customers" value={stats?.customers?.total||0}
            sub="Across all accounts" iconBg="#fef9c3"/>
        </div>
        <div className="col-6 col-md-3">
          <StatCard icon="💰" label="Platform MRR"    value={`₹${(stats?.platformMRR||0).toLocaleString('en-IN')}`}
            sub="Monthly recurring" iconBg="#dcfce7"/>
        </div>
      </div>

      {/* Plan breakdown + Signups */}
      <div className="row g-3 mb-4">
        {/* Plan Cards */}
        <div className="col-12 col-md-4">
          <div className="card border-0 shadow-sm h-100" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-pie-chart me-2" style={{color:'#6366f1'}}></i>Plan Distribution
              </h6>
              {[
                { plan:'Free',  count:stats?.plans?.free||0,  color:'#6b7280', bg:'#f3f4f6', icon:'🆓' },
                { plan:'Basic', count:stats?.plans?.basic||0, color:'#E07B39', bg:'#FFF0E8', icon:'⭐' },
                { plan:'Pro',   count:stats?.plans?.pro||0,   color:'#6366f1', bg:'#e0e7ff', icon:'👑' },
              ].map(p => (
                <div key={p.plan} className="d-flex align-items-center justify-content-between p-3 rounded-3 mb-2"
                  style={{background:p.bg}}>
                  <div className="d-flex align-items-center gap-2">
                    <span>{p.icon}</span>
                    <span className="fw-semibold" style={{color:p.color}}>{p.plan} Plan</span>
                  </div>
                  <div className="d-flex align-items-center gap-2">
                    <span className="fw-bold fs-5" style={{color:p.color}}>{p.count}</span>
                    <small className="text-muted">owners</small>
                  </div>
                </div>
              ))}
              <div className="mt-3 p-3 rounded-3 text-center" style={{background:'linear-gradient(135deg,#6366f1,#4f46e5)'}}>
                <div className="text-white-50 small">Monthly Revenue</div>
                <div className="text-white fw-bold fs-4">₹{(stats?.platformMRR||0).toLocaleString('en-IN')}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Signup Trend Chart */}
        <div className="col-12 col-md-8">
          <div className="card border-0 shadow-sm h-100" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-graph-up me-2" style={{color:'#6366f1'}}></i>New Owner Signups (Last 6 Months)
              </h6>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={stats?.trend||[]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="month" tick={{fontSize:12,fill:'#888'}}/>
                  <YAxis tick={{fontSize:12,fill:'#888'}}/>
                  <Tooltip/>
                  <Bar dataKey="signups" name="New Signups" fill="#6366f1" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats Row */}
      <div className="row g-3">
        {[
          { icon:'🆕', label:'New Today',      value: stats?.owners?.newToday||0,      bg:'#dcfce7', color:'#16a34a' },
          { icon:'📅', label:'New This Week',  value: stats?.owners?.newThisWeek||0,   bg:'#e0e7ff', color:'#6366f1' },
          { icon:'📆', label:'New This Month', value: stats?.owners?.newThisMonth||0,  bg:'#fef9c3', color:'#ca8a04' },
          { icon:'📊', label:'Total Bills Gen',value: stats?.billing?.totalBills||0,   bg:'#FFF0E8', color:'#E07B39' },
        ].map(s => (
          <div key={s.label} className="col-6 col-md-3">
            <div className="card border-0 shadow-sm text-center" style={{borderRadius:12}}>
              <div className="card-body py-3">
                <div className="rounded-circle d-inline-flex align-items-center justify-content-center mb-2"
                  style={{width:44,height:44,background:s.bg,fontSize:'1.2rem'}}>{s.icon}</div>
                <h4 className="fw-bold mb-0" style={{color:s.color}}>{s.value}</h4>
                <small className="text-muted">{s.label}</small>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;

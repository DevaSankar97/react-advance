import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAdmin } from '../../context/AdminContext';
import toast from 'react-hot-toast';

const AdminLayout = () => {
  const { admin, logout } = useAdmin();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => {
    logout();
    toast.success('Logged out!');
    navigate('/admin/login');
  };

  const navItems = [
    { path:'/admin',          icon:'bi-speedometer2',   label:'Dashboard',   end:true },
    { path:'/admin/owners',   icon:'bi-people-fill',    label:'All Owners'         },
    { path:'/admin/revenue',  icon:'bi-graph-up-arrow', label:'Revenue'            },
    { path:'/admin/settings', icon:'bi-gear-fill',      label:'Settings'           },
  ];

  return (
    <div className="d-flex" style={{minHeight:'100vh'}}>
      {/* Sidebar */}
      <div style={{
        width: collapsed?70:240, minHeight:'100vh', transition:'width .3s',
        background:'linear-gradient(180deg,#1e1b4b,#312e81)',
        display:'flex', flexDirection:'column'
      }}>
        {/* Logo */}
        <div className="p-3 border-bottom border-white border-opacity-25">
          <div className="d-flex align-items-center gap-2">
            <div className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
              style={{width:36,height:36,background:'rgba(99,102,241,.3)'}}>
              <i className="bi bi-shield-fill text-white"></i>
            </div>
            {!collapsed && (
              <div>
                <div className="text-white fw-bold" style={{fontSize:'.9rem'}}>TiffinBox</div>
                <div className="text-white-50" style={{fontSize:'.68rem'}}>Super Admin</div>
              </div>
            )}
          </div>
        </div>

        {/* Nav */}
        <nav className="p-2 flex-grow-1 mt-1">
          {navItems.map(item => (
            <NavLink key={item.path} to={item.path} end={item.end}
              className={({isActive}) =>
                `d-flex align-items-center gap-2 rounded-3 mb-1 text-decoration-none px-3 py-2 ${isActive?'bg-white bg-opacity-25 text-white fw-semibold':'text-white-50'}`
              }
              style={{transition:'all .2s',fontSize:'.88rem'}}>
              <i className={`bi ${item.icon} fs-6`} style={{minWidth:20}}></i>
              {!collapsed && <span>{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Bottom */}
        <div className="p-3 border-top border-white border-opacity-25">
          {!collapsed && <div className="text-white-50 small mb-2">👤 {admin?.name}</div>}
          <button onClick={handleLogout} className="btn btn-sm w-100 text-white border-0"
            style={{background:'rgba(255,255,255,.1)'}}>
            <i className="bi bi-box-arrow-left me-1"></i>
            {!collapsed && 'Logout'}
          </button>
        </div>
      </div>

      {/* Main */}
      <div className="flex-grow-1 d-flex flex-column bg-light" style={{minWidth:0}}>
        {/* Topbar */}
        <div className="bg-white border-bottom px-4 py-2 d-flex justify-content-between align-items-center"
          style={{boxShadow:'0 2px 8px rgba(0,0,0,.06)'}}>
          <button className="btn btn-sm btn-light border-0" onClick={() => setCollapsed(!collapsed)}>
            <i className="bi bi-list fs-5"></i>
          </button>
          <div className="d-flex align-items-center gap-3">
            <small className="text-muted">
              <i className="bi bi-calendar3 me-1"></i>
              {new Date().toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric'})}
            </small>
            <span className="badge rounded-pill text-white px-3 py-2"
              style={{background:'linear-gradient(135deg,#6366f1,#4f46e5)'}}>
              <i className="bi bi-shield-check me-1"></i>Super Admin
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 flex-grow-1" style={{overflowY:'auto'}}>
          <Outlet/>
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;

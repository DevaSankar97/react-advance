import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const Layout = () => {
  const { owner, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => {
    logout();
    toast.success('Logged out!');
    navigate('/login');
  };

  const navItems = [
    { path:'/',          icon:'bi-speedometer2', label:'Dashboard'        },
    { path:'/delivery',  icon:'bi-bicycle',      label:"Today's Delivery" },
    { path:'/customers', icon:'bi-people-fill',  label:'Customers'        },
    { path:'/billing',   icon:'bi-cash-stack',   label:'Billing'          },
    { path:'/settings',  icon:'bi-gear-fill',    label:'Settings'         },
  ];

  return (
    <div className="d-flex" style={{minHeight:'100vh'}}>
      {/* Sidebar */}
      <div className={`tb-sidebar d-flex flex-column ${collapsed?'collapsed':''}`}>
        {/* Logo */}
        <div className="p-3 border-bottom border-white border-opacity-25">
          <div className="d-flex align-items-center gap-2">
            <span style={{fontSize:'1.8rem'}}>🍱</span>
            {!collapsed && (
              <div>
                <div className="text-white fw-bold">TiffinBox</div>
                <div className="text-white-50" style={{fontSize:'.72rem'}}>{owner?.businessName}</div>
              </div>
            )}
          </div>
        </div>

        {/* Nav */}
        <nav className="nav flex-column p-2 flex-grow-1 mt-1">
          {navItems.map(item => (
            <NavLink key={item.path} to={item.path} end={item.path==='/'}
              className={({isActive}) => `nav-link d-flex align-items-center gap-2 mb-1 ${isActive?'active':''}`}>
              <i className={`bi ${item.icon} fs-5`} style={{minWidth:'20px'}}></i>
              <span className="label">{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Bottom */}
        <div className="p-3 border-top border-white border-opacity-25">
          {!collapsed && (
            <div className="text-white-50 small mb-2">
              <i className="bi bi-person-circle me-1"></i>{owner?.name}
            </div>
          )}
          <button onClick={handleLogout}
            className="btn btn-sm w-100 d-flex align-items-center gap-2 justify-content-center"
            style={{background:'rgba(255,255,255,.15)',color:'#fff',border:'none'}}>
            <i className="bi bi-box-arrow-left"></i>
            {!collapsed && 'Logout'}
          </button>
        </div>
      </div>

      {/* Main */}
      <div className="flex-grow-1 d-flex flex-column" style={{minWidth:0}}>
        {/* Topbar */}
        <div className="tb-topbar px-4 py-2 d-flex justify-content-between align-items-center">
          <button className="btn btn-sm btn-light border-0" onClick={() => setCollapsed(!collapsed)}>
            <i className="bi bi-list fs-5"></i>
          </button>
          <div className="d-flex align-items-center gap-3">
            <small className="text-muted">
              <i className="bi bi-calendar3 me-1"></i>
              {new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}
            </small>
            <span className="badge rounded-pill" style={{background:'#FFF0E8',color:'#E07B39',border:'1px solid #E07B39'}}>
              🆓 Free Trial
            </span>
          </div>
        </div>

        {/* Page content */}
        <div className="p-4 flex-grow-1" style={{overflowY:'auto'}}>
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default Layout;

import React, { useState } from 'react';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const Settings = () => {
  const { owner } = useAuth();
  const [profile, setProfile] = useState({
    name: owner?.name||'', businessName: owner?.businessName||'',
    email: owner?.email||'', city: owner?.address?.city||'Chennai'
  });
  const [pwd, setPwd] = useState({ current:'', newPwd:'', confirm:'' });
  const [saving, setSaving] = useState(false);

  const saveProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await axios.put('/api/auth/profile', profile);
      toast.success('Profile updated!');
    } catch (err) { toast.error(err.response?.data?.message||'Failed'); }
    finally { setSaving(false); }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    if (pwd.newPwd !== pwd.confirm) { toast.error('Passwords do not match!'); return; }
    try {
      await axios.put('/api/auth/password', { currentPassword: pwd.current, newPassword: pwd.newPwd });
      toast.success('Password changed!');
      setPwd({current:'',newPwd:'',confirm:''});
    } catch (err) { toast.error(err.response?.data?.message||'Failed'); }
  };

  return (
    <div>
      <div className="mb-4">
        <h4 className="fw-bold mb-1"><i className="bi bi-gear-fill me-2 text-primary"></i>Settings</h4>
        <p className="text-muted small mb-0">Manage your profile and account settings</p>
      </div>

      <div className="row g-4">
        {/* Profile */}
        <div className="col-12 col-lg-6">
          <div className="card stat-card">
            <div className="card-header bg-white border-bottom border-light py-3">
              <h6 className="fw-bold mb-0"><i className="bi bi-person-circle me-2 text-primary"></i>Business Profile</h6>
            </div>
            <div className="card-body">
              <form onSubmit={saveProfile}>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Your Name</label>
                  <input className="form-control" value={profile.name}
                    onChange={e => setProfile(p=>({...p,name:e.target.value}))} required/>
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Business Name</label>
                  <input className="form-control" value={profile.businessName}
                    onChange={e => setProfile(p=>({...p,businessName:e.target.value}))} required/>
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Email</label>
                  <input type="email" className="form-control" value={profile.email}
                    onChange={e => setProfile(p=>({...p,email:e.target.value}))}/>
                </div>
                <div className="mb-4">
                  <label className="form-label fw-semibold small">City</label>
                  <input className="form-control" value={profile.city}
                    onChange={e => setProfile(p=>({...p,city:e.target.value}))}/>
                </div>
                <button type="submit" className="btn btn-primary fw-semibold w-100" disabled={saving}>
                  {saving ? <><span className="spinner-border spinner-border-sm me-2"/>Saving...</> : <><i className="bi bi-check-circle me-2"/>Save Profile</>}
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Password */}
        <div className="col-12 col-lg-6">
          <div className="card stat-card">
            <div className="card-header bg-white border-bottom border-light py-3">
              <h6 className="fw-bold mb-0"><i className="bi bi-shield-lock me-2 text-primary"></i>Change Password</h6>
            </div>
            <div className="card-body">
              <form onSubmit={changePassword}>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Current Password</label>
                  <input type="password" className="form-control" value={pwd.current}
                    onChange={e => setPwd(p=>({...p,current:e.target.value}))} required/>
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">New Password</label>
                  <input type="password" className="form-control" value={pwd.newPwd}
                    onChange={e => setPwd(p=>({...p,newPwd:e.target.value}))} required minLength={6}/>
                </div>
                <div className="mb-4">
                  <label className="form-label fw-semibold small">Confirm New Password</label>
                  <input type="password" className="form-control" value={pwd.confirm}
                    onChange={e => setPwd(p=>({...p,confirm:e.target.value}))} required/>
                </div>
                <button type="submit" className="btn btn-outline-primary fw-semibold w-100">
                  <i className="bi bi-lock me-2"></i>Change Password
                </button>
              </form>
            </div>
          </div>

          {/* Plan Info */}
          <div className="card stat-card mt-4">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-star-fill me-2 text-warning"></i>Your Plan</h6>
              <div className="d-flex justify-content-between align-items-center p-3 rounded"
                style={{background:'#FFF8F0',border:'1px solid #F0E6D8'}}>
                <div>
                  <div className="fw-bold text-primary fs-5">Free Trial</div>
                  <small className="text-muted">Up to 10 customers</small>
                </div>
                <span className="badge bg-warning text-dark px-3 py-2">Active</span>
              </div>
              <button className="btn btn-primary fw-semibold w-100 mt-3">
                <i className="bi bi-rocket-takeoff me-2"></i>Upgrade to Pro — ₹499/month
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;

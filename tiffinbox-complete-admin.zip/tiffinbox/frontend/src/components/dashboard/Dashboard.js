import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { useAuth } from '../../context/AuthContext';

const StatCard = ({ icon, label, value, sub, borderColor, iconBg }) => (
  <div className="card stat-card h-100" style={{borderTop:`4px solid ${borderColor}`}}>
    <div className="card-body">
      <div className="d-flex justify-content-between align-items-start">
        <div>
          <p className="text-muted small mb-1">{label}</p>
          <h3 className="fw-bold mb-0">{value}</h3>
          {sub && <small className="text-muted">{sub}</small>}
        </div>
        <div className="rounded-circle d-flex align-items-center justify-content-center"
          style={{width:46,height:46,background:iconBg,fontSize:'1.3rem'}}>
          {icon}
        </div>
      </div>
    </div>
  </div>
);

const Dashboard = () => {
  const { owner } = useAuth();
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('/api/dashboard')
      .then(res => setData(res.data.dashboard))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const greeting = () => {
    const h = new Date().getHours();
    return h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : 'Good Evening';
  };

  if (loading) return (
    <div className="tb-loading">
      <div className="spinner-border text-primary mb-2"/>
      <span>Loading dashboard...</span>
    </div>
  );

  const quickActions = [
    { icon:'🛵', label:"Mark Today's Deliveries", path:'/delivery',  color:'#E07B39' },
    { icon:'👥', label:'Add New Customer',         path:'/customers', color:'#6366f1' },
    { icon:'⚡', label:'Generate Monthly Bills',   path:'/billing',   color:'#22c55e' },
    { icon:'💬', label:'Send WhatsApp Reminders',  path:'/billing',   color:'#25D366' },
  ];

  return (
    <div>
      {/* Header */}
      <div className="mb-4">
        <h4 className="fw-bold mb-1">{greeting()}, {owner?.name}! 👋</h4>
        <p className="text-muted mb-0 small">Here's your business overview for today</p>
      </div>

      {/* Stat Cards */}
      <div className="row g-3 mb-4">
        <div className="col-6 col-md-3">
          <StatCard icon="👥" label="Active Customers"
            value={data?.customers?.active || 0}
            sub={`Total: ${data?.customers?.total || 0}`}
            borderColor="#E07B39" iconBg="#FFF0E8"/>
        </div>
        <div className="col-6 col-md-3">
          <StatCard icon="✅" label="Delivered Today"
            value={data?.today?.delivered || 0}
            sub={`Pending: ${data?.today?.pending || 0}`}
            borderColor="#22c55e" iconBg="#dcfce7"/>
        </div>
        <div className="col-6 col-md-3">
          <StatCard icon="💰" label="Monthly Revenue"
            value={`₹${(data?.billing?.totalRevenue||0).toLocaleString('en-IN')}`}
            sub="This month"
            borderColor="#6366f1" iconBg="#e0e7ff"/>
        </div>
        <div className="col-6 col-md-3">
          <StatCard icon="⏳" label="Pending Collection"
            value={`₹${(data?.billing?.pendingAmt||0).toLocaleString('en-IN')}`}
            sub={`${data?.billing?.unpaidCount||0} customers`}
            borderColor="#f59e0b" iconBg="#fef9c3"/>
        </div>
      </div>

      {/* Chart + Quick Actions */}
      <div className="row g-3">
        {/* Chart */}
        <div className="col-12 col-lg-8">
          <div className="card stat-card h-100">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-bar-chart-line me-2 text-primary"></i>Revenue Trend (Last 6 Months)</h6>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={data?.trend || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="month" tick={{fontSize:12,fill:'#888'}}/>
                  <YAxis tick={{fontSize:12,fill:'#888'}} tickFormatter={v=>`₹${v}`}/>
                  <Tooltip formatter={v=>[`₹${v}`,'']}/>
                  <Legend/>
                  <Bar dataKey="revenue"   name="Billed"    fill="#E07B39" radius={[4,4,0,0]}/>
                  <Bar dataKey="collected" name="Collected" fill="#22c55e" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="col-12 col-lg-4">
          <div className="card stat-card h-100">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-lightning-charge me-2 text-primary"></i>Quick Actions</h6>
              {quickActions.map(a => (
                <Link key={a.label} to={a.path} className="quick-action text-decoration-none"
                  style={{background:`${a.color}12`,border:`1px solid ${a.color}30`}}>
                  <span style={{fontSize:'1.3rem'}}>{a.icon}</span>
                  <span style={{color:a.color,fontWeight:500,fontSize:'.88rem'}}>{a.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

const Billing = () => {
  const now = new Date();
  const [month, setMonth]     = useState(now.getMonth()+1);
  const [year,  setYear]      = useState(now.getFullYear());
  const [bills, setBills]     = useState([]);
  const [summary, setSummary] = useState({});
  const [loading, setLoading] = useState(true);
  const [generating, setGen]  = useState(false);
  const [payModal, setPay]    = useState(null);
  const [payForm, setPayForm] = useState({paidAmount:'',paymentMode:'cash'});

  const fetchBills = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`/api/billing?month=${month}&year=${year}`);
      setBills(res.data.bills);
      setSummary(res.data.summary||{});
    } catch { toast.error('Failed to load bills'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchBills(); }, [month, year]);

  const generateBills = async () => {
    setGen(true);
    try {
      const res = await axios.post('/api/billing/generate', {month, year});
      toast.success(res.data.message);
      fetchBills();
    } catch (err) { toast.error(err.response?.data?.message||'Failed'); }
    finally { setGen(false); }
  };

  const recordPayment = async () => {
    try {
      const res = await axios.put(`/api/billing/${payModal._id}/payment`, payForm);
      toast.success(res.data.message);
      setPay(null);
      fetchBills();
    } catch { toast.error('Failed to record payment'); }
  };

  const sendWA = async (billId) => {
    try {
      const res = await axios.post(`/api/whatsapp/send-bill/${billId}`);
      toast.success(res.data.message);
    } catch { toast.error('WhatsApp failed. Check Twilio setup.'); }
  };

  const sendAllReminders = async () => {
    try {
      const res = await axios.post('/api/whatsapp/send-reminder',{month,year});
      toast.success(res.data.message);
    } catch { toast.error('Failed to send reminders'); }
  };

  const statusBadge = { paid:'badge-paid', partial:'badge-partial', unpaid:'badge-unpaid' };

  return (
    <div>
      {/* Header */}
      <div className="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1"><i className="bi bi-cash-stack me-2 text-primary"></i>Billing</h4>
          <p className="text-muted small mb-0">{MONTHS[month-1]} {year}</p>
        </div>
        <div className="d-flex gap-2 flex-wrap">
          <select className="form-select form-select-sm" style={{width:'auto'}}
            value={month} onChange={e => setMonth(parseInt(e.target.value))}>
            {MONTHS.map((m,i) => <option key={m} value={i+1}>{m}</option>)}
          </select>
          <select className="form-select form-select-sm" style={{width:'auto'}}
            value={year} onChange={e => setYear(parseInt(e.target.value))}>
            {[2024,2025,2026,2027].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
          <button className="btn btn-primary btn-sm fw-semibold" onClick={generateBills} disabled={generating}>
            {generating
              ? <><span className="spinner-border spinner-border-sm me-1"/>Generating...</>
              : <><i className="bi bi-lightning-charge me-1"/>Generate Bills</>}
          </button>
          <button className="btn btn-sm fw-semibold text-white" style={{background:'#25D366',border:'none'}} onClick={sendAllReminders}>
            <i className="bi bi-whatsapp me-1"/>Send Reminders
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="row g-3 mb-4">
        {[
          {label:'Total Bills',    value:summary.total,        color:'#6366f1', prefix:''},
          {label:'Total Amount',   value:summary.totalAmount,  color:'#E07B39', prefix:'₹'},
          {label:'Collected',      value:summary.collectedAmt, color:'#22c55e', prefix:'₹'},
          {label:'Pending',        value:summary.unpaidAmount, color:'#ef4444', prefix:'₹'},
          {label:'Paid',           value:summary.paid,         color:'#22c55e', prefix:''},
        ].map(s => (
          <div key={s.label} className="col-6 col-md">
            <div className="card stat-card text-center" style={{borderTop:`3px solid ${s.color}`}}>
              <div className="card-body py-3">
                <h4 className="fw-bold mb-0" style={{color:s.color}}>
                  {s.prefix}{typeof s.value==='number' ? s.value.toLocaleString('en-IN') : 0}
                </h4>
                <small className="text-muted">{s.label}</small>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="card stat-card">
        <div className="card-body p-0">
          {loading ? (
            <div className="tb-loading py-5"><div className="spinner-border text-primary"/></div>
          ) : (
            <div className="table-responsive">
              <table className="table tb-table align-middle mb-0">
                <thead>
                  <tr>
                    <th>Customer</th>
                    <th>Delivered</th>
                    <th>Amount</th>
                    <th>Paid</th>
                    <th>Balance</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {bills.map(bill => {
                    const balance = bill.finalAmount - bill.paidAmount;
                    return (
                      <tr key={bill._id}>
                        <td>
                          <div className="fw-semibold">{bill.customer?.name}</div>
                          <small className="text-muted"><i className="bi bi-phone me-1"></i>{bill.customer?.phone}</small>
                        </td>
                        <td><span className="badge bg-light text-dark">{bill.deliveredDays} days</span></td>
                        <td className="fw-semibold">₹{bill.finalAmount}</td>
                        <td className="text-success fw-semibold">₹{bill.paidAmount}</td>
                        <td className={`fw-bold ${balance>0?'text-danger':'text-success'}`}>₹{balance}</td>
                        <td>
                          <span className={`badge rounded-pill px-3 py-2 ${statusBadge[bill.paymentStatus]||'badge-unpaid'}`}>
                            {bill.paymentStatus}
                          </span>
                        </td>
                        <td>
                          <div className="d-flex gap-1">
                            {bill.paymentStatus!=='paid' && (
                              <button className="btn btn-sm btn-outline-success" title="Record Payment"
                                onClick={() => { setPay(bill); setPayForm({paidAmount:balance,paymentMode:'cash'}); }}>
                                <i className="bi bi-cash-coin"></i>
                              </button>
                            )}
                            <button className="btn btn-sm" title="Send WhatsApp Bill"
                              style={{background:'#25D366',color:'#fff',border:'none'}}
                              onClick={() => sendWA(bill._id)}>
                              <i className="bi bi-whatsapp"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {!bills.length && (
                <div className="text-center py-5 text-muted">
                  <i className="bi bi-receipt fs-1 d-block mb-2"></i>
                  No bills found. Click "Generate Bills" to create bills for {MONTHS[month-1]} {year}.
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Payment Modal */}
      {payModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold"><i className="bi bi-cash-coin me-2 text-success"></i>Record Payment</h5>
                <button className="btn-close" onClick={() => setPay(null)}/>
              </div>
              <div className="modal-body">
                <div className="alert alert-light border">
                  <strong>{payModal.customer?.name}</strong><br/>
                  <small>Total: <strong>₹{payModal.finalAmount}</strong> | Balance: <strong>₹{payModal.finalAmount-payModal.paidAmount}</strong></small>
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Amount Paid (₹)</label>
                  <div className="input-group">
                    <span className="input-group-text">₹</span>
                    <input type="number" className="form-control form-control-lg"
                      value={payForm.paidAmount}
                      onChange={e => setPayForm(f=>({...f,paidAmount:e.target.value}))}/>
                  </div>
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Payment Mode</label>
                  <select className="form-select" value={payForm.paymentMode}
                    onChange={e => setPayForm(f=>({...f,paymentMode:e.target.value}))}>
                    <option value="cash">💵 Cash</option>
                    <option value="upi">📱 UPI</option>
                    <option value="bank">🏦 Bank Transfer</option>
                  </select>
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setPay(null)}>Cancel</button>
                <button className="btn btn-success fw-semibold" onClick={recordPayment}>
                  <i className="bi bi-check-circle me-2"></i>Record Payment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Billing;

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const Register = () => {
  const [form, setForm] = useState({
    name:'', phone:'', email:'', businessName:'', password:'', city:'Chennai'
  });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await register(form);
      toast.success(data.message);
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally { setLoading(false); }
  };

  const set = (key, val) => setForm(f => ({...f, [key]: val}));

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center py-4"
      style={{background:'linear-gradient(135deg,#FFF8F0,#FFE8D0)'}}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12 col-sm-9 col-md-6 col-lg-5">
            <div className="card auth-card p-4">
              <div className="text-center mb-4">
                <div style={{fontSize:'3rem'}}>🍱</div>
                <h2 className="fw-bold text-primary mb-1">Start Free Trial</h2>
                <p className="text-muted small">30 days free — no credit card needed</p>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="row g-3 mb-3">
                  <div className="col-12">
                    <label className="form-label fw-semibold small"><i className="bi bi-person me-1"></i>Your Name</label>
                    <input className="form-control" placeholder="Kavitha Devi"
                      value={form.name} onChange={e => set('name',e.target.value)} required/>
                  </div>
                  <div className="col-12">
                    <label className="form-label fw-semibold small"><i className="bi bi-shop me-1"></i>Business Name</label>
                    <input className="form-control" placeholder="Kavitha Tiffin Service"
                      value={form.businessName} onChange={e => set('businessName',e.target.value)} required/>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label fw-semibold small"><i className="bi bi-phone me-1"></i>Mobile Number</label>
                    <input className="form-control" placeholder="9876543210" maxLength={10}
                      value={form.phone} onChange={e => set('phone',e.target.value)} required/>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label fw-semibold small"><i className="bi bi-geo-alt me-1"></i>City</label>
                    <input className="form-control" placeholder="Chennai"
                      value={form.city} onChange={e => set('city',e.target.value)} required/>
                  </div>
                  <div className="col-12">
                    <label className="form-label fw-semibold small"><i className="bi bi-envelope me-1"></i>Email <span className="text-muted">(optional)</span></label>
                    <input type="email" className="form-control" placeholder="kavitha@gmail.com"
                      value={form.email} onChange={e => set('email',e.target.value)}/>
                  </div>
                  <div className="col-12">
                    <label className="form-label fw-semibold small"><i className="bi bi-lock me-1"></i>Password</label>
                    <input type="password" className="form-control" placeholder="Min 6 characters"
                      value={form.password} onChange={e => set('password',e.target.value)} required minLength={6}/>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary btn-lg w-100 fw-semibold" disabled={loading}>
                  {loading
                    ? <><span className="spinner-border spinner-border-sm me-2"/>Creating account...</>
                    : <><i className="bi bi-rocket-takeoff me-2"/>Start Free Trial</>}
                </button>
              </form>

              <hr className="my-3"/>
              <p className="text-center text-muted small mb-0">
                Already have an account?{' '}
                <Link to="/login" className="text-primary fw-semibold text-decoration-none">Login</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;

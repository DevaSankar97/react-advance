import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const Login = () => {
  const [form, setForm]     = useState({ phone:'', password:'' });
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const { login } = useAuth();
  const navigate  = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await login(form.phone, form.password);
      toast.success(data.message);
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center"
      style={{background:'linear-gradient(135deg,#FFF8F0,#FFE8D0)'}}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12 col-sm-8 col-md-5 col-lg-4">
            <div className="card auth-card p-4">
              {/* Logo */}
              <div className="text-center mb-4">
                <div style={{fontSize:'3.5rem'}}>🍱</div>
                <h2 className="fw-bold text-primary mb-1">TiffinBox</h2>
                <p className="text-muted small">Manage your tiffin business easily</p>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">
                    <i className="bi bi-phone me-1"></i>Mobile Number
                  </label>
                  <input type="tel" className="form-control form-control-lg"
                    placeholder="9876543210" maxLength={10}
                    value={form.phone}
                    onChange={e => setForm({...form, phone:e.target.value})}
                    required/>
                </div>

                <div className="mb-4">
                  <label className="form-label fw-semibold small">
                    <i className="bi bi-lock me-1"></i>Password
                  </label>
                  <div className="input-group">
                    <input type={showPwd?'text':'password'} className="form-control form-control-lg"
                      placeholder="Enter password"
                      value={form.password}
                      onChange={e => setForm({...form, password:e.target.value})}
                      required/>
                    <button type="button" className="btn btn-outline-secondary"
                      onClick={() => setShowPwd(!showPwd)}>
                      <i className={`bi bi-eye${showPwd?'-slash':''}`}></i>
                    </button>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary btn-lg w-100 fw-semibold"
                  disabled={loading}>
                  {loading
                    ? <><span className="spinner-border spinner-border-sm me-2"/>Logging in...</>
                    : <><i className="bi bi-arrow-right-circle me-2"/>Login</>}
                </button>
              </form>

              <hr className="my-3"/>
              <p className="text-center text-muted small mb-0">
                New to TiffinBox?{' '}
                <Link to="/register" className="text-primary fw-semibold text-decoration-none">
                  Start Free Trial
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;

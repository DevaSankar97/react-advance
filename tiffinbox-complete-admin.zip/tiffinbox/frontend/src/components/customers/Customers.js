import React, { useState, useEffect } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

const defaultForm = {
  name:'', phone:'',
  address:{ street:'', area:'', city:'Chennai' },
  plan:{ type:'veg', meals:'lunch', pricePerMonth:'' },
  startDate: new Date().toISOString().split('T')[0],
  notes:''
};

const Customers = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm]           = useState(defaultForm);
  const [editId, setEditId]       = useState(null);
  const [search, setSearch]       = useState('');
  const [filterStatus, setFilter] = useState('active');

  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`/api/customers?status=${filterStatus}&search=${search}`);
      setCustomers(res.data.customers);
    } catch { toast.error('Failed to load customers'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchCustomers(); }, [filterStatus, search]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await axios.put(`/api/customers/${editId}`, form);
        toast.success('Customer updated!');
      } else {
        const res = await axios.post('/api/customers', form);
        toast.success(res.data.message);
      }
      setShowModal(false);
      setForm(defaultForm);
      setEditId(null);
      fetchCustomers();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save'); }
  };

  const handleEdit = (c) => {
    setForm({
      name:c.name, phone:c.phone,
      address: c.address||defaultForm.address,
      plan: c.plan,
      startDate: new Date(c.startDate).toISOString().split('T')[0],
      notes: c.notes||''
    });
    setEditId(c._id);
    setShowModal(true);
  };

  const toggleStatus = async (id, current) => {
    const next = current==='active'?'paused':'active';
    try {
      await axios.put(`/api/customers/${id}`, { status: next });
      toast.success(`Customer ${next}!`);
      fetchCustomers();
    } catch { toast.error('Failed to update status'); }
  };

  const setPlan = (key, val) => setForm(f => ({...f, plan:{...f.plan,[key]:val}}));
  const setAddr = (key, val) => setForm(f => ({...f, address:{...f.address,[key]:val}}));

  const badgeMap = { active:'badge-active', paused:'badge-paused', stopped:'badge-stopped' };

  return (
    <div>
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1"><i className="bi bi-people-fill me-2 text-primary"></i>Customers</h4>
          <p className="text-muted small mb-0">{customers.length} customers</p>
        </div>
        <button className="btn btn-primary fw-semibold"
          onClick={() => { setShowModal(true); setForm(defaultForm); setEditId(null); }}>
          <i className="bi bi-person-plus me-2"></i>Add Customer
        </button>
      </div>

      {/* Filters */}
      <div className="d-flex gap-2 mb-4 flex-wrap align-items-center">
        <div className="input-group" style={{maxWidth:280}}>
          <span className="input-group-text bg-white"><i className="bi bi-search text-muted"></i></span>
          <input className="form-control" placeholder="Search name or phone..."
            value={search} onChange={e => setSearch(e.target.value)}/>
        </div>
        <div className="btn-group">
          {['active','paused','stopped'].map(s => (
            <button key={s} onClick={() => setFilter(s)}
              className={`btn btn-sm ${filterStatus===s?'btn-primary':'btn-outline-secondary'}`}>
              {s.charAt(0).toUpperCase()+s.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Cards */}
      {loading ? (
        <div className="tb-loading"><div className="spinner-border text-primary"/></div>
      ) : (
        <div className="row g-3">
          {customers.map(c => (
            <div key={c._id} className="col-12 col-md-6 col-lg-4">
              <div className="card stat-card h-100" style={{borderTop:`3px solid ${c.status==='active'?'#22c55e':c.status==='paused'?'#f59e0b':'#ef4444'}`}}>
                <div className="card-body">
                  {/* Top */}
                  <div className="d-flex justify-content-between align-items-start mb-3">
                    <div>
                      <h6 className="fw-bold mb-1">{c.name}</h6>
                      <small className="text-muted"><i className="bi bi-phone me-1"></i>{c.phone}</small>
                    </div>
                    <span className={`badge rounded-pill px-3 py-2 ${badgeMap[c.status]}`}>
                      {c.status}
                    </span>
                  </div>

                  {/* Details Grid */}
                  <div className="row g-2 mb-3">
                    {[
                      {label:'Area',    value: c.address?.area||'N/A'},
                      {label:'Meal',    value: c.plan?.type==='veg'?'🥗 Veg':'🍗 Non-Veg'},
                      {label:'Monthly', value: `₹${c.plan?.pricePerMonth}`, bold:true},
                      {label:'Timing',  value: c.plan?.meals},
                    ].map(d => (
                      <div key={d.label} className="col-6">
                        <div className="rounded p-2" style={{background:'#FFF8F0'}}>
                          <div style={{fontSize:'.68rem',color:'#888'}}>{d.label}</div>
                          <div className={`${d.bold?'fw-bold text-primary':''}`} style={{fontSize:'.85rem'}}>{d.value}</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="d-flex gap-2">
                    <button className="btn btn-sm btn-outline-primary flex-fill" onClick={() => handleEdit(c)}>
                      <i className="bi bi-pencil me-1"></i>Edit
                    </button>
                    <button onClick={() => toggleStatus(c._id, c.status)}
                      className={`btn btn-sm flex-fill ${c.status==='active'?'btn-outline-warning':'btn-outline-success'}`}>
                      <i className={`bi bi-${c.status==='active'?'pause':'play'}-circle me-1`}></i>
                      {c.status==='active'?'Pause':'Activate'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {!customers.length && (
            <div className="col-12 text-center py-5 text-muted">
              <i className="bi bi-people fs-1 d-block mb-2"></i>
              No customers found. Add your first customer!
            </div>
          )}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold">
                  <i className={`bi bi-person-${editId?'gear':'plus'} me-2 text-primary`}></i>
                  {editId?'Edit Customer':'Add Customer'}
                </h5>
                <button className="btn-close" onClick={() => setShowModal(false)}/>
              </div>
              <div className="modal-body">
                <form id="customerForm" onSubmit={handleSubmit}>
                  <div className="row g-3">
                    <div className="col-12">
                      <label className="form-label fw-semibold small">Name *</label>
                      <input className="form-control" placeholder="Customer name"
                        value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} required/>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold small">Phone *</label>
                      <input className="form-control" placeholder="9876543210" maxLength={10}
                        value={form.phone} onChange={e => setForm(f=>({...f,phone:e.target.value}))} required/>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold small">Area</label>
                      <input className="form-control" placeholder="Anna Nagar"
                        value={form.address.area} onChange={e => setAddr('area',e.target.value)}/>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold small">Meal Type</label>
                      <select className="form-select" value={form.plan.type} onChange={e => setPlan('type',e.target.value)}>
                        <option value="veg">🥗 Veg</option>
                        <option value="non-veg">🍗 Non-Veg</option>
                        <option value="both">Both</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold small">Timing</label>
                      <select className="form-select" value={form.plan.meals} onChange={e => setPlan('meals',e.target.value)}>
                        <option value="lunch">Lunch</option>
                        <option value="dinner">Dinner</option>
                        <option value="both">Both</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold small">Monthly Price (₹) *</label>
                      <div className="input-group">
                        <span className="input-group-text">₹</span>
                        <input type="number" className="form-control" placeholder="1500"
                          value={form.plan.pricePerMonth} onChange={e => setPlan('pricePerMonth',e.target.value)} required/>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label fw-semibold small">Start Date *</label>
                      <input type="date" className="form-control"
                        value={form.startDate} onChange={e => setForm(f=>({...f,startDate:e.target.value}))} required/>
                    </div>
                    <div className="col-12">
                      <label className="form-label fw-semibold small">Notes</label>
                      <textarea className="form-control" rows={2} placeholder="Any special notes..."
                        value={form.notes} onChange={e => setForm(f=>({...f,notes:e.target.value}))}/>
                    </div>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" form="customerForm" className="btn btn-primary fw-semibold">
                  <i className={`bi bi-${editId?'check':'plus'}-circle me-2`}></i>
                  {editId?'Update Customer':'Add Customer'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;

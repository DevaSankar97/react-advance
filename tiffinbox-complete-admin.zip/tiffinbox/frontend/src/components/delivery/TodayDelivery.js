import React, { useState, useEffect } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

const TodayDelivery = () => {
  const [data, setData]         = useState(null);
  const [loading, setLoading]   = useState(true);
  const [marking, setMarking]   = useState({});
  const [search, setSearch]     = useState('');

  const fetchToday = async () => {
    try {
      const res = await axios.get('/api/delivery/today');
      setData(res.data);
    } catch { toast.error('Failed to load delivery list'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchToday(); }, []);

  const markDelivery = async (customerId, status) => {
    setMarking(p => ({...p,[customerId]:true}));
    try {
      await axios.post('/api/delivery/mark', { customerId, status });
      toast.success(`Marked as ${status}!`);
      fetchToday();
    } catch { toast.error('Failed to update'); }
    finally { setMarking(p => ({...p,[customerId]:false})); }
  };

  const markAll = async () => {
    try {
      const res = await axios.post('/api/delivery/mark-all');
      toast.success(res.data.message);
      fetchToday();
    } catch { toast.error('Failed to mark all'); }
  };

  const badgeClass = { delivered:'badge-delivered', pending:'badge-pending', skipped:'badge-skipped', holiday:'badge-holiday' };

  const filtered = data?.deliveryList?.filter(d =>
    !search || d.customer.name.toLowerCase().includes(search.toLowerCase()) ||
    d.customer.phone.includes(search)
  ) || [];

  if (loading) return (
    <div className="tb-loading">
      <div className="spinner-border text-primary mb-2"/>
      <span>Loading deliveries...</span>
    </div>
  );

  const { summary } = data || {};

  return (
    <div>
      {/* Header */}
      <div className="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1"><i className="bi bi-bicycle me-2 text-primary"></i>Today's Delivery</h4>
          <p className="text-muted small mb-0">
            {new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}
          </p>
        </div>
        <button className="btn btn-success fw-semibold" onClick={markAll}>
          <i className="bi bi-check-all me-2"></i>Mark All Delivered
        </button>
      </div>

      {/* Summary Cards */}
      <div className="row g-3 mb-4">
        {[
          {label:'Total',     value:summary?.total,     color:'#6366f1', bg:'#e0e7ff'},
          {label:'Delivered', value:summary?.delivered, color:'#22c55e', bg:'#dcfce7'},
          {label:'Pending',   value:summary?.pending,   color:'#f59e0b', bg:'#fef9c3'},
          {label:'Skipped',   value:summary?.skipped,   color:'#ef4444', bg:'#fee2e2'},
        ].map(s => (
          <div key={s.label} className="col-6 col-md-3">
            <div className="card stat-card text-center" style={{borderTop:`3px solid ${s.color}`}}>
              <div className="card-body py-3">
                <h3 className="fw-bold mb-0" style={{color:s.color}}>{s.value||0}</h3>
                <small className="text-muted">{s.label}</small>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="mb-3">
        <div className="input-group" style={{maxWidth:320}}>
          <span className="input-group-text bg-white"><i className="bi bi-search text-muted"></i></span>
          <input className="form-control" placeholder="Search customer name or phone..."
            value={search} onChange={e => setSearch(e.target.value)}/>
        </div>
      </div>

      {/* Table */}
      <div className="card stat-card">
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table tb-table align-middle mb-0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Customer</th>
                  <th>Area</th>
                  <th>Meal Type</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(({customer, status}, i) => (
                  <tr key={customer._id}>
                    <td className="text-muted small">{i+1}</td>
                    <td>
                      <div className="fw-semibold">{customer.name}</div>
                      <small className="text-muted"><i className="bi bi-phone me-1"></i>{customer.phone}</small>
                    </td>
                    <td><small className="text-muted">{customer.area||'N/A'}</small></td>
                    <td>
                      <span className={`badge rounded-pill ${customer.mealType==='veg'?'text-bg-success':'text-bg-danger'}`}
                        style={{fontSize:'.72rem'}}>
                        {customer.mealType==='veg'?'🥗 Veg':'🍗 Non-Veg'}
                      </span>
                    </td>
                    <td>
                      <span className={`badge rounded-pill px-3 py-2 ${badgeClass[status]||'badge-pending'}`}>
                        {status==='delivered'?'✅ Delivered':status==='skipped'?'❌ Skipped':status==='holiday'?'🏖 Holiday':'⏳ Pending'}
                      </span>
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button className="btn btn-outline-success" disabled={marking[customer._id]||status==='delivered'}
                          onClick={() => markDelivery(customer._id,'delivered')} title="Delivered">
                          <i className="bi bi-check-lg"></i>
                        </button>
                        <button className="btn btn-outline-danger" disabled={marking[customer._id]||status==='skipped'}
                          onClick={() => markDelivery(customer._id,'skipped')} title="Skipped">
                          <i className="bi bi-x-lg"></i>
                        </button>
                        <button className="btn btn-outline-secondary" disabled={marking[customer._id]||status==='holiday'}
                          onClick={() => markDelivery(customer._id,'holiday')} title="Holiday">
                          <i className="bi bi-umbrella"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!filtered.length && (
              <div className="text-center py-5 text-muted">
                <i className="bi bi-inbox fs-1 d-block mb-2"></i>
                No customers found. Add customers to get started!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TodayDelivery;

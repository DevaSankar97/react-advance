import React, { useState, useEffect } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { NavigationContainer }          from '@react-navigation/native';
import { createBottomTabNavigator }     from '@react-navigation/bottom-tabs';
import { createStackNavigator }         from '@react-navigation/stack';
import { GestureHandlerRootView }       from 'react-native-gesture-handler';
import { SafeAreaProvider }             from 'react-native-safe-area-context';
import * as SplashScreen               from 'expo-splash-screen';
import { StatusBar }                   from 'expo-status-bar';

import { AppProvider, useApp }         from './src/context/AppContext';
import { T, BADGES }                   from './src/utils/theme';

import HomeScreen                      from './src/screens/HomeScreen';
import { CalendarScreen, StatsScreen, HabitsScreen, ProfileScreen } from './src/screens/Screens';
import { PremiumScreen, HabitDetailScreen }                         from './src/screens/PremiumScreens';
import AddHabitModal                   from './src/components/AddHabitModal';

const Tab   = createBottomTabNavigator();
const Stack = createStackNavigator();

const TABS = [
  { name:'Home',     icon:'🏠', label:'Today'    },
  { name:'Habits',   icon:'✅', label:'Habits'   },
  { name:'Calendar', icon:'📅', label:'Calendar' },
  { name:'Stats',    icon:'📊', label:'Stats'    },
  { name:'Profile',  icon:'👤', label:'Profile'  },
];

function AddHabitScreen({ navigation }) {
  const app = useApp();
  return (
    <AddHabitModal
      visible
      onClose={() => navigation.goBack()}
      onAdd={(data) => { app.addHabit(data); navigation.goBack(); }}
    />
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: T.card,
          borderTopColor:  T.border,
          borderTopWidth:  1,
          height:          64,
          paddingBottom:   8,
        },
        tabBarIcon: ({ focused }) => {
          const t = TABS.find(x => x.name === route.name);
          return <Text style={{ fontSize: 22 }}>{t?.icon}</Text>;
        },
        tabBarLabel: ({ focused }) => {
          const t = TABS.find(x => x.name === route.name);
          return <Text style={{ fontSize:11, fontWeight:focused?'800':'400', color:focused?T.primary:T.dim }}>{t?.label}</Text>;
        },
      })}
    >
      <Tab.Screen name="Home"     component={HomeScreen}/>
      <Tab.Screen name="Habits"   component={HabitsScreen}/>
      <Tab.Screen name="Calendar" component={CalendarScreen}/>
      <Tab.Screen name="Stats"    component={StatsScreen}/>
      <Tab.Screen name="Profile"  component={ProfileScreen}/>
    </Tab.Navigator>
  );
}

function AppContent() {
  const { loaded } = useApp();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (loaded) {
      setTimeout(async () => {
        setReady(true);
        try { await SplashScreen.hideAsync(); } catch {}
      }, 300);
    }
  }, [loaded]);

  if (!ready) return (
    <View style={{ flex:1, backgroundColor:T.bg, alignItems:'center', justifyContent:'center' }}>
      <Text style={{ fontSize:56, marginBottom:16 }}>✨</Text>
      <Text style={{ color:T.primary, fontSize:26, fontWeight:'800', marginBottom:8 }}>StreakIn</Text>
      <Text style={{ color:T.muted, fontSize:14, marginBottom:24 }}>Build habits that stick</Text>
      <ActivityIndicator color={T.primary} size="large"/>
    </View>
  );

  return (
    <NavigationContainer
      theme={{
        dark: true,
        colors: {
          primary:      T.primary,
          background:   T.bg,
          card:         T.card,
          text:         T.text,
          border:       T.border,
          notification: T.danger,
        },
      }}
    >
      <Stack.Navigator screenOptions={{ headerShown:false }}>
        <Stack.Screen name="Main"        component={MainTabs}/>
        <Stack.Screen name="AddHabit"    component={AddHabitScreen}    options={{ presentation:'modal' }}/>
        <Stack.Screen name="HabitDetail" component={HabitDetailScreen}/>
        <Stack.Screen name="Premium"     component={PremiumScreen}     options={{ presentation:'modal' }}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  useEffect(() => {
    SplashScreen.preventAutoHideAsync().catch(() => {});
  }, []);

  return (
    <GestureHandlerRootView style={{ flex:1 }}>
      <SafeAreaProvider>
        <StatusBar style="light"/>
        <AppProvider>
          <AppContent/>
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

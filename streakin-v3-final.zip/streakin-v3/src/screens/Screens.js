import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Dimensions, FlatList, Switch, Alert, TextInput,
} from 'react-native';
import { useApp, dateStr } from '../context/AppContext';
import { T, LANGS, BADGES } from '../utils/theme';
import { getLevel, getNextLevel, getLevelProgress, LEVELS } from '../utils/xp';
import * as Notifications from 'expo-notifications';
import { scheduleHabitReminders, requestPermissions } from '../utils/notifications';

const { width } = Dimensions.get('window');

function getDaysInMonth(y, m) { return new Date(y, m+1, 0).getDate(); }
function getFirstDay(y, m)    { return new Date(y, m, 1).getDay(); }

// ══════════════════════════════
// CALENDAR SCREEN
// ══════════════════════════════
export function CalendarScreen() {
  const app = useApp();
  const [month,    setMonth]   = useState(new Date().getMonth());
  const [year,     setYear]    = useState(new Date().getFullYear());
  const [selDay,   setSelDay]  = useState(null);
  const [selHabit, setSelHab]  = useState(null); // filter by habit

  const daysInMonth = getDaysInMonth(year, month);
  const firstDay    = getFirstDay(year, month);
  const monthName   = new Date(year, month).toLocaleDateString('en-IN', { month:'long', year:'numeric' });
  const today       = new Date();

  const getDayPct = (day) => {
    const d = new Date(year, month, day);
    if (!app.habits.length) return 0;
    const filtered = selHabit ? app.habits.filter(h => h.id === selHabit) : app.habits;
    if (!filtered.length) return 0;
    const done = filtered.filter(h => app.isDone(h.id, d)).length;
    return done / filtered.length;
  };

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const selDate  = selDay ? new Date(year, month, selDay) : null;
  const habitsForDay = selDate ? app.habits.map(h => ({
    ...h, done: app.isDone(h.id, selDate), qty: app.getQuantity(h.id, selDate)
  })) : [];

  return (
    <View style={{ flex:1, backgroundColor:T.bg }}>
      <View style={{ paddingHorizontal:16, paddingTop:56, paddingBottom:8 }}>
        <Text style={{ color:T.text, fontSize:22, fontWeight:'800', marginBottom:16 }}>Calendar 📅</Text>

        {/* Month nav */}
        <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
          <TouchableOpacity onPress={() => { if(month===0){setMonth(11);setYear(y=>y-1);}else setMonth(m=>m-1); setSelDay(null); }}>
            <Text style={{ color:T.primary, fontSize:26, fontWeight:'700' }}>‹</Text>
          </TouchableOpacity>
          <Text style={{ color:T.text, fontSize:17, fontWeight:'800' }}>{monthName}</Text>
          <TouchableOpacity onPress={() => { if(month===11){setMonth(0);setYear(y=>y+1);}else setMonth(m=>m+1); setSelDay(null); }}>
            <Text style={{ color:T.primary, fontSize:26, fontWeight:'700' }}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Habit filter */}
        {app.habits.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom:12 }}>
            <View style={{ flexDirection:'row', gap:8 }}>
              <TouchableOpacity onPress={() => setSelHab(null)}
                style={[calS.filterBtn, !selHabit && { backgroundColor:T.primary, borderColor:T.primary }]}>
                <Text style={{ color:!selHabit?'#fff':T.muted, fontWeight:'600', fontSize:12 }}>🔄 All</Text>
              </TouchableOpacity>
              {app.habits.map(h => (
                <TouchableOpacity key={h.id} onPress={() => setSelHab(selHabit===h.id?null:h.id)}
                  style={[calS.filterBtn, selHabit===h.id && { backgroundColor:h.color+'30', borderColor:h.color }]}>
                  <Text style={{ color:selHabit===h.id?h.color:T.muted, fontWeight:'600', fontSize:12 }}>{h.emoji} {h.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        )}

        {/* Day headers */}
        <View style={{ flexDirection:'row', marginBottom:6 }}>
          {['S','M','T','W','T','F','S'].map((d,i) => (
            <View key={i} style={{ flex:1, alignItems:'center' }}>
              <Text style={{ color:T.dim, fontSize:12, fontWeight:'700' }}>{d}</Text>
            </View>
          ))}
        </View>

        {/* Grid */}
        <View style={{ flexDirection:'row', flexWrap:'wrap' }}>
          {cells.map((day, i) => {
            if (!day) return <View key={'e'+i} style={{ width:`${100/7}%`, aspectRatio:1 }}/>;
            const pct     = getDayPct(day);
            const isToday = day===today.getDate()&&month===today.getMonth()&&year===today.getFullYear();
            const isSel   = day === selDay;
            const isFut   = new Date(year, month, day) > today;
            const bg      = isSel ? T.primary : pct===1 ? T.success+'40' : pct>0.5 ? T.primary+'30' : pct>0 ? T.primary+'15' : 'transparent';
            return (
              <TouchableOpacity key={day} style={{ width:`${100/7}%`, aspectRatio:1, alignItems:'center', justifyContent:'center' }}
                onPress={() => setSelDay(isSel ? null : day)}>
                <View style={{ width:34, height:34, borderRadius:17, alignItems:'center', justifyContent:'center', backgroundColor:bg, borderWidth:isToday?2:0, borderColor:T.primary }}>
                  <Text style={{ color:isSel?'#fff':isToday?T.primary:isFut?T.border:pct===1?T.success:T.text, fontSize:13, fontWeight:isToday||isSel?'800':'500' }}>{day}</Text>
                </View>
                {pct>0&&!isSel&&<View style={{ width:4,height:4,borderRadius:2,backgroundColor:pct===1?T.success:T.primary,marginTop:1 }}/>}
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Legend */}
        <View style={{ flexDirection:'row', justifyContent:'center', gap:16, marginTop:10, marginBottom:4 }}>
          {[{c:T.success+'40',l:'All done'},{c:T.primary+'30',l:'Partial'},{c:T.border,l:'Missed'}].map(l=>(
            <View key={l.l} style={{ flexDirection:'row', alignItems:'center', gap:4 }}>
              <View style={{ width:12,height:12,borderRadius:6,backgroundColor:l.c }}/>
              <Text style={{ color:T.dim, fontSize:11 }}>{l.l}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Selected day detail */}
      {selDay && (
        <ScrollView style={{ flex:1 }} contentContainerStyle={{ padding:16, paddingBottom:100 }}>
          <Text style={{ color:T.muted, fontSize:12, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:12 }}>
            {selDate?.toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'})}
          </Text>
          <View style={{ flexDirection:'row', gap:8, marginBottom:12 }}>
            <View style={{ flex:1, backgroundColor:T.success+'15', borderRadius:12, padding:12, alignItems:'center', borderWidth:1, borderColor:T.success+'30' }}>
              <Text style={{ color:T.success, fontSize:20, fontWeight:'800' }}>{habitsForDay.filter(h=>h.done).length}</Text>
              <Text style={{ color:T.dim, fontSize:11 }}>Completed</Text>
            </View>
            <View style={{ flex:1, backgroundColor:T.danger+'15', borderRadius:12, padding:12, alignItems:'center', borderWidth:1, borderColor:T.danger+'30' }}>
              <Text style={{ color:T.danger, fontSize:20, fontWeight:'800' }}>{habitsForDay.filter(h=>!h.done).length}</Text>
              <Text style={{ color:T.dim, fontSize:11 }}>Missed</Text>
            </View>
          </View>
          {habitsForDay.map(h => (
            <View key={h.id} style={{ flexDirection:'row', alignItems:'center', backgroundColor:T.card, borderRadius:14, padding:14, marginBottom:8, borderWidth:1.5, borderColor:h.done?h.color+'50':T.border, gap:12 }}>
              <View style={{ width:36,height:36,borderRadius:18,alignItems:'center',justifyContent:'center',backgroundColor:h.done?h.color:'transparent',borderWidth:2,borderColor:h.done?h.color:T.muted }}>
                {h.done&&<Text style={{ color:'#fff',fontSize:16,fontWeight:'800' }}>✓</Text>}
              </View>
              <Text style={{ fontSize:18 }}>{h.emoji}</Text>
              <View style={{ flex:1 }}>
                <Text style={{ color:h.done?T.dim:T.text, fontWeight:'600', textDecorationLine:h.done?'line-through':'none' }}>{h.name}</Text>
                {h.type==='quantity'&&<Text style={{ color:T.dim, fontSize:12, marginTop:2 }}>{h.qty}/{h.target} {h.unit}</Text>}
              </View>
              <Text style={{ fontSize:20 }}>{h.done?'✅':'❌'}</Text>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

// ══════════════════════════════
// STATS SCREEN
// ══════════════════════════════
export function StatsScreen() {
  const app = useApp();
  const prog       = app.todayProgress();
  const totalDone  = app.habits.reduce((s,h) => s+app.getTotal(h.id), 0);
  const bestEver   = app.habits.reduce((b,h) => Math.max(b,app.getBest(h.id)), 0);
  const avgRate    = app.habits.length ? Math.round(app.habits.reduce((s,h)=>s+app.getMonthRate(h.id),0)/app.habits.length) : 0;

  // 4-week bar chart
  const weekly = Array.from({length:4},(_,wi) => {
    let done=0, total=0;
    for(let d=6;d>=0;d--){const dt=new Date();dt.setDate(dt.getDate()-wi*7-d);if(dt<=new Date()){total+=app.habits.length;done+=app.habits.filter(h=>app.isDone(h.id,dt)).length;}}
    return { week:`W${4-wi}`, pct:total?Math.round(done/total*100):0 };
  }).reverse();

  return (
    <ScrollView style={{ flex:1, backgroundColor:T.bg }} contentContainerStyle={{ padding:16, paddingTop:56, paddingBottom:100 }}>
      <Text style={{ color:T.text, fontSize:22, fontWeight:'800', marginBottom:16 }}>Analytics 📊</Text>

      {/* Top 4 stats */}
      <View style={{ flexDirection:'row', gap:8, marginBottom:12 }}>
        {[
          {icon:'✅',label:'Today',    value:`${prog.done}/${prog.total}`, color:T.success, bg:'rgba(34,197,94,.15)'},
          {icon:'📅',label:'30d Rate', value:`${avgRate}%`,               color:T.primary, bg:'rgba(99,102,241,.15)'},
          {icon:'🔥',label:'Best',     value:bestEver,                    color:T.warning, bg:'rgba(245,158,11,.15)'},
          {icon:'📊',label:'Total',    value:totalDone,                   color:T.pink,    bg:'rgba(236,72,153,.15)'},
        ].map(s=>(
          <View key={s.label} style={{ flex:1, backgroundColor:s.bg, borderRadius:14, padding:10, alignItems:'center', borderWidth:1, borderColor:s.color+'30' }}>
            <Text style={{ fontSize:18 }}>{s.icon}</Text>
            <Text style={{ color:s.color, fontSize:17, fontWeight:'800', marginTop:4 }}>{s.value}</Text>
            <Text style={{ color:T.dim, fontSize:10, marginTop:2 }}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* 4-week chart */}
      <View style={{ backgroundColor:T.card, borderRadius:16, padding:16, marginBottom:12, borderWidth:1, borderColor:T.border }}>
        <Text style={{ color:T.muted, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:12 }}>WEEKLY COMPLETION TREND</Text>
        <View style={{ flexDirection:'row', alignItems:'flex-end', height:80, gap:8 }}>
          {weekly.map((w,i) => (
            <View key={i} style={{ flex:1, alignItems:'center', gap:4 }}>
              <Text style={{ color:T.dim, fontSize:10 }}>{w.pct}%</Text>
              <View style={{ width:'100%', height:60, justifyContent:'flex-end' }}>
                <View style={{ width:'100%', height:`${Math.max(4,w.pct)}%`, borderRadius:4, minHeight:4,
                  backgroundColor:w.pct>=70?T.success:w.pct>=40?T.warning:T.danger }}/>
              </View>
              <Text style={{ color:T.dim, fontSize:10 }}>{w.week}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Per habit */}
      {app.habits.length===0 ? (
        <View style={{ alignItems:'center', paddingVertical:60 }}>
          <Text style={{ fontSize:48 }}>📊</Text>
          <Text style={{ color:T.muted, fontSize:15, marginTop:12 }}>Add habits to see stats!</Text>
        </View>
      ) : app.habits.map(h => {
        const streak=app.getStreak(h.id), best=app.getBest(h.id), total=app.getTotal(h.id), rate=app.getMonthRate(h.id);
        return (
          <View key={h.id} style={{ backgroundColor:T.card, borderRadius:16, padding:16, marginBottom:12, borderWidth:1, borderColor:T.border, borderLeftWidth:4, borderLeftColor:h.color }}>
            <View style={{ flexDirection:'row', alignItems:'center', gap:10, marginBottom:12 }}>
              <Text style={{ fontSize:24 }}>{h.emoji}</Text>
              <Text style={{ fontSize:15, fontWeight:'700', color:T.text, flex:1 }}>{h.name}</Text>
              {streak>=7&&<View style={{ backgroundColor:T.warning+'25', paddingHorizontal:8, paddingVertical:3, borderRadius:10 }}><Text style={{ color:T.warning, fontSize:11, fontWeight:'700' }}>🔥 {streak}</Text></View>}
            </View>
            <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:12 }}>
              {[{l:'Streak',v:streak,c:T.primary},{l:'Best',v:best,c:T.success},{l:'Total',v:total,c:T.warning},{l:'30d',v:`${rate}%`,c:T.pink}].map(s=>(
                <View key={s.l} style={{ alignItems:'center' }}>
                  <Text style={{ fontSize:20, fontWeight:'800', color:s.c }}>{s.v}</Text>
                  <Text style={{ fontSize:10, color:T.dim, marginTop:2 }}>{s.l}</Text>
                </View>
              ))}
            </View>
            {/* Week progress */}
            <View style={{ marginBottom:10 }}>
              <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:4 }}>
                <Text style={{ color:T.dim, fontSize:11 }}>This week</Text>
                <Text style={{ color:T.primary, fontSize:11, fontWeight:'600' }}>{app.getWeekDone(h.id)}/7</Text>
              </View>
              <View style={{ height:8, backgroundColor:T.border, borderRadius:4, overflow:'hidden' }}>
                <View style={{ height:'100%', width:`${app.getWeekDone(h.id)/7*100}%`, backgroundColor:h.color, borderRadius:4 }}/>
              </View>
            </View>
            {/* 7 day dots */}
            <View style={{ flexDirection:'row', gap:4 }}>
              {app.getWeek(h.id).map((d,i) => (
                <View key={i} style={{ flex:1, alignItems:'center', gap:3 }}>
                  <View style={{ width:'100%', height:d.done?20:5, borderRadius:4, backgroundColor:d.done?h.color:T.border, opacity:d.done?1:0.4 }}/>
                  <Text style={{ color:T.dim, fontSize:8 }}>{d.label}</Text>
                </View>
              ))}
            </View>
            {/* 28 day heatmap */}
            <View style={{ marginTop:10 }}>
              <Text style={{ color:T.dim, fontSize:10, marginBottom:6 }}>Last 28 days</Text>
              <View style={{ flexDirection:'row', flexWrap:'wrap', gap:3 }}>
                {Array.from({length:28},(_,i)=>{const d=new Date();d.setDate(d.getDate()-27+i);const done=app.isDone(h.id,d);return(
                  <View key={i} style={{ width:(width-64)/28, aspectRatio:1, borderRadius:2, backgroundColor:done?h.color:T.border, opacity:done?1:0.3 }}/>
                );})}
              </View>
            </View>
          </View>
        );
      })}
    </ScrollView>
  );
}

// ══════════════════════════════
// HABITS SCREEN
// ══════════════════════════════
export function HabitsScreen({ navigation }) {
  const app = useApp();
  const active = app.habits.filter(h => !h.archived);

  return (
    <View style={{ flex:1, backgroundColor:T.bg }}>
      <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal:16, paddingTop:56, paddingBottom:16, borderBottomWidth:1, borderBottomColor:T.border }}>
        <View>
          <Text style={{ fontSize:22, fontWeight:'800', color:T.text }}>My Habits</Text>
          <Text style={{ color:T.dim, fontSize:13, marginTop:2 }}>{active.length} habits · long press for details</Text>
        </View>
        <TouchableOpacity style={{ width:40,height:40,borderRadius:20,backgroundColor:T.primary,alignItems:'center',justifyContent:'center' }} onPress={() => navigation.navigate('AddHabit')}>
          <Text style={{ color:'#fff', fontSize:22, lineHeight:26 }}>+</Text>
        </TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={{ padding:16, paddingBottom:100 }}>
        {active.length===0 ? (
          <View style={{ alignItems:'center', paddingVertical:60 }}>
            <Text style={{ fontSize:56, marginBottom:12 }}>🌱</Text>
            <Text style={{ color:T.muted, fontSize:16, textAlign:'center' }}>No habits yet!</Text>
            <TouchableOpacity style={{ marginTop:16, backgroundColor:T.primary, paddingHorizontal:28, paddingVertical:13, borderRadius:14 }} onPress={() => navigation.navigate('AddHabit')}>
              <Text style={{ color:'#fff', fontWeight:'800', fontSize:15 }}>+ Add First Habit</Text>
            </TouchableOpacity>
          </View>
        ) : active.map(h => (
          <TouchableOpacity key={h.id} activeOpacity={0.8}
            onLongPress={() => navigation.navigate('HabitDetail', { habit:h })}
            style={{ flexDirection:'row', alignItems:'center', backgroundColor:T.card, borderRadius:16, padding:14, marginBottom:10, borderWidth:1, borderColor:T.border, gap:12 }}>
            <View style={{ width:48,height:48,borderRadius:24,backgroundColor:h.color+'25',alignItems:'center',justifyContent:'center' }}>
              <Text style={{ fontSize:24 }}>{h.emoji}</Text>
            </View>
            <View style={{ flex:1 }}>
              <Text style={{ fontSize:15, fontWeight:'700', color:T.text, marginBottom:3 }}>{h.name}</Text>
              {h.motivation ? <Text style={{ color:T.dim, fontSize:11, fontStyle:'italic', marginBottom:4 }}>"{h.motivation}"</Text> : null}
              <Text style={{ fontSize:12, color:T.dim, marginBottom:6 }}>🔥 {app.getStreak(h.id)} streak · ✅ {app.getTotal(h.id)} total · {h.type==='quantity'?`📏 ${h.unit}`:h.timeOfDay==='morning'?'🌅':h.timeOfDay==='evening'?'🌆':'🔄'}</Text>
              <View style={{ flexDirection:'row', gap:3 }}>
                {app.getWeek(h.id).map((d,i) => (
                  <View key={i} style={{ alignItems:'center', gap:2 }}>
                    <View style={{ width:16,height:16,borderRadius:4,backgroundColor:d.done?h.color:T.border,opacity:d.done?1:0.35 }}/>
                    <Text style={{ color:T.dim, fontSize:7 }}>{d.label}</Text>
                  </View>
                ))}
              </View>
            </View>
            <TouchableOpacity onPress={() => { app.deleteHabit(h.id); }} style={{ padding:8 }}>
              <Text style={{ color:T.danger, fontSize:18 }}>🗑</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}
        {active.length>=5&&!app.isPro&&(
          <TouchableOpacity style={{ backgroundColor:T.primary+'15', borderRadius:16, padding:16, borderWidth:1, borderColor:T.primary+'40', marginTop:4 }} onPress={() => navigation.navigate('Premium')}>
            <Text style={{ color:T.primary, fontWeight:'800', textAlign:'center' }}>✨ Upgrade to Pro for unlimited habits →</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

// ══════════════════════════════
// PROFILE SCREEN
// ══════════════════════════════
export function ProfileScreen({ navigation }) {
  const app    = useApp();
  const prog   = app.todayProgress();
  const level  = getLevel(app.totalXP);
  const nextLvl= getNextLevel(app.totalXP);
  const lvlPct = getLevelProgress(app.totalXP);

  return (
    <ScrollView style={{ flex:1, backgroundColor:T.bg }} contentContainerStyle={{ padding:16, paddingTop:56, paddingBottom:100 }}>
      <Text style={{ color:T.text, fontSize:22, fontWeight:'800', marginBottom:16 }}>Profile 👤</Text>

      {/* Profile card */}
      <View style={{ backgroundColor:'#1e1b4b', borderRadius:20, padding:20, marginBottom:16, alignItems:'center' }}>
        <View style={{ width:80,height:80,borderRadius:40,backgroundColor:'#312e81',alignItems:'center',justifyContent:'center',marginBottom:12,borderWidth:3,borderColor:T.primary+'60' }}>
          <Text style={{ fontSize:36 }}>{level.icon}</Text>
        </View>
        <Text style={{ color:T.text, fontSize:18, fontWeight:'800' }}>{app.userName||'StreakIn User'}</Text>
        <Text style={{ color:level.color, fontSize:14, fontWeight:'700', marginTop:4 }}>{level.icon} {level.name}</Text>
        {/* XP bar */}
        <View style={{ width:'100%', marginTop:14 }}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:6 }}>
            <Text style={{ color:T.dim, fontSize:12 }}>{app.totalXP} XP</Text>
            {nextLvl&&<Text style={{ color:T.dim, fontSize:12 }}>{nextLvl.minXP} XP → {nextLvl.icon} {nextLvl.name}</Text>}
          </View>
          <View style={{ height:8, backgroundColor:'rgba(255,255,255,.1)', borderRadius:4, overflow:'hidden' }}>
            <View style={{ height:'100%', width:`${lvlPct}%`, backgroundColor:level.color, borderRadius:4 }}/>
          </View>
        </View>
        <View style={{ flexDirection:'row', gap:24, marginTop:16 }}>
          {[{l:'Habits',v:app.habits.length,c:T.primary},{l:'Today',v:prog.done,c:T.success},{l:'Best 🔥',v:app.habits.reduce((b,h)=>Math.max(b,app.getStreak(h.id)),0),c:T.warning}].map(s=>(
            <View key={s.l} style={{ alignItems:'center' }}>
              <Text style={{ color:s.c, fontSize:24, fontWeight:'800' }}>{s.v}</Text>
              <Text style={{ color:T.dim, fontSize:12, marginTop:2 }}>{s.l}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Level roadmap */}
      <View style={{ backgroundColor:T.card, borderRadius:16, padding:16, marginBottom:16, borderWidth:1, borderColor:T.border }}>
        <Text style={{ color:T.muted, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:12 }}>LEVEL ROADMAP</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {LEVELS.map(l => {
            const reached = app.totalXP >= l.minXP;
            const current = level.level === l.level;
            return (
              <View key={l.level} style={{ alignItems:'center', marginRight:16, opacity:reached?1:0.4 }}>
                <View style={{ width:44,height:44,borderRadius:22,backgroundColor:reached?l.color+'30':T.border,alignItems:'center',justifyContent:'center',borderWidth:current?2:0,borderColor:l.color }}>
                  <Text style={{ fontSize:20 }}>{l.icon}</Text>
                </View>
                <Text style={{ color:reached?l.color:T.dim, fontSize:10, fontWeight:'700', marginTop:4, textAlign:'center', maxWidth:60 }}>{l.name}</Text>
                <Text style={{ color:T.dim, fontSize:9, marginTop:1 }}>{l.minXP}XP</Text>
              </View>
            );
          })}
        </ScrollView>
      </View>

      {/* Pro banner */}
      <TouchableOpacity style={{ backgroundColor:T.primary+'20', borderRadius:16, padding:18, marginBottom:16, borderWidth:1, borderColor:T.primary+'50' }} onPress={() => navigation.navigate('Premium')}>
        <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center' }}>
          <View>
            <Text style={{ color:T.primary, fontWeight:'800', fontSize:16 }}>✨ Upgrade to Pro</Text>
            <Text style={{ color:'#a78bfa', fontSize:12, marginTop:2 }}>Unlimited · Reminders · Widgets</Text>
          </View>
          <View style={{ backgroundColor:T.primary, paddingHorizontal:14, paddingVertical:8, borderRadius:12 }}>
            <Text style={{ color:'#fff', fontWeight:'800' }}>₹99/mo</Text>
          </View>
        </View>
      </TouchableOpacity>

      {/* Settings */}
      <View style={{ backgroundColor:T.card, borderRadius:16, borderWidth:1, borderColor:T.border, marginBottom:16, overflow:'hidden' }}>
        <Text style={{ color:T.dim, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, padding:14, paddingBottom:8 }}>SETTINGS</Text>
        {/* Username */}
        <View style={{ flexDirection:'row', alignItems:'center', padding:14, borderBottomWidth:0.5, borderBottomColor:T.border, gap:12 }}>
          <Text style={{ fontSize:20 }}>✏️</Text>
          <Text style={{ fontSize:15, fontWeight:'500', color:T.text, flex:1 }}>Name</Text>
          <TextInput style={{ color:T.muted, fontSize:14, textAlign:'right' }} value={app.userName} onChangeText={app.setUserName} placeholder="Enter name" placeholderTextColor={T.dim}/>
        </View>
        {/* Language */}
        <TouchableOpacity style={{ flexDirection:'row', alignItems:'center', padding:14, borderBottomWidth:0.5, borderBottomColor:T.border, gap:12 }}
          onPress={() => Alert.alert('Language', 'Select Language', LANGS.map(l => ({ text:`${l.native} (${l.label})`, onPress:()=>app.setLanguage(l.code) })).concat([{text:'Cancel',style:'cancel'}]))}>
          <Text style={{ fontSize:20 }}>🌐</Text>
          <Text style={{ fontSize:15, fontWeight:'500', color:T.text, flex:1 }}>Language</Text>
          <Text style={{ color:T.dim }}>{LANGS.find(l=>l.code===app.language)?.native||'English'} ›</Text>
        </TouchableOpacity>
        {/* Forgiveness mode */}
        <View style={{ flexDirection:'row', alignItems:'center', padding:14, borderBottomWidth:0.5, borderBottomColor:T.border, gap:12 }}>
          <Text style={{ fontSize:20 }}>🛡️</Text>
          <View style={{ flex:1 }}>
            <Text style={{ fontSize:15, fontWeight:'500', color:T.text }}>Forgiveness Mode</Text>
            <Text style={{ color:T.dim, fontSize:11, marginTop:2 }}>Miss 1 day — streak doesn't break</Text>
          </View>
          <Switch value={app.forgiveMissed} onValueChange={app.setForgive} trackColor={{false:T.border,true:T.success}} thumbColor="#fff"/>
        </View>
        {/* Notifications */}
        <View style={{ flexDirection:'row', alignItems:'center', padding:14, gap:12 }}>
          <Text style={{ fontSize:20 }}>🔔</Text>
          <Text style={{ fontSize:15, fontWeight:'500', color:T.text, flex:1 }}>Notifications</Text>
          <Switch value={app.notifEnabled} onValueChange={async v => {
            if (v) { const ok = await requestPermissions(); if (!ok) { Alert.alert('Permission needed','Please enable notifications in Settings'); return; } }
            app.setNotifEnabled(v);
            if (v) scheduleHabitReminders(app.habits);
          }} trackColor={{false:T.border,true:T.primary}} thumbColor="#fff"/>
        </View>
      </View>

      <View style={{ backgroundColor:T.card, borderRadius:16, borderWidth:1, borderColor:T.border, overflow:'hidden' }}>
        <Text style={{ color:T.dim, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, padding:14, paddingBottom:8 }}>ABOUT</Text>
        <View style={{ flexDirection:'row', alignItems:'center', padding:14, borderBottomWidth:0.5, borderBottomColor:T.border, gap:12 }}>
          <Text style={{ fontSize:20 }}>📱</Text><Text style={{ fontSize:15, color:T.text, flex:1 }}>Version</Text><Text style={{ color:T.dim }}>3.0.0</Text>
        </View>
        <View style={{ flexDirection:'row', alignItems:'center', padding:14, gap:12 }}>
          <Text style={{ fontSize:20 }}>🇮🇳</Text><Text style={{ fontSize:15, color:T.text, flex:1 }}>Made in Chennai, India</Text><Text style={{ color:T.dim }}>❤️</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const calS = StyleSheet.create({
  filterBtn: { backgroundColor:T.card, borderRadius:20, paddingHorizontal:12, paddingVertical:6, borderWidth:1, borderColor:T.border },
});

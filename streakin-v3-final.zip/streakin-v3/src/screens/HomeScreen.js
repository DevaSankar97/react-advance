import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Dimensions, Share, Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Haptics from 'expo-haptics';
import { useApp, dateStr } from '../context/AppContext';
import { T, QUOTES, BADGES, TIME_OF_DAY } from '../utils/theme';
import { getLevel, getNextLevel, getLevelProgress } from '../utils/xp';
import QuantityModal from '../components/QuantityModal';

const { width } = Dimensions.get('window');

export default function HomeScreen({ navigation }) {
  const app = useApp();
  const [showQuantity, setShowQuantity] = useState(null);
  const [focusMode,    setFocusMode]    = useState(false);
  const [activeTOD,    setActiveTOD]    = useState('all'); // time of day filter

  const prog    = app.todayProgress();
  const hour    = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
  const today   = new Date().toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'long' });
  const quote   = QUOTES[new Date().getDate() % QUOTES.length];
  const level   = getLevel(app.totalXP);
  const nextLvl = getNextLevel(app.totalXP);
  const lvlPct  = getLevelProgress(app.totalXP);

  // Get current time of day
  const currentTOD = TIME_OF_DAY.find(t => t.hours.includes(hour))?.id || 'anytime';

  // Filter habits
  let displayHabits = app.habits.filter(h => !h.archived);
  if (focusMode) displayHabits = displayHabits.filter(h => !app.isDone(h.id)).slice(0, 3);
  if (activeTOD !== 'all') displayHabits = displayHabits.filter(h => h.timeOfDay === activeTOD || h.timeOfDay === 'anytime');

  const handleToggle = useCallback((h) => {
    app.toggleHabit(h.id, new Date(), (habit, date) => setShowQuantity({ habit, date }));
    try { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); } catch {}
  }, [app]);

  // WhatsApp share
  const shareProgress = async () => {
    const streak = app.habits.reduce((b, h) => Math.max(b, app.getStreak(h.id)), 0);
    const done   = app.habits.filter(h => app.isDone(h.id)).length;
    const msg = `🔥 StreakIn Daily Report\n\n✅ ${done}/${app.habits.length} habits done today\n🔥 Best streak: ${streak} days\n⭐ Level: ${level.icon} ${level.name} (${app.totalXP} XP)\n\n${app.habits.filter(h => app.isDone(h.id)).map(h => `${h.emoji} ${h.name}`).join('\n')}\n\n💪 Building habits with StreakIn — Made in India 🇮🇳`;
    try {
      await Share.share({ message: msg, title: 'My StreakIn Progress' });
    } catch {}
  };

  // Earned badges
  const earnedBadges = BADGES.filter(b => {
    if (b.id === 'first')   return Object.keys(app.completions).length >= 1;
    if (b.id === 'week7')   return app.habits.some(h => app.getStreak(h.id) >= 7);
    if (b.id === 'week14')  return app.habits.some(h => app.getStreak(h.id) >= 14);
    if (b.id === 'month30') return app.habits.some(h => app.getStreak(h.id) >= 30);
    if (b.id === 'century') return app.habits.some(h => app.getTotal(h.id) >= 100);
    if (b.id === 'perfect') return app.habits.every(h => app.isDone(h.id)) && app.habits.length > 0;
    if (b.id === 'allstar') return prog.pct === 100;
    return false;
  });

  return (
    <View style={{ flex: 1, backgroundColor: T.bg }}>
      <StatusBar style="light"/>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>

        {/* ── Hero Header ── */}
        <View style={s.hero}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start' }}>
            <View>
              <Text style={s.greeting}>{greeting} 👋</Text>
              {app.userName ? <Text style={s.userName}>{app.userName}</Text> : null}
              <Text style={s.dateText}>{today}</Text>
            </View>
            <TouchableOpacity onPress={shareProgress} style={s.shareBtn}>
              <Text style={{ fontSize: 18 }}>📤</Text>
            </TouchableOpacity>
          </View>

          {/* Progress ring + stats */}
          <View style={{ flexDirection:'row', alignItems:'center', gap:16, marginTop:16 }}>
            <View style={s.ringWrap}>
              <View style={[s.ringOuter, { borderColor: T.border }]}/>
              <View style={[s.ringOuter, { borderColor: prog.pct===100 ? T.success : T.primary, opacity: Math.max(0.15, prog.pct/100) }]}/>
              <View style={s.ringInner}>
                <Text style={[s.ringPct, { color: prog.pct===100 ? T.success : T.primary }]}>{prog.pct}%</Text>
                <Text style={s.ringLabel}>Today</Text>
              </View>
            </View>
            <View style={{ flex:1, gap:8 }}>
              <View style={{ flexDirection:'row', gap:8 }}>
                <View style={[s.statCard, { borderColor:'rgba(34,197,94,.3)', backgroundColor:'rgba(34,197,94,.1)' }]}>
                  <Text style={[s.statNum, { color:T.success }]}>{prog.done}</Text>
                  <Text style={s.statLbl}>Done ✅</Text>
                </View>
                <View style={[s.statCard, { borderColor:'rgba(245,158,11,.3)', backgroundColor:'rgba(245,158,11,.1)' }]}>
                  <Text style={[s.statNum, { color:T.warning }]}>{prog.total - prog.done}</Text>
                  <Text style={s.statLbl}>Left ⏳</Text>
                </View>
              </View>
              {/* XP bar */}
              <TouchableOpacity style={s.xpBar} onPress={() => navigation.navigate('Profile')}>
                <View style={{ flexDirection:'row', alignItems:'center', gap:6, marginBottom:4 }}>
                  <Text style={{ fontSize:14 }}>{level.icon}</Text>
                  <Text style={{ color:level.color, fontSize:12, fontWeight:'700', flex:1 }}>{level.name}</Text>
                  <Text style={{ color:T.dim, fontSize:11 }}>{app.totalXP} XP</Text>
                </View>
                <View style={{ height:5, backgroundColor:T.border, borderRadius:3, overflow:'hidden' }}>
                  <View style={{ height:'100%', width:`${lvlPct}%`, backgroundColor:level.color, borderRadius:3 }}/>
                </View>
                {nextLvl && <Text style={{ color:T.dim, fontSize:10, marginTop:3 }}>{nextLvl.minXP - app.totalXP} XP to {nextLvl.icon} {nextLvl.name}</Text>}
              </TouchableOpacity>
            </View>
          </View>

          {prog.pct===100 && (
            <View style={s.allDone}>
              <Text style={{ color:T.success, fontWeight:'800', fontSize:16 }}>🎉 Perfect day! All habits done!</Text>
            </View>
          )}
        </View>

        {/* ── Controls: Focus + Time filter ── */}
        <View style={{ paddingHorizontal:16, marginBottom:12, gap:10 }}>
          {/* Focus mode toggle */}
          <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center' }}>
            <View style={{ flexDirection:'row', alignItems:'center', gap:8 }}>
              <Text style={{ color:T.muted, fontSize:12, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5 }}>TODAY'S HABITS</Text>
              {app.forgiveMissed && <View style={{ backgroundColor:'rgba(34,197,94,.2)', paddingHorizontal:6, paddingVertical:2, borderRadius:6 }}><Text style={{ color:T.success, fontSize:10, fontWeight:'700' }}>🛡️ Forgiven</Text></View>}
            </View>
            <View style={{ flexDirection:'row', gap:8 }}>
              <TouchableOpacity onPress={() => setFocusMode(f => !f)}
                style={[s.controlBtn, focusMode && { backgroundColor:T.warning+'30', borderColor:T.warning }]}>
                <Text style={{ color: focusMode ? T.warning : T.muted, fontSize:12, fontWeight:'600' }}>🎯 Focus</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.controlBtn} onPress={() => navigation.navigate('AddHabit')}>
                <Text style={{ color:'#fff', fontSize:18, lineHeight:22 }}>+</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Time of day filter */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{ flexDirection:'row', gap:8 }}>
              <TouchableOpacity onPress={() => setActiveTOD('all')}
                style={[s.todBtn, activeTOD==='all' && { backgroundColor:T.primary, borderColor:T.primary }]}>
                <Text style={{ color: activeTOD==='all' ? '#fff' : T.muted, fontSize:12, fontWeight:'600' }}>🔄 All</Text>
              </TouchableOpacity>
              {TIME_OF_DAY.filter(t => t.id !== 'anytime').map(t => (
                <TouchableOpacity key={t.id} onPress={() => setActiveTOD(t.id)}
                  style={[s.todBtn, activeTOD===t.id && { backgroundColor:T.primary, borderColor:T.primary },
                    currentTOD===t.id && activeTOD!==t.id && { borderColor:T.warning }]}>
                  <Text style={{ color: activeTOD===t.id ? '#fff' : T.muted, fontSize:12, fontWeight:'600' }}>
                    {t.icon} {t.label}
                    {currentTOD===t.id ? ' ←' : ''}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* ── Habit List ── */}
        <View style={{ paddingHorizontal:16 }}>
          {focusMode && <View style={{ backgroundColor:T.warning+'15', borderRadius:10, padding:10, marginBottom:12, borderWidth:1, borderColor:T.warning+'40' }}>
            <Text style={{ color:T.warning, fontWeight:'600', fontSize:13 }}>🎯 Focus mode — showing top 3 pending habits</Text>
          </View>}

          {app.habits.length === 0 ? (
            <TouchableOpacity style={s.emptyState} onPress={() => navigation.navigate('AddHabit')}>
              <Text style={{ fontSize:52, marginBottom:12 }}>🌱</Text>
              <Text style={{ color:T.muted, fontSize:16, fontWeight:'600' }}>No habits yet!</Text>
              <Text style={{ color:T.dim, fontSize:13, marginTop:4 }}>Tap to add your first habit</Text>
            </TouchableOpacity>
          ) : displayHabits.length === 0 ? (
            <View style={{ alignItems:'center', paddingVertical:30 }}>
              <Text style={{ fontSize:36, marginBottom:8 }}>✅</Text>
              <Text style={{ color:T.muted }}>All {activeTOD} habits done!</Text>
            </View>
          ) : (
            displayHabits.map(h => {
              const done   = app.isDone(h.id);
              const streak = app.getStreak(h.id);
              const qty    = app.getQuantity(h.id);
              const pct    = h.type==='quantity' ? Math.min(100, Math.round((qty/(h.target||1))*100)) : done ? 100 : 0;
              return (
                <TouchableOpacity key={h.id} activeOpacity={0.85}
                  onPress={() => handleToggle(h)}
                  onLongPress={() => navigation.navigate('HabitDetail', { habit: h })}
                  style={[s.habitCard, { borderColor: done ? h.color+'50' : T.border }]}>
                  {/* Check */}
                  <TouchableOpacity onPress={() => handleToggle(h)}
                    style={[s.checkCircle, { backgroundColor: done ? h.color : 'transparent', borderColor: done ? h.color : T.muted }]}>
                    {done && <Text style={{ color:'#fff', fontSize:18, fontWeight:'900' }}>✓</Text>}
                  </TouchableOpacity>
                  {/* Info */}
                  <View style={{ flex:1 }}>
                    <View style={{ flexDirection:'row', alignItems:'center', gap:6, marginBottom:2 }}>
                      <Text style={{ fontSize:20 }}>{h.emoji}</Text>
                      <Text style={{ fontSize:15, fontWeight:'700', color: done ? T.dim : T.text, textDecorationLine: done ? 'line-through' : 'none', flex:1 }}>{h.name}</Text>
                      {streak >= 7 && <View style={{ backgroundColor:T.warning+'25', paddingHorizontal:6, paddingVertical:2, borderRadius:8 }}><Text style={{ color:T.warning, fontSize:11, fontWeight:'700' }}>🔥{streak}</Text></View>}
                    </View>
                    {/* Motivation */}
                    {h.motivation && !done && <Text style={{ color:T.dim, fontSize:11, marginBottom:4, fontStyle:'italic' }}>"{h.motivation}"</Text>}
                    {/* Quantity bar */}
                    {h.type==='quantity' && (
                      <View>
                        <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:3 }}>
                          <Text style={{ color:T.dim, fontSize:11 }}>{qty} / {h.target} {h.unit}</Text>
                          <Text style={{ color: done ? T.success : T.primary, fontSize:11, fontWeight:'600' }}>{pct}%</Text>
                        </View>
                        <View style={{ height:6, backgroundColor:T.border, borderRadius:3, overflow:'hidden' }}>
                          <View style={{ height:'100%', width:`${pct}%`, backgroundColor: done ? T.success : h.color, borderRadius:3 }}/>
                        </View>
                      </View>
                    )}
                    {streak > 0 && h.type !== 'quantity' && (
                      <Text style={{ fontSize:11, color:T.warning, marginTop:2 }}>🔥 {streak} day streak{app.forgiveMissed ? ' (forgiven)' : ''}</Text>
                    )}
                  </View>
                  <Text style={{ color:T.dim, fontSize:18 }}>›</Text>
                </TouchableOpacity>
              );
            })
          )}
        </View>

        {/* ── Badges ── */}
        {app.habits.length > 0 && (
          <View style={{ marginTop:16, paddingHorizontal:16 }}>
            <Text style={s.sectionTitle}>BADGES ({earnedBadges.length}/{BADGES.length})</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop:10 }}>
              {BADGES.map(b => {
                const earned = earnedBadges.find(e => e.id === b.id);
                return (
                  <View key={b.id} style={{ alignItems:'center', marginRight:16, opacity: earned ? 1 : 0.3 }}>
                    <View style={[s.badgeCircle, { backgroundColor: earned ? T.primary+'30' : T.card, borderColor: earned ? T.primary : T.border }]}>
                      <Text style={{ fontSize:26 }}>{b.icon}</Text>
                    </View>
                    <Text style={{ color: earned ? T.text : T.dim, fontSize:10, fontWeight:'600', marginTop:4, textAlign:'center', maxWidth:60 }}>{b.name}</Text>
                    <Text style={{ color:T.warning, fontSize:10, fontWeight:'700' }}>+{b.xp}XP</Text>
                  </View>
                );
              })}
            </ScrollView>
          </View>
        )}

        {/* ── Quote ── */}
        <View style={s.quoteCard}>
          <Text style={{ color:T.dim, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:6 }}>DAILY QUOTE</Text>
          <Text style={{ color:T.text, fontSize:14, fontStyle:'italic', lineHeight:22 }}>"{quote.text}"</Text>
          <Text style={{ color:T.dim, fontSize:12, marginTop:6 }}>— {quote.author}</Text>
        </View>

        {/* ── WhatsApp Share Card ── */}
        <TouchableOpacity style={s.whatsappBtn} onPress={shareProgress}>
          <Text style={{ fontSize:20 }}>📤</Text>
          <View style={{ flex:1 }}>
            <Text style={{ color:T.text, fontWeight:'700', fontSize:14 }}>Share your progress</Text>
            <Text style={{ color:T.dim, fontSize:12 }}>Send to WhatsApp, Instagram & more</Text>
          </View>
          <View style={{ backgroundColor:'#25D366', paddingHorizontal:12, paddingVertical:6, borderRadius:10 }}>
            <Text style={{ color:'#fff', fontWeight:'700', fontSize:12 }}>Share</Text>
          </View>
        </TouchableOpacity>

      </ScrollView>

      {showQuantity && (
        <QuantityModal
          habit={showQuantity.habit}
          date={showQuantity.date}
          currentValue={app.getQuantity(showQuantity.habit.id, showQuantity.date)}
          onSave={(val) => { app.logQuantity(showQuantity.habit.id, val, showQuantity.date); setShowQuantity(null); }}
          onClose={() => setShowQuantity(null)}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  hero:        { backgroundColor:'#1e1b4b', paddingHorizontal:20, paddingTop:56, paddingBottom:24, borderBottomLeftRadius:28, borderBottomRightRadius:28, marginBottom:16 },
  greeting:    { color:T.muted, fontSize:14, marginBottom:2 },
  userName:    { color:T.text, fontSize:22, fontWeight:'800', marginBottom:2 },
  dateText:    { color:T.dim, fontSize:13 },
  shareBtn:    { backgroundColor:'rgba(255,255,255,.1)', width:40, height:40, borderRadius:20, alignItems:'center', justifyContent:'center' },
  ringWrap:    { width:100, height:100, alignItems:'center', justifyContent:'center' },
  ringOuter:   { position:'absolute', width:100, height:100, borderRadius:50, borderWidth:8 },
  ringInner:   { alignItems:'center', justifyContent:'center' },
  ringPct:     { fontSize:22, fontWeight:'900' },
  ringLabel:   { color:T.dim, fontSize:10 },
  statCard:    { flex:1, borderRadius:12, padding:10, alignItems:'center', borderWidth:1 },
  statNum:     { fontSize:22, fontWeight:'800' },
  statLbl:     { color:T.dim, fontSize:11, marginTop:2 },
  xpBar:       { backgroundColor:'rgba(99,102,241,.15)', borderRadius:12, padding:10, borderWidth:1, borderColor:'rgba(99,102,241,.3)' },
  allDone:     { marginTop:14, backgroundColor:'rgba(34,197,94,.2)', borderRadius:14, padding:12, alignItems:'center', borderWidth:1, borderColor:'rgba(34,197,94,.4)' },
  controlBtn:  { backgroundColor:T.card, borderRadius:10, paddingHorizontal:12, paddingVertical:7, borderWidth:1, borderColor:T.border, alignItems:'center', justifyContent:'center' },
  todBtn:      { backgroundColor:T.card, borderRadius:20, paddingHorizontal:12, paddingVertical:6, borderWidth:1, borderColor:T.border },
  sectionTitle:{ color:T.muted, fontSize:12, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5 },
  habitCard:   { backgroundColor:T.card, borderRadius:18, padding:16, marginBottom:12, borderWidth:1.5, flexDirection:'row', alignItems:'center', gap:14 },
  checkCircle: { width:44, height:44, borderRadius:22, borderWidth:2.5, alignItems:'center', justifyContent:'center' },
  emptyState:  { alignItems:'center', paddingVertical:50, backgroundColor:T.card, borderRadius:20, borderWidth:1, borderColor:T.border },
  badgeCircle: { width:56, height:56, borderRadius:28, alignItems:'center', justifyContent:'center', borderWidth:1.5 },
  quoteCard:   { margin:16, backgroundColor:T.card, borderRadius:16, padding:16, borderWidth:1, borderColor:T.border, borderLeftWidth:3, borderLeftColor:T.primary },
  whatsappBtn: { marginHorizontal:16, marginBottom:8, backgroundColor:'rgba(37,211,102,.1)', borderRadius:16, padding:16, flexDirection:'row', alignItems:'center', gap:12, borderWidth:1, borderColor:'rgba(37,211,102,.3)' },
});

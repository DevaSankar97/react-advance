import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Alert, StyleSheet, Dimensions } from 'react-native';
import { useApp, dateStr } from '../context/AppContext';
import { T, BADGES } from '../utils/theme';

const { width } = Dimensions.get('window');

// ── Premium Screen ──
export function PremiumScreen({ navigation }) {
  const { isPro, setIsPro } = useApp();
  const [plan, setPlan] = useState('yearly');

  if (isPro) return (
    <View style={{ flex:1, backgroundColor:T.bg, alignItems:'center', justifyContent:'center', padding:32 }}>
      <Text style={{ fontSize:72, marginBottom:16 }}>🎉</Text>
      <Text style={{ color:T.text, fontSize:24, fontWeight:'800', marginBottom:8 }}>You're Pro!</Text>
      <Text style={{ color:T.muted, textAlign:'center', marginBottom:32 }}>All features unlocked. Keep building those habits!</Text>
      <TouchableOpacity style={{ backgroundColor:T.primary, paddingHorizontal:32, paddingVertical:16, borderRadius:16 }} onPress={() => navigation.goBack()}>
        <Text style={{ color:'#fff', fontWeight:'800', fontSize:16 }}>Back to App 🚀</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={{ flex:1, backgroundColor:T.bg }}>
      <TouchableOpacity style={{ position:'absolute', top:56, right:20, zIndex:10 }} onPress={() => navigation.goBack()}>
        <Text style={{ color:T.dim, fontSize:22, fontWeight:'600' }}>✕</Text>
      </TouchableOpacity>
      <ScrollView contentContainerStyle={{ alignItems:'center', padding:32, paddingTop:80 }}>
        <Text style={{ fontSize:64 }}>✨</Text>
        <Text style={{ color:T.text, fontSize:28, fontWeight:'800', marginTop:12 }}>StreakIn Pro</Text>
        <Text style={{ color:T.muted, fontSize:15, marginTop:6, textAlign:'center' }}>Unlock your full potential</Text>

        <View style={{ width:'100%', marginTop:24, gap:10 }}>
          {[
            ['♾️','Unlimited habits (free = 5 only)'],
            ['📊','Full analytics + 28-day heatmaps'],
            ['🔔','Smart hourly reminders'],
            ['📅','Complete calendar history'],
            ['📏','Quantity tracking (water, steps...)'],
            ['🏆','Badges, XP & level system'],
            ['🛡️','Forgiveness mode — miss 1 day OK'],
            ['🎯','Focus mode — top 3 habits'],
            ['📤','WhatsApp progress sharing'],
            ['🌐','All 5 Indian languages'],
          ].map(([icon, text]) => (
            <View key={text} style={{ flexDirection:'row', alignItems:'center', gap:12 }}>
              <View style={{ width:28,height:28,borderRadius:14,backgroundColor:T.success+'20',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:T.success }}>
                <Text style={{ color:T.success, fontSize:12, fontWeight:'800' }}>✓</Text>
              </View>
              <Text style={{ color:T.text, fontSize:14, flex:1 }}>{icon} {text}</Text>
            </View>
          ))}
        </View>

        {/* Plans */}
        <View style={{ flexDirection:'row', gap:12, marginTop:28, width:'100%' }}>
          <TouchableOpacity style={[s.planCard, { borderColor:T.border }]} onPress={() => setPlan('monthly')}>
            {plan==='monthly'&&<View style={s.selectedDot}/>}
            <Text style={{ color:T.muted, fontWeight:'700', marginBottom:4 }}>Monthly</Text>
            <Text style={{ color:T.text, fontSize:30, fontWeight:'900' }}>₹99</Text>
            <Text style={{ color:T.dim, fontSize:12 }}>per month</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.planCard, { borderColor:T.primary, borderWidth:2, backgroundColor:T.primary+'15' }]} onPress={() => setPlan('yearly')}>
            {plan==='yearly'&&<View style={[s.selectedDot, { backgroundColor:T.primary }]}/>}
            <View style={{ position:'absolute', top:-12, backgroundColor:T.warning, paddingHorizontal:10, paddingVertical:3, borderRadius:10 }}>
              <Text style={{ color:'#fff', fontSize:10, fontWeight:'800' }}>SAVE 41%</Text>
            </View>
            <Text style={{ color:'#a78bfa', fontWeight:'700', marginBottom:4 }}>Yearly</Text>
            <Text style={{ color:T.text, fontSize:30, fontWeight:'900' }}>₹699</Text>
            <Text style={{ color:T.success, fontSize:12, fontWeight:'600' }}>= ₹58/mo</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={s.ctaBtn} onPress={() => Alert.alert('Coming Soon!','Payment via PhonePe/GPay — launching soon!\n\nFor early access contact:\nddeva8560@gmail.com')}>
          <Text style={{ color:'#fff', fontSize:18, fontWeight:'900' }}>Get Pro — {plan==='yearly'?'₹699/year':'₹99/month'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginTop:16 }}>
          <Text style={{ color:T.dim, fontSize:14 }}>Continue with Free (5 habits)</Text>
        </TouchableOpacity>

        <Text style={{ color:T.dim, fontSize:11, textAlign:'center', marginTop:16, lineHeight:18 }}>
          Payment processed via Google Play / App Store.{'\n'}Cancel anytime. No questions asked.
        </Text>
      </ScrollView>
    </View>
  );
}

// ── Habit Detail Screen ──
export function HabitDetailScreen({ route, navigation }) {
  const app = useApp();
  const h   = route.params?.habit;
  if (!h) return null;

  const streak   = app.getStreak(h.id);
  const best     = app.getBest(h.id);
  const total    = app.getTotal(h.id);
  const weekDone = app.getWeekDone(h.id);

  const earnedBadges = BADGES.filter(b => {
    if (b.id==='first')   return total >= 1;
    if (b.id==='week7')   return streak >= 7;
    if (b.id==='week14')  return streak >= 14;
    if (b.id==='month30') return streak >= 30;
    if (b.id==='century') return total >= 100;
    if (b.id==='perfect') return weekDone >= 7;
    return false;
  });

  return (
    <View style={{ flex:1, backgroundColor:T.bg }}>
      <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal:16, paddingTop:56, paddingBottom:16, borderBottomWidth:1, borderBottomColor:T.border }}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={{ color:T.primary, fontSize:16 }}>‹ Back</Text></TouchableOpacity>
        <Text style={{ color:T.text, fontSize:17, fontWeight:'800' }}>Habit Details</Text>
        <TouchableOpacity onPress={() => { app.deleteHabit(h.id); navigation.goBack(); }}>
          <Text style={{ color:T.danger, fontSize:14 }}>Delete</Text>
        </TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={{ padding:20, paddingBottom:60 }}>
        {/* Header */}
        <View style={{ alignItems:'center', marginBottom:24 }}>
          <View style={{ width:90,height:90,borderRadius:45,backgroundColor:h.color+'25',alignItems:'center',justifyContent:'center',marginBottom:14 }}>
            <Text style={{ fontSize:46 }}>{h.emoji}</Text>
          </View>
          <Text style={{ color:T.text, fontSize:24, fontWeight:'800' }}>{h.name}</Text>
          {h.motivation&&<Text style={{ color:T.muted, fontSize:14, fontStyle:'italic', marginTop:6, textAlign:'center' }}>"{h.motivation}"</Text>}
          <Text style={{ color:T.dim, fontSize:13, marginTop:6 }}>
            {h.type==='quantity'?`Target: ${h.target} ${h.unit}/day`:`Daily ${h.timeOfDay||'anytime'} habit`}
          </Text>
        </View>

        {/* Stats */}
        <View style={{ flexDirection:'row', gap:10, marginBottom:20 }}>
          {[{icon:'🔥',l:'Current',v:streak,c:T.primary},{icon:'🏆',l:'Best',v:best,c:T.success},{icon:'📊',l:'Total',v:total,c:T.warning}].map(s=>(
            <View key={s.l} style={{ flex:1, backgroundColor:T.card, borderRadius:16, padding:14, alignItems:'center', borderWidth:1, borderColor:T.border }}>
              <Text style={{ fontSize:22 }}>{s.icon}</Text>
              <Text style={{ color:s.c, fontSize:24, fontWeight:'800', marginTop:6 }}>{s.v}</Text>
              <Text style={{ color:T.dim, fontSize:11, marginTop:2 }}>{s.l}</Text>
            </View>
          ))}
        </View>

        {/* Week */}
        <View style={{ backgroundColor:T.card, borderRadius:16, padding:16, marginBottom:16, borderWidth:1, borderColor:T.border }}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:10 }}>
            <Text style={{ color:T.muted, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5 }}>THIS WEEK</Text>
            <Text style={{ color:T.primary, fontWeight:'700' }}>{weekDone}/7</Text>
          </View>
          <View style={{ flexDirection:'row', gap:6 }}>
            {app.getWeek(h.id).map((d,i) => (
              <View key={i} style={{ flex:1, alignItems:'center', gap:4 }}>
                <View style={{ width:'100%', height:d.done?32:6, borderRadius:6, backgroundColor:d.done?h.color:T.border, opacity:d.done?1:0.3 }}/>
                <Text style={{ color:T.dim, fontSize:9 }}>{d.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* 28-day heatmap */}
        <View style={{ backgroundColor:T.card, borderRadius:16, padding:16, marginBottom:16, borderWidth:1, borderColor:T.border }}>
          <Text style={{ color:T.muted, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:12 }}>LAST 28 DAYS</Text>
          <View style={{ flexDirection:'row', flexWrap:'wrap', gap:4 }}>
            {Array.from({length:28},(_,i)=>{const d=new Date();d.setDate(d.getDate()-27+i);const done=app.isDone(h.id,d);return(
              <View key={i} style={{ width:(width-80)/28, aspectRatio:1, borderRadius:3, backgroundColor:done?h.color:T.border, opacity:done?1:0.25 }}/>
            );})}
          </View>
          <Text style={{ color:T.dim, fontSize:11, textAlign:'center', marginTop:8 }}>
            {Math.round(total/28*100)}% completion rate
          </Text>
        </View>

        {/* Badges */}
        <Text style={{ color:T.muted, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:12 }}>BADGES ({earnedBadges.length}/{BADGES.length})</Text>
        <View style={{ flexDirection:'row', flexWrap:'wrap', gap:10 }}>
          {BADGES.map(b => {
            const earned = earnedBadges.find(e => e.id === b.id);
            return (
              <View key={b.id} style={{ width:'47%', backgroundColor:T.card, borderRadius:14, padding:14, flexDirection:'row', alignItems:'center', gap:10, borderWidth:1.5, borderColor:earned?h.color:T.border, opacity:earned?1:0.4 }}>
                <Text style={{ fontSize:26 }}>{b.icon}</Text>
                <View>
                  <Text style={{ color:T.text, fontWeight:'700', fontSize:13 }}>{b.name}</Text>
                  <Text style={{ color:T.dim, fontSize:11 }}>{b.desc}</Text>
                  <Text style={{ color:T.warning, fontSize:11, fontWeight:'700', marginTop:2 }}>+{b.xp} XP</Text>
                </View>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  planCard:    { flex:1, borderRadius:16, padding:16, alignItems:'center', borderWidth:1.5, backgroundColor:T.card, position:'relative', overflow:'visible' },
  selectedDot: { position:'absolute', top:10, right:10, width:10, height:10, borderRadius:5, backgroundColor:T.success },
  ctaBtn:      { width:'100%', borderRadius:18, height:58, marginTop:24, backgroundColor:T.primary, alignItems:'center', justifyContent:'center' },
});

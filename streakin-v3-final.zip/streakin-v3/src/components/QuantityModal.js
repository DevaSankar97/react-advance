import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, Modal, StyleSheet } from 'react-native';
import { T } from '../utils/theme';

export default function QuantityModal({ habit: h, date, currentValue, onSave, onClose }) {
  const [val, setVal] = useState(currentValue || 0);
  if (!h) return null;
  const pct = Math.min(100, Math.round((val / (h.target || 1)) * 100));

  const quickAmounts = [h.step, h.step*2, h.step*4, h.target*0.5, h.target].filter((v,i,a) => v>0 && a.indexOf(v)===i).slice(0,5);

  return (
    <Modal visible animationType="slide" presentationStyle="pageSheet">
      <View style={{ flex:1, backgroundColor:T.bg, padding:24 }}>
        {/* Header */}
        <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:24 }}>
          <TouchableOpacity onPress={onClose}><Text style={{ color:T.dim, fontSize:20, fontWeight:'600' }}>✕</Text></TouchableOpacity>
          <Text style={{ color:T.text, fontSize:17, fontWeight:'800' }}>Log {h.name}</Text>
          <TouchableOpacity onPress={() => onSave(val)}><Text style={{ color:T.primary, fontSize:16, fontWeight:'800' }}>Save</Text></TouchableOpacity>
        </View>

        {/* Emoji + name */}
        <View style={{ alignItems:'center', marginBottom:28 }}>
          <Text style={{ fontSize:60 }}>{h.emoji}</Text>
          <Text style={{ color:T.text, fontSize:18, fontWeight:'700', marginTop:8 }}>{h.name}</Text>
          <Text style={{ color:T.dim, fontSize:13, marginTop:4 }}>Daily target: {h.target} {h.unit}</Text>
          {h.motivation ? <Text style={{ color:T.muted, fontSize:12, fontStyle:'italic', marginTop:6, textAlign:'center' }}>"{h.motivation}"</Text> : null}
        </View>

        {/* Big number */}
        <View style={{ alignItems:'center', marginBottom:20 }}>
          <Text style={{ color: pct>=100 ? T.success : T.primary, fontSize:72, fontWeight:'900', lineHeight:80 }}>{val}</Text>
          <Text style={{ color:T.muted, fontSize:16, marginTop:4 }}>{h.unit}</Text>
          {pct >= 100 && <Text style={{ color:T.success, fontWeight:'800', fontSize:16, marginTop:8 }}>🎉 Goal reached!</Text>}
        </View>

        {/* Progress bar */}
        <View style={{ marginBottom:28 }}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', marginBottom:8 }}>
            <Text style={{ color:T.dim, fontSize:13 }}>{val} / {h.target} {h.unit}</Text>
            <Text style={{ color: pct>=100 ? T.success : T.primary, fontWeight:'700' }}>{pct}%</Text>
          </View>
          <View style={{ height:14, backgroundColor:T.border, borderRadius:7, overflow:'hidden' }}>
            <View style={{ height:'100%', width:`${pct}%`, backgroundColor: pct>=100 ? T.success : h.color, borderRadius:7 }}/>
          </View>
        </View>

        {/* +/- controls */}
        <View style={{ flexDirection:'row', alignItems:'center', justifyContent:'center', gap:16, marginBottom:24 }}>
          <TouchableOpacity onPress={() => setVal(v => Math.max(0, Math.round((v-(h.step||1))*100)/100))}
            style={{ width:64, height:64, borderRadius:32, backgroundColor:T.card, borderWidth:1.5, borderColor:T.border, alignItems:'center', justifyContent:'center' }}>
            <Text style={{ color:T.text, fontSize:32, fontWeight:'700', lineHeight:38 }}>−</Text>
          </TouchableOpacity>
          <TextInput
            style={{ flex:1, backgroundColor:T.card, borderRadius:16, padding:14, color:T.text, fontSize:26, fontWeight:'800', textAlign:'center', borderWidth:1.5, borderColor:T.primary }}
            keyboardType="numeric"
            value={String(val)}
            onChangeText={v => setVal(parseFloat(v) || 0)}
          />
          <TouchableOpacity onPress={() => setVal(v => Math.round((v+(h.step||1))*100)/100)}
            style={{ width:64, height:64, borderRadius:32, backgroundColor:T.primary, alignItems:'center', justifyContent:'center' }}>
            <Text style={{ color:'#fff', fontSize:32, fontWeight:'700', lineHeight:38 }}>+</Text>
          </TouchableOpacity>
        </View>

        {/* Quick amounts */}
        <Text style={{ color:T.muted, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:10, textAlign:'center' }}>QUICK LOG</Text>
        <View style={{ flexDirection:'row', gap:8, flexWrap:'wrap', justifyContent:'center' }}>
          {quickAmounts.map(v => (
            <TouchableOpacity key={v} onPress={() => setVal(v)}
              style={{ paddingHorizontal:16, paddingVertical:9, borderRadius:20, backgroundColor: val===v ? T.primary : T.card, borderWidth:1, borderColor: val===v ? T.primary : T.border }}>
              <Text style={{ color: val===v ? '#fff' : T.muted, fontWeight:'600' }}>{v} {h.unit}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </Modal>
  );
}

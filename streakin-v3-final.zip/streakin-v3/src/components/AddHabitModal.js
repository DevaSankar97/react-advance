import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, TextInput,
  Modal, ScrollView, Switch, StyleSheet,
} from 'react-native';
import { T, HABIT_COLORS, EMOJIS, PRESETS, TIME_OF_DAY } from '../utils/theme';

const BLANK = {
  name:'', emoji:'🎯', color:'#6366f1', type:'boolean',
  unit:'', target:'', step:'', timeOfDay:'anytime', motivation:'',
  reminderEnabled:false, reminderHour:8, reminderMinute:0, reminderInterval:0,
};

export default function AddHabitModal({ visible, onClose, onAdd }) {
  const [tab,  setTab]  = useState('preset');
  const [form, setForm] = useState({...BLANK});
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleAdd = (data) => {
    if (!data.name?.trim()) return;
    onAdd(data);
    setForm({...BLANK});
    setTab('preset');
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={{ flex:1, backgroundColor:T.bg }}>
        {/* Header */}
        <View style={s.header}>
          <TouchableOpacity onPress={onClose}><Text style={{ color:T.dim, fontSize:20, fontWeight:'600' }}>✕</Text></TouchableOpacity>
          <Text style={{ color:T.text, fontSize:17, fontWeight:'800' }}>Add Habit</Text>
          {tab==='custom'
            ? <TouchableOpacity onPress={() => handleAdd(form)}><Text style={{ color:T.primary, fontSize:16, fontWeight:'800' }}>Save</Text></TouchableOpacity>
            : <View style={{ width:40 }}/>
          }
        </View>

        {/* Tab switcher */}
        <View style={s.tabRow}>
          {[{k:'preset',l:'⚡ Quick Add'},{k:'custom',l:'✏️ Custom'}].map(t => (
            <TouchableOpacity key={t.k} onPress={() => setTab(t.k)}
              style={[s.tabBtn, tab===t.k && { backgroundColor:T.primary }]}>
              <Text style={{ color: tab===t.k ? '#fff' : T.muted, fontWeight:'700', fontSize:14 }}>{t.l}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <ScrollView contentContainerStyle={{ padding:16, paddingBottom:40 }}>
          {tab === 'preset' ? (
            <View style={{ flexDirection:'row', flexWrap:'wrap', gap:10 }}>
              {PRESETS.map(p => (
                <TouchableOpacity key={p.name} style={s.presetCard} onPress={() => handleAdd(p)}>
                  <View style={[s.presetIcon, { backgroundColor:p.color+'20' }]}>
                    <Text style={{ fontSize:26 }}>{p.emoji}</Text>
                  </View>
                  <Text style={{ color:T.text, fontWeight:'700', fontSize:13, textAlign:'center' }}>{p.name}</Text>
                  {p.type==='quantity' && <Text style={{ color:T.dim, fontSize:11 }}>Target: {p.target} {p.unit}</Text>}
                </TouchableOpacity>
              ))}
            </View>
          ) : (
            <View>
              {/* Name */}
              <Text style={s.label}>HABIT NAME *</Text>
              <View style={s.inputRow}>
                <Text style={{ fontSize:22, marginRight:10 }}>{form.emoji}</Text>
                <TextInput style={s.input} placeholder="e.g. Drink water" placeholderTextColor={T.dim}
                  value={form.name} onChangeText={v => f('name', v)} autoFocus maxLength={40}/>
              </View>

              {/* Motivation */}
              <Text style={s.label}>WHY? (Motivation)</Text>
              <TextInput style={[s.inputRow, { paddingVertical:12 }]}
                placeholder="I'm doing this because..." placeholderTextColor={T.dim}
                value={form.motivation} onChangeText={v => f('motivation', v)} maxLength={80}/>

              {/* Type */}
              <Text style={s.label}>TYPE</Text>
              <View style={{ flexDirection:'row', gap:10, marginBottom:16 }}>
                {[{v:'boolean',l:'✅ Yes/No'},{v:'quantity',l:'📏 Quantity'}].map(t => (
                  <TouchableOpacity key={t.v} onPress={() => f('type', t.v)}
                    style={[s.typeBtn, form.type===t.v && { backgroundColor:T.primary+'30', borderColor:T.primary }]}>
                    <Text style={{ color: form.type===t.v ? T.primary : T.muted, fontWeight:'700' }}>{t.l}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Quantity fields */}
              {form.type === 'quantity' && (
                <View style={{ flexDirection:'row', gap:10, marginBottom:16 }}>
                  <View style={{ flex:2 }}>
                    <Text style={s.label}>UNIT</Text>
                    <TextInput style={s.smallInput} placeholder="liters, steps..." placeholderTextColor={T.dim}
                      value={form.unit} onChangeText={v => f('unit', v)}/>
                  </View>
                  <View style={{ flex:1 }}>
                    <Text style={s.label}>TARGET</Text>
                    <TextInput style={s.smallInput} placeholder="8" placeholderTextColor={T.dim}
                      keyboardType="numeric" value={String(form.target||'')} onChangeText={v => f('target', v)}/>
                  </View>
                  <View style={{ flex:1 }}>
                    <Text style={s.label}>STEP</Text>
                    <TextInput style={s.smallInput} placeholder="1" placeholderTextColor={T.dim}
                      keyboardType="numeric" value={String(form.step||'')} onChangeText={v => f('step', v)}/>
                  </View>
                </View>
              )}

              {/* Time of day */}
              <Text style={s.label}>TIME OF DAY</Text>
              <View style={{ flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:16 }}>
                {TIME_OF_DAY.map(t => (
                  <TouchableOpacity key={t.id} onPress={() => f('timeOfDay', t.id)}
                    style={[s.typeBtn, form.timeOfDay===t.id && { backgroundColor:T.primary+'30', borderColor:T.primary }]}>
                    <Text style={{ color: form.timeOfDay===t.id ? T.primary : T.muted, fontWeight:'600', fontSize:13 }}>{t.icon} {t.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Emoji */}
              <Text style={s.label}>ICON</Text>
              <View style={{ flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:16 }}>
                {EMOJIS.map(e => (
                  <TouchableOpacity key={e} onPress={() => f('emoji', e)}
                    style={[s.emojiBtn, form.emoji===e && { backgroundColor:T.primary+'30', borderColor:T.primary }]}>
                    <Text style={{ fontSize:20 }}>{e}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Color */}
              <Text style={s.label}>COLOR</Text>
              <View style={{ flexDirection:'row', flexWrap:'wrap', gap:10, marginBottom:16 }}>
                {HABIT_COLORS.map(c => (
                  <TouchableOpacity key={c} onPress={() => f('color', c)}
                    style={{ width:36, height:36, borderRadius:18, backgroundColor:c, borderWidth: form.color===c ? 3 : 0, borderColor:'#fff' }}/>
                ))}
              </View>

              {/* Reminder */}
              <View style={s.reminderBox}>
                <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom: form.reminderEnabled ? 14 : 0 }}>
                  <View>
                    <Text style={{ color:T.text, fontWeight:'700', fontSize:15 }}>🔔 Daily Reminder</Text>
                    <Text style={{ color:T.dim, fontSize:12, marginTop:2 }}>Get notified at a specific time</Text>
                  </View>
                  <Switch value={form.reminderEnabled} onValueChange={v => f('reminderEnabled', v)} trackColor={{ false:T.border, true:T.primary }} thumbColor="#fff"/>
                </View>
                {form.reminderEnabled && (
                  <View>
                    <View style={{ flexDirection:'row', gap:10, marginBottom:12 }}>
                      <View style={{ flex:1 }}>
                        <Text style={s.label}>HOUR (0-23)</Text>
                        <TextInput style={s.smallInput} keyboardType="numeric" value={String(form.reminderHour)}
                          onChangeText={v => f('reminderHour', parseInt(v)||0)} maxLength={2}/>
                      </View>
                      <View style={{ flex:1 }}>
                        <Text style={s.label}>MINUTE</Text>
                        <TextInput style={s.smallInput} keyboardType="numeric" value={String(form.reminderMinute)}
                          onChangeText={v => f('reminderMinute', parseInt(v)||0)} maxLength={2}/>
                      </View>
                    </View>
                    <Text style={s.label}>REPEAT EVERY</Text>
                    <View style={{ flexDirection:'row', gap:8 }}>
                      {[0,1,2,3,4].map(h => (
                        <TouchableOpacity key={h} onPress={() => f('reminderInterval', h)}
                          style={[s.typeBtn, { flex:1 }, form.reminderInterval===h && { backgroundColor:T.primary+'30', borderColor:T.primary }]}>
                          <Text style={{ color: form.reminderInterval===h ? T.primary : T.muted, fontWeight:'600', fontSize:12 }}>{h===0?'Once':`${h}h`}</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                )}
              </View>

              {/* Preview */}
              {form.name.length > 0 && (
                <View style={[s.preview, { backgroundColor:form.color+'15', borderColor:form.color+'40' }]}>
                  <Text style={{ fontSize:26 }}>{form.emoji}</Text>
                  <View style={{ flex:1, marginLeft:12 }}>
                    <Text style={{ color:T.text, fontWeight:'700', fontSize:15 }}>{form.name}</Text>
                    {form.motivation ? <Text style={{ color:T.dim, fontSize:12, marginTop:2, fontStyle:'italic' }}>"{form.motivation}"</Text> : null}
                    {form.type==='quantity' && form.target ? <Text style={{ color:T.muted, fontSize:12, marginTop:2 }}>Target: {form.target} {form.unit}</Text> : null}
                  </View>
                  <View style={{ width:8, height:8, borderRadius:4, backgroundColor:form.color }}/>
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  header:      { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal:16, paddingTop:20, paddingBottom:16, borderBottomWidth:1, borderBottomColor:T.border },
  tabRow:      { flexDirection:'row', backgroundColor:T.card, borderRadius:10, padding:4, margin:16 },
  tabBtn:      { flex:1, paddingVertical:9, borderRadius:8, alignItems:'center' },
  label:       { color:T.muted, fontSize:11, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.5, marginBottom:8, marginTop:4 },
  inputRow:    { flexDirection:'row', alignItems:'center', backgroundColor:T.card, borderRadius:14, padding:14, borderWidth:1.5, borderColor:T.border, marginBottom:4 },
  input:       { flex:1, color:T.text, fontSize:15 },
  smallInput:  { backgroundColor:T.card, borderRadius:12, padding:12, color:T.text, borderWidth:1.5, borderColor:T.border },
  typeBtn:     { flex:1, paddingVertical:12, borderRadius:12, borderWidth:1.5, borderColor:T.border, alignItems:'center', backgroundColor:T.card },
  emojiBtn:    { width:42, height:42, borderRadius:10, borderWidth:1.5, borderColor:T.border, alignItems:'center', justifyContent:'center', backgroundColor:T.card },
  reminderBox: { backgroundColor:T.card, borderRadius:14, padding:16, borderWidth:1, borderColor:T.border, marginBottom:8 },
  preview:     { flexDirection:'row', alignItems:'center', borderRadius:16, padding:16, borderWidth:1, marginTop:20 },
  presetCard:  { width:'47%', backgroundColor:T.card, borderRadius:16, padding:14, borderWidth:1, borderColor:T.border, alignItems:'center', gap:8 },
  presetIcon:  { width:56, height:56, borderRadius:28, alignItems:'center', justifyContent:'center' },
});

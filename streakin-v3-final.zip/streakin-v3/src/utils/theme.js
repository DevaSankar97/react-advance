export const T = {
  bg:      '#0f172a',
  card:    '#1e293b',
  card2:   '#263347',
  border:  '#334155',
  text:    '#f1f5f9',
  muted:   '#94a3b8',
  dim:     '#64748b',
  primary: '#6366f1',
  success: '#22c55e',
  warning: '#f59e0b',
  danger:  '#ef4444',
  orange:  '#f97316',
  pink:    '#ec4899',
  cyan:    '#06b6d4',
};

export const HABIT_COLORS = [
  '#6366f1','#22c55e','#f59e0b','#ef4444',
  '#0ea5e9','#ec4899','#14b8a6','#f97316',
  '#8b5cf6','#84cc16','#06b6d4','#e879f9',
];

export const EMOJIS = [
  '💧','🏃','📚','🧘','💪','🥗','😴','✍️',
  '🎯','🧹','💊','🚴','🎨','🎵','🌿','☀️',
  '🧠','💰','🙏','🥤','🥦','🌙','📱','🏆',
  '🚿','🍎','👟','⚽','🎸','🫁','🧪','🌺',
];

export const PRESETS = [
  { name:'Drink Water',   emoji:'💧', color:'#0ea5e9', type:'quantity', unit:'liters',   target:2,     step:0.25, timeOfDay:'morning',   motivation:'Stay hydrated for better energy' },
  { name:'Exercise',      emoji:'🏃', color:'#22c55e', type:'boolean',  timeOfDay:'morning',   motivation:'Strong body, strong mind' },
  { name:'Meditate',      emoji:'🧘', color:'#8b5cf6', type:'quantity', unit:'mins',     target:10,    step:5,    timeOfDay:'morning',   motivation:'Peace of mind every day' },
  { name:'Read',          emoji:'📚', color:'#f59e0b', type:'quantity', unit:'pages',    target:20,    step:5,    timeOfDay:'evening',   motivation:'Knowledge is power' },
  { name:'Sleep 8 hrs',   emoji:'😴', color:'#6366f1', type:'boolean',  timeOfDay:'night',     motivation:'Rest is productive' },
  { name:'Journal',       emoji:'✍️', color:'#ec4899', type:'boolean',  timeOfDay:'evening',   motivation:'Reflect to grow' },
  { name:'Steps',         emoji:'👟', color:'#14b8a6', type:'quantity', unit:'steps',    target:10000, step:1000, timeOfDay:'anytime',   motivation:'Move more, live longer' },
  { name:'No Sugar',      emoji:'🥗', color:'#22c55e', type:'boolean',  timeOfDay:'anytime',   motivation:'Fuel your body right' },
  { name:'Walk 30 min',   emoji:'🚶', color:'#14b8a6', type:'boolean',  timeOfDay:'morning',   motivation:'Fresh air clears the mind' },
  { name:'Vitamins',      emoji:'💊', color:'#ef4444', type:'boolean',  timeOfDay:'morning',   motivation:'Small pill, big difference' },
  { name:'Gratitude',     emoji:'🙏', color:'#f97316', type:'boolean',  timeOfDay:'morning',   motivation:'Thankfulness attracts more good' },
  { name:'Cold Shower',   emoji:'🚿', color:'#0ea5e9', type:'boolean',  timeOfDay:'morning',   motivation:'Build mental toughness' },
  { name:'Pushups',       emoji:'💪', color:'#22c55e', type:'quantity', unit:'reps',     target:30,    step:5,    timeOfDay:'morning',   motivation:'One rep at a time' },
  { name:'No Phone AM',   emoji:'📵', color:'#64748b', type:'boolean',  timeOfDay:'morning',   motivation:'Own your mornings' },
  { name:'Fruits',        emoji:'🍎', color:'#ef4444', type:'quantity', unit:'servings', target:3,     step:1,    timeOfDay:'anytime',   motivation:'Nature\'s medicine' },
  { name:'No Alcohol',    emoji:'🚫', color:'#ef4444', type:'boolean',  timeOfDay:'anytime',   motivation:'Clarity is a superpower' },
];

export const QUOTES = [
  { text:"Small steps every day lead to big changes.",          author:"James Clear" },
  { text:"You don't have to be perfect, just consistent.",      author:"Unknown" },
  { text:"Every check mark is a vote for who you want to become.", author:"Atomic Habits" },
  { text:"Success is the sum of small efforts, repeated daily.", author:"Robert Collier" },
  { text:"The secret of getting ahead is getting started.",     author:"Mark Twain" },
  { text:"We are what we repeatedly do.",                       author:"Aristotle" },
  { text:"Motivation gets you started. Habit keeps you going.", author:"Jim Ryun" },
  { text:"Your future is created by what you do today.",        author:"Unknown" },
  { text:"Don't break the chain.",                              author:"Jerry Seinfeld" },
  { text:"Habits are the compound interest of self-improvement.", author:"James Clear" },
];

export const BADGES = [
  { id:'first',   icon:'🌱', name:'First Step',    desc:'Complete first habit',     xp:10  },
  { id:'week7',   icon:'🔥', name:'Week Warrior',  desc:'7 day streak',             xp:50  },
  { id:'week14',  icon:'⚡', name:'Fortnight Fire', desc:'14 day streak',            xp:100 },
  { id:'month30', icon:'💎', name:'Month Master',  desc:'30 day streak',            xp:200 },
  { id:'century', icon:'🏆', name:'Century Club',  desc:'100 completions',          xp:300 },
  { id:'perfect', icon:'⭐', name:'Perfect Week',  desc:'7/7 days this week',       xp:75  },
  { id:'allstar', icon:'🌟', name:'All Star',       desc:'All habits done in a day', xp:25  },
  { id:'comeback',icon:'🦅', name:'Comeback Kid',  desc:'Return after missing 3d',  xp:40  },
];

export const LANGS = [
  { code:'en', label:'English',  native:'English'  },
  { code:'ta', label:'Tamil',    native:'தமிழ்'     },
  { code:'hi', label:'Hindi',    native:'हिंदी'      },
  { code:'te', label:'Telugu',   native:'తెలుగు'    },
  { code:'kn', label:'Kannada',  native:'ಕನ್ನಡ'     },
];

export const TIME_OF_DAY = [
  { id:'morning',  label:'Morning',  icon:'🌅', hours:[5,6,7,8,9,10,11]  },
  { id:'afternoon',label:'Afternoon',icon:'☀️', hours:[12,13,14,15,16]   },
  { id:'evening',  label:'Evening',  icon:'🌆', hours:[17,18,19,20]       },
  { id:'night',    label:'Night',    icon:'🌙', hours:[21,22,23,0]        },
  { id:'anytime',  label:'Anytime',  icon:'🔄', hours:[]                  },
];

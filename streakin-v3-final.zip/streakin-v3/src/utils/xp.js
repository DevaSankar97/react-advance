// ── XP & Level System ──

export const LEVELS = [
  { level:1,  name:'Seedling',      icon:'🌱', minXP:0,    color:'#94a3b8' },
  { level:2,  name:'Sprouting',     icon:'🌿', minXP:100,  color:'#22c55e' },
  { level:3,  name:'Growing',       icon:'🌳', minXP:250,  color:'#16a34a' },
  { level:4,  name:'Consistent',    icon:'⚡', minXP:500,  color:'#0ea5e9' },
  { level:5,  name:'Dedicated',     icon:'🔥', minXP:1000, color:'#f97316' },
  { level:6,  name:'Warrior',       icon:'⚔️', minXP:2000, color:'#8b5cf6' },
  { level:7,  name:'Champion',      icon:'🏆', minXP:3500, color:'#f59e0b' },
  { level:8,  name:'Legend',        icon:'💎', minXP:5000, color:'#ec4899' },
  { level:9,  name:'Master',        icon:'👑', minXP:7500, color:'#6366f1' },
  { level:10, name:'Habit Guru',    icon:'✨', minXP:10000,color:'#fff'    },
];

export function getLevel(xp) {
  let current = LEVELS[0];
  for (const l of LEVELS) {
    if (xp >= l.minXP) current = l;
  }
  return current;
}

export function getNextLevel(xp) {
  const curr = getLevel(xp);
  return LEVELS.find(l => l.level === curr.level + 1) || null;
}

export function getLevelProgress(xp) {
  const curr = getLevel(xp);
  const next = getNextLevel(xp);
  if (!next) return 100;
  return Math.round(((xp - curr.minXP) / (next.minXP - curr.minXP)) * 100);
}

export function getXPForAction(action) {
  const XP = {
    complete_habit:    10,
    complete_quantity: 15,
    perfect_day:       25,
    streak_7:          50,
    streak_30:         200,
    streak_100:        500,
    comeback:          20,
    first_habit:       10,
  };
  return XP[action] || 5;
}

export function calcTotalXP(habits, completions, getStreak, getTotal) {
  let xp = 0;
  // XP from completions
  xp += Object.keys(completions).length * 10;
  // Bonus for streaks
  for (const h of habits) {
    const streak = getStreak(h.id);
    if (streak >= 7)  xp += 50;
    if (streak >= 30) xp += 200;
    if (streak >= 100)xp += 500;
  }
  return xp;
}

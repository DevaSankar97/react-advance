import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge:  true,
  }),
});

export async function requestPermissions() {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

export async function scheduleHabitReminders(habits) {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    for (const h of habits) {
      if (!h.reminderEnabled) continue;
      // Daily reminder
      await Notifications.scheduleNotificationAsync({
        content: {
          title: `${h.emoji} ${h.name}`,
          body:  `Time for your habit! Keep your streak going 🔥`,
          sound: true,
          data:  { habitId: h.id },
        },
        trigger: {
          hour:    h.reminderHour    || 8,
          minute:  h.reminderMinute  || 0,
          repeats: true,
        },
      });
      // Hourly reminders
      if (h.reminderInterval > 0) {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: `⏰ ${h.emoji} ${h.name}`,
            body:  `Have you done this yet today?`,
            sound: true,
            data:  { habitId: h.id },
          },
          trigger: {
            seconds: h.reminderInterval * 3600,
            repeats: true,
          },
        });
      }
    }
  } catch (err) {
    console.log('Notification error:', err);
  }
}

export async function sendMissedHabitNotification(habitName, emoji) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: `😢 Don't break your streak!`,
        body:  `${emoji} ${habitName} is waiting for you today`,
        sound: true,
      },
      trigger: { seconds: 1 },
    });
  } catch {}
}

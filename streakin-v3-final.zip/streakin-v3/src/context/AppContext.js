import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { calcTotalXP } from '../utils/xp';

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

const STORAGE_KEY = 'streakin_v4';
const FREE_LIMIT   = 5;

export function dateStr(d) {
  return (d || new Date()).toISOString().split('T')[0];
}

export function AppProvider({ children }) {
  const [habits,       setHabits]       = useState([]);
  const [completions,  setCompletions]  = useState({});
  const [friends,      setFriends]      = useState([]);
  const [challenges,   setChallenges]   = useState([]);
  const [isPro,        setIsPro]        = useState(false);
  const [language,     setLanguage]     = useState('en');
  const [darkMode,     setDarkMode]     = useState(true);
  const [notifEnabled, setNotifEnabled] = useState(false);
  const [userName,     setUserName]     = useState('');
  const [forgiveMissed,setForgive]      = useState(true); // forgiveness mode
  const [loaded,       setLoaded]       = useState(false);

  // Load
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(raw => {
      if (raw) {
        try {
          const d = JSON.parse(raw);
          if (d.habits)       setHabits(d.habits);
          if (d.completions)  setCompletions(d.completions);
          if (d.friends)      setFriends(d.friends);
          if (d.challenges)   setChallenges(d.challenges);
          if (d.isPro)        setIsPro(d.isPro);
          if (d.language)     setLanguage(d.language);
          if (d.darkMode !== undefined) setDarkMode(d.darkMode);
          if (d.notifEnabled) setNotifEnabled(d.notifEnabled);
          if (d.userName)     setUserName(d.userName);
          if (d.forgiveMissed !== undefined) setForgive(d.forgiveMissed);
        } catch {}
      }
      setLoaded(true);
    });
  }, []);

  // Save
  useEffect(() => {
    if (!loaded) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({
      habits, completions, friends, challenges,
      isPro, language, darkMode, notifEnabled, userName, forgiveMissed,
    }));
  }, [habits, completions, friends, challenges, isPro, language, darkMode, notifEnabled, userName, forgiveMissed, loaded]);

  // ── Completion helpers ──
  const getComp = useCallback((id, date) => {
    return completions[id + '_' + dateStr(date)] || null;
  }, [completions]);

  const isDone = useCallback((id, date) => {
    const c = getComp(id, date);
    if (!c) return false;
    const h = habits.find(x => x.id === id);
    if (h?.type === 'quantity') return (c.value || 0) >= (h.target || 1);
    return !!c.done;
  }, [completions, habits, getComp]);

  const getQuantity = useCallback((id, date) => {
    return getComp(id, date)?.value || 0;
  }, [getComp]);

  const toggleHabit = useCallback((id, date, cb) => {
    const h = habits.find(x => x.id === id);
    if (!h) return;
    if (h.type === 'quantity') { cb && cb(h, date || new Date()); return; }
    const k = id + '_' + dateStr(date);
    setCompletions(prev => {
      const u = { ...prev };
      if (u[k]?.done) delete u[k];
      else u[k] = { done: true, timestamp: new Date().toISOString() };
      return u;
    });
  }, [habits]);

  const logQuantity = useCallback((id, value, date) => {
    const k = id + '_' + dateStr(date);
    setCompletions(prev => ({
      ...prev,
      [k]: { value, timestamp: new Date().toISOString() },
    }));
  }, []);

  // ── Streak (with forgiveness mode) ──
  const getStreak = useCallback((id) => {
    let streak = 0;
    const d = new Date();
    let missedOnce = false; // forgiveness: allow 1 missed day
    for (let i = 0; i < 365; i++) {
      if (isDone(id, d)) {
        streak++;
        d.setDate(d.getDate() - 1);
      } else if (forgiveMissed && !missedOnce && streak > 0) {
        missedOnce = true;
        d.setDate(d.getDate() - 1); // skip one missed day
      } else {
        break;
      }
    }
    return streak;
  }, [completions, habits, forgiveMissed, isDone]);

  const getBest = useCallback((id) => {
    const h = habits.find(x => x.id === id);
    if (!h) return 0;
    let best = 0, cur = 0;
    const d = new Date(h.createdAt);
    while (d <= new Date()) {
      if (isDone(id, d)) { cur++; best = Math.max(best, cur); }
      else cur = 0;
      d.setDate(d.getDate() + 1);
    }
    return best;
  }, [completions, habits, isDone]);

  const getTotal = useCallback((id) => {
    return Object.keys(completions).filter(k => k.startsWith(id + '_')).length;
  }, [completions]);

  const getWeek = useCallback((id) => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(); d.setDate(d.getDate() - 6 + i);
      return {
        done:  isDone(id, d),
        label: d.toLocaleDateString('en-IN', { weekday:'short' }).slice(0, 1),
        date:  new Date(d),
        isToday: dateStr(d) === dateStr(),
      };
    });
  }, [completions, habits, isDone]);

  const getWeekDone = useCallback((id) => getWeek(id).filter(d => d.done).length, [getWeek]);

  const getMonthRate = useCallback((id) => {
    let done = 0;
    for (let i = 0; i < 30; i++) {
      const d = new Date(); d.setDate(d.getDate() - i);
      if (isDone(id, d)) done++;
    }
    return Math.round((done / 30) * 100);
  }, [completions, habits, isDone]);

  const todayProgress = useCallback(() => {
    const active = habits.filter(h => !h.archived);
    const done   = active.filter(h => isDone(h.id)).length;
    return { done, total: active.length, pct: active.length ? Math.round(done / active.length * 100) : 0 };
  }, [habits, isDone]);

  // ── XP ──
  const totalXP = calcTotalXP(habits, completions, getStreak, getTotal);

  // ── Habit CRUD ──
  const addHabit = useCallback((data) => {
    const h = {
      id:               Date.now().toString(),
      name:             data.name.trim(),
      emoji:            data.emoji   || '🎯',
      color:            data.color   || '#6366f1',
      type:             data.type    || 'boolean',
      unit:             data.unit    || '',
      target:           parseFloat(data.target) || 1,
      step:             parseFloat(data.step)   || 1,
      timeOfDay:        data.timeOfDay || 'anytime',
      motivation:       data.motivation || '',
      reminderEnabled:  data.reminderEnabled  || false,
      reminderHour:     data.reminderHour     || 8,
      reminderMinute:   data.reminderMinute   || 0,
      reminderInterval: parseInt(data.reminderInterval) || 0,
      archived:         false,
      createdAt:        new Date().toISOString(),
    };
    setHabits(prev => [...prev, h]);
    return h;
  }, []);

  const updateHabit = useCallback((id, updates) => {
    setHabits(prev => prev.map(h => h.id === id ? { ...h, ...updates } : h));
  }, []);

  const deleteHabit = useCallback((id) => {
    setHabits(prev => prev.filter(h => h.id !== id));
    setCompletions(prev => Object.fromEntries(
      Object.entries(prev).filter(([k]) => !k.startsWith(id + '_'))
    ));
  }, []);

  const canAddHabit = () => isPro || habits.filter(h => !h.archived).length < FREE_LIMIT;

  // ── Friends & Challenges ──
  const addFriend = useCallback((friend) => {
    setFriends(prev => [...prev, { id: Date.now().toString(), ...friend }]);
  }, []);

  const createChallenge = useCallback((challenge) => {
    setChallenges(prev => [...prev, {
      id:        Date.now().toString(),
      createdAt: new Date().toISOString(),
      status:    'active',
      ...challenge,
    }]);
  }, []);

  return (
    <AppContext.Provider value={{
      // State
      habits, completions, friends, challenges,
      isPro, language, darkMode, notifEnabled, userName, forgiveMissed, loaded,
      totalXP,
      // Setters
      setIsPro, setLanguage, setDarkMode, setNotifEnabled, setUserName, setForgive,
      // Habit ops
      addHabit, updateHabit, deleteHabit, canAddHabit,
      // Completion ops
      toggleHabit, logQuantity, isDone, getQuantity,
      // Stats
      getStreak, getBest, getTotal, getWeek, getWeekDone, getMonthRate, todayProgress,
      // Friends
      addFriend, createChallenge,
    }}>
      {children}
    </AppContext.Provider>
  );
}

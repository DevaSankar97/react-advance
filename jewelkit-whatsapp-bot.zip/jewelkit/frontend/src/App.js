import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './index.css';
import Login     from './components/auth/Login';
import Layout    from './components/Layout';
import Dashboard from './components/dashboard/Dashboard';
import Customers from './components/customers/Customers';
import Stock     from './components/stock/Stock';
import Reports   from './components/reports/Reports';
import Settings  from './components/settings/Settings';

const Guard = ({ children }) => {
  const { seller, loading } = useAuth();
  if (loading) return (
    <div className="min-vh-100 d-flex flex-column align-items-center justify-content-center" style={{background:'#fdf4ff'}}>
      <div style={{fontSize:'3.5rem'}} className="mb-3">💍</div>
      <div className="spinner-border mb-2" style={{color:'#9333ea'}}/>
      <p style={{color:'#9333ea'}} className="fw-semibold">JewelKit loading...</p>
    </div>
  );
  return seller ? children : <Navigate to="/login"/>;
};

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster position="top-right" toastOptions={{
          success:{ style:{background:'#22c55e',color:'#fff'} },
          error:  { style:{background:'#ef4444',color:'#fff'} }
        }}/>
        <Routes>
          <Route path="/login" element={<Login/>}/>
          <Route path="/" element={<Guard><Layout/></Guard>}>
            <Route index            element={<Dashboard/>}/>
            <Route path="customers" element={<Customers/>}/>
            <Route path="stock"     element={<Stock/>}/>
            <Route path="reports"   element={<Reports/>}/>
            <Route path="settings"  element={<Settings/>}/>
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

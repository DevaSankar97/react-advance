import React, { useState } from 'react';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function Settings() {
  const { seller, logout } = useAuth();
  const [lang, setLang]     = useState(seller?.language || 'ta');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      await axios.put('/api/dash/settings', { language: lang, reminderEnabled: true });
      toast.success('Settings saved!');
    } catch { toast.error('Failed'); }
    finally { setSaving(false); }
  };

  const commands = {
    ta: [
      ['💰 Sale', '"Kavitha 500 vaangi"', 'Kavitha 500 ரூபாய் வாங்கினாள்'],
      ['💵 Payment', '"Kavitha 200 kuduthal"', 'Kavitha 200 ரூபாய் கொடுத்தாள்'],
      ['📊 Balance', '"Kavitha balance"', 'Kavitha balance பார்க்க'],
      ['📋 List', '"list"', 'எல்லா pending customers'],
      ['📈 Today', '"today"', 'இன்றைய summary'],
      ['📅 Report', '"report"', 'மாத அறிக்கை'],
      ['📦 Stock', '"stock"', 'Stock summary'],
      ['❓ Help', '"help"', 'All commands'],
    ],
    en: [
      ['💰 Sale', '"Kavitha bought 500"', 'Kavitha bought for ₹500'],
      ['💵 Payment', '"Kavitha paid 200"', 'Kavitha paid ₹200'],
      ['📊 Balance', '"Kavitha balance"', 'Check Kavitha balance'],
      ['📋 List', '"list"', 'All pending customers'],
      ['📈 Today', '"today"', 'Today summary'],
      ['📅 Report', '"report"', 'Monthly report'],
    ],
  };

  return (
    <div>
      <div className="mb-4">
        <h4 className="fw-bold mb-1"><i className="bi bi-gear-fill me-2" style={{color:'#9333ea'}}></i>Settings</h4>
        <p className="text-muted small mb-0">Bot language & account settings</p>
      </div>

      <div className="row g-4">
        {/* Account info */}
        <div className="col-12 col-lg-5">
          <div className="jk-card mb-4">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-person-circle me-2" style={{color:'#9333ea'}}></i>Account</h6>
              <div className="d-flex align-items-center gap-3 p-3 rounded-3 mb-3" style={{background:'linear-gradient(135deg,#fdf4ff,#ede9fe)'}}>
                <div className="rounded-circle d-flex align-items-center justify-content-center text-white fw-bold"
                  style={{width:52,height:52,background:'#9333ea',fontSize:'1.3rem'}}>
                  {seller?.name?.charAt(0)?.toUpperCase()}
                </div>
                <div>
                  <div className="fw-bold">{seller?.name}</div>
                  <div className="text-muted small">📱 {seller?.phone}</div>
                </div>
              </div>

              <div className="mb-4">
                <label className="form-label fw-semibold small">Bot Language / மொழி</label>
                <div className="d-flex gap-2">
                  {[
                    { v:'ta', l:'🇮🇳 தமிழ்' },
                    { v:'en', l:'🇬🇧 English' },
                    { v:'hi', l:'🇮🇳 हिंदी' },
                  ].map(opt => (
                    <button key={opt.v} onClick={()=>setLang(opt.v)}
                      className={`btn btn-sm flex-fill fw-semibold ${lang===opt.v?'btn-jk':'btn-outline-secondary'}`}>
                      {opt.l}
                    </button>
                  ))}
                </div>
                <div className="form-text">WhatsApp bot இந்த மொழியில் reply செய்யும்</div>
              </div>

              <button className="btn btn-jk fw-semibold w-100" onClick={save} disabled={saving}>
                {saving ? <><span className="spinner-border spinner-border-sm me-2"/>Saving...</> : '💾 Save Settings'}
              </button>
            </div>
          </div>

          {/* WhatsApp number info */}
          <div className="jk-card">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-whatsapp me-2 text-success"></i>WhatsApp Bot Number</h6>
              <div className="p-3 rounded-3 text-center" style={{background:'#f0fdf4',border:'1px solid #86efac'}}>
                <div className="text-muted small mb-1">இந்த number-la WhatsApp பண்ணுங்க:</div>
                <div className="fw-bold fs-5 text-success">{process.env.REACT_APP_BOT_NUMBER || 'Configure in .env'}</div>
              </div>
              <div className="mt-3 p-3 rounded-3" style={{background:'#fdf4ff'}}>
                <div className="small text-muted">
                  <strong>How to start:</strong><br/>
                  1. Above number-la WhatsApp open pannunga<br/>
                  2. "Hi" nu message panunga<br/>
                  3. Bot உங்கள் பேரு கேக்கும் — சொல்லுங்க<br/>
                  4. Ready! 💍
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Commands guide */}
        <div className="col-12 col-lg-7">
          <div className="jk-card">
            <div className="card-body">
              <h6 className="fw-bold mb-3">
                <i className="bi bi-chat-dots me-2" style={{color:'#9333ea'}}></i>
                WhatsApp Commands Guide / வழிகாட்டி
              </h6>
              <table className="table jk-table align-middle mb-0">
                <thead><tr><th>Command</th><th>Type</th><th>Meaning</th></tr></thead>
                <tbody>
                  {(commands[lang] || commands.ta).map(([cmd, example, meaning]) => (
                    <tr key={cmd}>
                      <td><span className="fw-semibold">{cmd}</span></td>
                      <td><code style={{background:'#fdf4ff',color:'#9333ea',padding:'2px 6px',borderRadius:4,fontSize:'.8rem'}}>{example}</code></td>
                      <td><small className="text-muted">{meaning}</small></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pricing */}
          <div className="jk-card mt-4">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-star-fill me-2 text-warning"></i>Subscription / சந்தா</h6>
              <div className="row g-3">
                {[
                  { plan:'Free Trial', price:'₹0', period:'14 days', features:['WhatsApp bot','Customer tracking','Balance check'], color:'#6b7280' },
                  { plan:'Paid Plan',  price:'₹99', period:'/month', features:['Everything in Free','Payment reminders','Stock alerts','Monthly reports'], color:'#9333ea', popular:true },
                ].map(p=>(
                  <div key={p.plan} className="col-md-6">
                    <div className="p-3 rounded-3 h-100" style={{border:`2px solid ${p.popular?p.color:'#e9d5ff'}`,background:p.popular?'#fdf4ff':'#fff'}}>
                      {p.popular && <div className="badge mb-2" style={{background:p.color,color:'#fff'}}>⭐ Best Value</div>}
                      <div className="fw-bold" style={{color:p.color}}>{p.plan}</div>
                      <div style={{fontSize:'1.8rem',fontWeight:800,color:p.color}}>{p.price}<span style={{fontSize:'1rem',fontWeight:400,color:'#888'}}> {p.period}</span></div>
                      {p.features.map(f=>(
                        <div key={f} className="d-flex align-items-center gap-2 mt-1">
                          <i className="bi bi-check-circle-fill" style={{color:p.color,fontSize:'.8rem'}}></i>
                          <small>{f}</small>
                        </div>
                      ))}
                      {p.popular && (
                        <div className="mt-3 p-2 rounded-2 text-center" style={{background:'#ede9fe'}}>
                          <small style={{color:p.color,fontWeight:600}}>PhonePe/GPay: 9940612737</small>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

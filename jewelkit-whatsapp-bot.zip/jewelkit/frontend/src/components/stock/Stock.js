import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

const CATS = ['necklace','bangles','earrings','rings','anklets','chains','sets','other'];
const CAT_ICONS = { necklace:'💎', bangles:'🔮', earrings:'✨', rings:'💍', anklets:'⭕', chains:'🔗', sets:'💼', other:'📦' };
const blank = { name:'', category:'necklace', quantity:'', costPrice:'', sellPrice:'', minQuantity:'2', notes:'' };

export default function Stock() {
  const [stocks, setStocks]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal]     = useState(false);
  const [adjModal, setAdj]    = useState(null);
  const [form, setForm]       = useState(blank);
  const [editId, setEditId]   = useState(null);
  const [adjQty, setAdjQty]   = useState('');
  const [adjType, setAdjType] = useState('add');

  const load = useCallback(async () => {
    setLoading(true);
    try { const r = await axios.get('/api/dash/stock'); setStocks(r.data.stocks); }
    catch { toast.error('Failed to load stock'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const save = async (e) => {
    e.preventDefault();
    try {
      if (editId) { await axios.put(`/api/dash/stock/${editId}`, form); toast.success('Updated!'); }
      else        { await axios.post('/api/dash/stock', form); toast.success('Stock item added!'); }
      setModal(false); setForm(blank); setEditId(null); load();
    } catch (err) { toast.error(err.response?.data?.message||'Failed'); }
  };

  const adjust = async () => {
    if (!adjQty) { toast.error('Quantity enter pannunga'); return; }
    const qty  = parseInt(adjQty);
    const item = stocks.find(s=>s._id===adjModal._id);
    const newQ = adjType==='add' ? item.quantity+qty : Math.max(0,item.quantity-qty);
    try {
      await axios.put(`/api/dash/stock/${adjModal._id}`, { quantity: newQ });
      toast.success(adjType==='add' ? `${qty} pieces added!` : `${qty} pieces sold/used!`);
      setAdj(null); setAdjQty(''); load();
    } catch { toast.error('Failed'); }
  };

  const del = async (id) => {
    if (!window.confirm('Remove this item?')) return;
    try { await axios.delete(`/api/dash/stock/${id}`); toast.success('Removed'); load(); }
    catch { toast.error('Failed'); }
  };

  const low = stocks.filter(s => s.quantity <= s.minQuantity);
  const totalValue = stocks.reduce((s,i) => s + (i.quantity * i.costPrice), 0);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1"><i className="bi bi-gem me-2" style={{color:'#9333ea'}}></i>Stock / பொருள்</h4>
          <p className="text-muted small mb-0">{stocks.length} items • Value: ₹{totalValue.toLocaleString('en-IN')}</p>
        </div>
        <button className="btn btn-jk fw-semibold" onClick={()=>{setModal(true);setForm(blank);setEditId(null);}}>
          <i className="bi bi-plus-circle me-2"></i>Add Item
        </button>
      </div>

      {low.length > 0 && (
        <div className="alert alert-warning mb-4 border-0 d-flex gap-2" style={{background:'#fef9c3',borderLeft:'4px solid #f59e0b',borderRadius:10}}>
          <i className="bi bi-exclamation-triangle-fill text-warning fs-5"></i>
          <div><strong>⚠️ Low Stock:</strong> {low.map(i=>`${i.name} (${i.quantity})`).join(', ')}</div>
        </div>
      )}

      {loading ? <div className="jk-loading"><div className="spinner-border" style={{color:'#9333ea'}}/></div> : (
        <div className="row g-3">
          {stocks.map(item => {
            const isLow = item.quantity <= item.minQuantity;
            const profit = item.sellPrice - item.costPrice;
            return (
              <div key={item._id} className="col-12 col-md-6 col-lg-4">
                <div className="jk-card h-100" style={{borderLeft:`4px solid ${isLow?'#ef4444':'#9333ea'}`}}>
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-start mb-2">
                      <div>
                        <div className="fw-bold">{CAT_ICONS[item.category]||'📦'} {item.name}</div>
                        <span className="badge rounded-pill mt-1" style={{background:'#fdf4ff',color:'#9333ea',fontSize:'.68rem'}}>{item.category}</span>
                      </div>
                      {isLow && <span className="badge bg-warning text-dark" style={{fontSize:'.68rem'}}>⚠️ Low</span>}
                    </div>

                    <div className="row g-2 mb-3">
                      <div className="col-4 text-center p-2 rounded-3" style={{background:isLow?'#fee2e2':'#dcfce7'}}>
                        <div className="fw-bold fs-5" style={{color:isLow?'#dc2626':'#16a34a'}}>{item.quantity}</div>
                        <div style={{fontSize:'.65rem',color:'#888'}}>pieces</div>
                      </div>
                      <div className="col-4 text-center p-2 rounded-3" style={{background:'#fdf4ff'}}>
                        <div className="fw-bold" style={{color:'#9333ea'}}>₹{item.costPrice}</div>
                        <div style={{fontSize:'.65rem',color:'#888'}}>cost</div>
                      </div>
                      <div className="col-4 text-center p-2 rounded-3" style={{background:'#f0fdf4'}}>
                        <div className="fw-bold text-success">₹{item.sellPrice}</div>
                        <div style={{fontSize:'.65rem',color:'#888'}}>sell</div>
                      </div>
                    </div>

                    {profit > 0 && (
                      <div className="text-center mb-3 small text-success">
                        💚 Profit per piece: ₹{profit} ({Math.round(profit/item.costPrice*100)}%)
                      </div>
                    )}

                    <div className="d-flex gap-2">
                      <button className="btn btn-sm btn-jk flex-fill" onClick={()=>{setAdj(item);setAdjType('add');setAdjQty('');}}>
                        <i className="bi bi-plus me-1"></i>Stock Add
                      </button>
                      <button className="btn btn-sm btn-outline-warning flex-fill" onClick={()=>{setAdj(item);setAdjType('use');setAdjQty('');}}>
                        <i className="bi bi-dash me-1"></i>Sold/Used
                      </button>
                      <button className="btn btn-sm btn-outline-primary" onClick={()=>{setForm({name:item.name,category:item.category,quantity:item.quantity,costPrice:item.costPrice,sellPrice:item.sellPrice,minQuantity:item.minQuantity,notes:item.notes||''});setEditId(item._id);setModal(true);}}>
                        <i className="bi bi-pencil"></i>
                      </button>
                      <button className="btn btn-sm btn-outline-danger" onClick={()=>del(item._id)}>
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
          {!stocks.length && !loading && (
            <div className="col-12 text-center py-5 text-muted">
              <div style={{fontSize:'3rem',opacity:.3}}>💍</div>
              <p>No stock items. Add your jewellery stock!</p>
            </div>
          )}
        </div>
      )}

      {/* Add/Edit Modal */}
      {modal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header"><h5 className="modal-title fw-bold">💍 {editId?'Edit':'Add'} Stock Item</h5><button className="btn-close" onClick={()=>setModal(false)}/></div>
              <div className="modal-body">
                <form id="stockForm" onSubmit={save}>
                  <div className="row g-3">
                    <div className="col-12"><label className="form-label fw-semibold small">Item Name *</label>
                      <input className="form-control" placeholder="Gold necklace" value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))} required/></div>
                    <div className="col-md-6"><label className="form-label fw-semibold small">Category</label>
                      <select className="form-select" value={form.category} onChange={e=>setForm(p=>({...p,category:e.target.value}))}>
                        {CATS.map(c=><option key={c} value={c}>{CAT_ICONS[c]} {c}</option>)}
                      </select></div>
                    <div className="col-md-6"><label className="form-label fw-semibold small">Quantity *</label>
                      <input type="number" className="form-control" placeholder="50" value={form.quantity} onChange={e=>setForm(p=>({...p,quantity:e.target.value}))} required/></div>
                    <div className="col-md-6"><label className="form-label fw-semibold small">Cost Price (₹)</label>
                      <div className="input-group"><span className="input-group-text">₹</span>
                        <input type="number" className="form-control" placeholder="100" value={form.costPrice} onChange={e=>setForm(p=>({...p,costPrice:e.target.value}))}/></div></div>
                    <div className="col-md-6"><label className="form-label fw-semibold small">Sell Price (₹)</label>
                      <div className="input-group"><span className="input-group-text">₹</span>
                        <input type="number" className="form-control" placeholder="250" value={form.sellPrice} onChange={e=>setForm(p=>({...p,sellPrice:e.target.value}))}/></div></div>
                    <div className="col-md-6"><label className="form-label fw-semibold small">Min Stock Alert</label>
                      <input type="number" className="form-control" placeholder="5" value={form.minQuantity} onChange={e=>setForm(p=>({...p,minQuantity:e.target.value}))}/></div>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={()=>setModal(false)}>Cancel</button>
                <button type="submit" form="stockForm" className="btn btn-jk fw-semibold">{editId?'Update':'Add Item'}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Adjust Modal */}
      {adjModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold">{adjType==='add'?'📦 Stock Add':'✅ Sold/Used'} — {adjModal.name}</h5>
                <button className="btn-close" onClick={()=>setAdj(null)}/>
              </div>
              <div className="modal-body">
                <div className="d-flex gap-2 mb-3">
                  {['add','use'].map(t=>(
                    <button key={t} onClick={()=>setAdjType(t)}
                      className={`btn btn-sm flex-fill fw-semibold ${adjType===t?'btn-jk':'btn-outline-secondary'}`}>
                      {t==='add'?'📦 Stock Add':'✅ Sold/Used'}
                    </button>
                  ))}
                </div>
                <div className="alert alert-light border text-center">
                  Current stock: <strong>{adjModal.quantity} pieces</strong>
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Quantity *</label>
                  <input type="number" className="form-control form-control-lg text-center"
                    placeholder="Enter quantity" value={adjQty} onChange={e=>setAdjQty(e.target.value)} autoFocus/>
                </div>
                {adjQty && (
                  <div className="text-center p-3 rounded-3" style={{background:'#fdf4ff'}}>
                    <div className="text-muted small">After this:</div>
                    <div className="fw-bold fs-4" style={{color:'#9333ea'}}>
                      {adjType==='add' ? adjModal.quantity+parseInt(adjQty||0) : Math.max(0,adjModal.quantity-parseInt(adjQty||0))} pieces
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={()=>setAdj(null)}>Cancel</button>
                <button className="btn btn-jk fw-semibold" onClick={adjust}>
                  <i className="bi bi-check-circle me-2"></i>Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

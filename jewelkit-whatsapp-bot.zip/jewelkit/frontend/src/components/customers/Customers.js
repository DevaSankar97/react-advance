import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

const blank = { name:'', phone:'', area:'', notes:'' };

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [showModal, setModal]     = useState(false);
  const [txnModal, setTxnModal]   = useState(null);
  const [histModal, setHistModal] = useState(null);
  const [history, setHistory]     = useState([]);
  const [form, setForm]           = useState(blank);
  const [editId, setEditId]       = useState(null);
  const [txnForm, setTxnForm]     = useState({ type:'sale', amount:'', items:'', notes:'' });
  const [search, setSearch]       = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { const r = await axios.get(`/api/dash/customers?search=${search}`); setCustomers(r.data.customers); }
    catch { toast.error('Failed to load'); }
    finally { setLoading(false); }
  }, [search]);

  useEffect(() => { load(); }, [load]);

  const save = async (e) => {
    e.preventDefault();
    try {
      if (editId) { await axios.put(`/api/dash/customers/${editId}`, form); toast.success('Updated!'); }
      else        { await axios.post('/api/dash/customers', form); toast.success('Customer added!'); }
      setModal(false); setForm(blank); setEditId(null); load();
    } catch (err) { toast.error(err.response?.data?.message||'Failed'); }
  };

  const addTxn = async () => {
    if (!txnForm.amount) { toast.error('Amount enter pannunga'); return; }
    try {
      await axios.post('/api/dash/transactions', { customerId: txnModal._id, ...txnForm });
      toast.success(txnForm.type==='sale' ? 'Sale added! ✅' : 'Payment recorded! ✅');
      setTxnModal(null); setTxnForm({ type:'sale', amount:'', items:'', notes:'' }); load();
    } catch (err) { toast.error(err.response?.data?.message||'Failed'); }
  };

  const loadHistory = async (customer) => {
    setHistModal(customer);
    const r = await axios.get(`/api/dash/transactions?customerId=${customer._id}&limit=20`);
    setHistory(r.data.transactions);
  };

  const delTxn = async (id) => {
    if (!window.confirm('Delete this entry?')) return;
    try {
      await axios.delete(`/api/dash/transactions/${id}`);
      toast.success('Deleted!');
      loadHistory(histModal); load();
    } catch { toast.error('Failed'); }
  };

  const totalDue = customers.reduce((s,c) => s+c.totalDue, 0);
  const pending  = customers.filter(c=>c.totalDue>0).length;

  return (
    <div>
      <div className="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1"><i className="bi bi-people-fill me-2" style={{color:'#9333ea'}}></i>Customers / கடனாளிகள்</h4>
          <p className="text-muted small mb-0">{pending} pending • Total due: ₹{totalDue.toLocaleString('en-IN')}</p>
        </div>
        <button className="btn btn-jk fw-semibold" onClick={()=>{setModal(true);setForm(blank);setEditId(null);}}>
          <i className="bi bi-person-plus me-2"></i>Add Customer
        </button>
      </div>

      {/* Search */}
      <div className="mb-3">
        <div className="input-group" style={{maxWidth:280}}>
          <span className="input-group-text bg-white"><i className="bi bi-search text-muted"></i></span>
          <input className="form-control" placeholder="Search name..." value={search} onChange={e=>setSearch(e.target.value)}/>
        </div>
      </div>

      {loading ? <div className="jk-loading"><div className="spinner-border" style={{color:'#9333ea'}}/></div> : (
        <div className="row g-3">
          {customers.map(c => (
            <div key={c._id} className="col-12 col-md-6 col-lg-4">
              <div className="jk-card h-100" style={{borderLeft:`4px solid ${c.totalDue>0?'#ef4444':'#22c55e'}`}}>
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <div>
                      <div className="fw-bold fs-6">{c.name}</div>
                      {c.phone && <small className="text-muted"><i className="bi bi-phone me-1"></i>{c.phone}</small>}
                      {c.area  && <><br/><small className="text-muted"><i className="bi bi-geo-alt me-1"></i>{c.area}</small></>}
                    </div>
                    <div className="text-end">
                      <div className={`fw-bold fs-5 ${c.totalDue>0?'text-danger':'text-success'}`}>
                        ₹{c.totalDue.toLocaleString('en-IN')}
                      </div>
                      <span className={`badge rounded-pill ${c.totalDue>0?'badge-due':'badge-clear'}`} style={{fontSize:'.68rem'}}>
                        {c.totalDue>0?'Pending':'Clear ✓'}
                      </span>
                    </div>
                  </div>

                  <div className="d-flex gap-2 mt-3">
                    <button className="btn btn-sm btn-jk flex-fill"
                      onClick={()=>{setTxnModal(c);setTxnForm({type:'sale',amount:'',items:'',notes:''});}}>
                      <i className="bi bi-plus me-1"></i>Sale
                    </button>
                    <button className="btn btn-sm btn-success flex-fill"
                      onClick={()=>{setTxnModal(c);setTxnForm({type:'payment',amount:'',items:'',notes:''});}}>
                      <i className="bi bi-cash me-1"></i>Payment
                    </button>
                    <button className="btn btn-sm btn-outline-secondary" onClick={()=>loadHistory(c)} title="History">
                      <i className="bi bi-clock-history"></i>
                    </button>
                    <button className="btn btn-sm btn-outline-primary" onClick={()=>{setForm({name:c.name,phone:c.phone||'',area:c.area||'',notes:c.notes||''});setEditId(c._id);setModal(true);}}>
                      <i className="bi bi-pencil"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {!customers.length && !loading && (
            <div className="col-12 text-center py-5 text-muted">
              <i className="bi bi-people" style={{fontSize:'3rem',opacity:.3,display:'block',marginBottom:'1rem'}}></i>
              No customers yet. Add your first customer!<br/>
              <small>WhatsApp-la "Kavitha 500 vaangi" nu type pannalum customer create aagum!</small>
            </div>
          )}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header"><h5 className="modal-title fw-bold">💍 {editId?'Edit':'Add'} Customer</h5><button className="btn-close" onClick={()=>setModal(false)}/></div>
              <div className="modal-body">
                <form id="custForm" onSubmit={save}>
                  <div className="mb-3"><label className="form-label fw-semibold small">Name *</label>
                    <input className="form-control" placeholder="Kavitha" value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))} required/></div>
                  <div className="mb-3"><label className="form-label fw-semibold small">Phone (for reminders)</label>
                    <input className="form-control" placeholder="9876543210" maxLength={10} value={form.phone} onChange={e=>setForm(p=>({...p,phone:e.target.value.replace(/\D/g,'')}))}/></div>
                  <div className="mb-3"><label className="form-label fw-semibold small">Area / பகுதி</label>
                    <input className="form-control" placeholder="Anna Nagar" value={form.area} onChange={e=>setForm(p=>({...p,area:e.target.value}))}/></div>
                  <div className="mb-3"><label className="form-label fw-semibold small">Notes</label>
                    <input className="form-control" placeholder="Any notes..." value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))}/></div>
                </form>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={()=>setModal(false)}>Cancel</button>
                <button type="submit" form="custForm" className="btn btn-jk fw-semibold">{editId?'Update':'Add Customer'}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Transaction Modal */}
      {txnModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold">
                  {txnForm.type==='sale'?'💰 Sale':'💵 Payment'} — {txnModal.name}
                </h5>
                <button className="btn-close" onClick={()=>setTxnModal(null)}/>
              </div>
              <div className="modal-body">
                <div className="d-flex gap-2 mb-3">
                  {['sale','payment'].map(t => (
                    <button key={t} onClick={()=>setTxnForm(p=>({...p,type:t}))}
                      className={`btn btn-sm flex-fill fw-semibold ${txnForm.type===t?'btn-jk':'btn-outline-secondary'}`}>
                      {t==='sale'?'💰 Sale':'💵 Payment'}
                    </button>
                  ))}
                </div>
                <div className="alert alert-light border d-flex justify-content-between">
                  <span className="text-muted small">Current balance:</span>
                  <span className="fw-bold text-danger">₹{txnModal.totalDue}</span>
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Amount (₹) *</label>
                  <div className="input-group input-group-lg">
                    <span className="input-group-text fw-bold">₹</span>
                    <input type="number" className="form-control" placeholder="500"
                      value={txnForm.amount} onChange={e=>setTxnForm(p=>({...p,amount:e.target.value}))} autoFocus/>
                  </div>
                </div>
                {txnForm.type==='sale' && (
                  <div className="mb-3">
                    <label className="form-label fw-semibold small">Items (optional)</label>
                    <input className="form-control" placeholder="3 necklace, 2 bangles"
                      value={txnForm.items} onChange={e=>setTxnForm(p=>({...p,items:e.target.value}))}/>
                  </div>
                )}
                {txnForm.amount && (
                  <div className="p-3 rounded-3 text-center" style={{background:'#fdf4ff'}}>
                    <div className="text-muted small">New balance after this:</div>
                    <div className="fw-bold fs-5" style={{color: txnForm.type==='sale'?'#ef4444':'#22c55e'}}>
                      ₹{Math.max(0, txnModal.totalDue + (txnForm.type==='sale' ? parseFloat(txnForm.amount||0) : -parseFloat(txnForm.amount||0)))}
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={()=>setTxnModal(null)}>Cancel</button>
                <button className="btn btn-jk fw-semibold" onClick={addTxn}>
                  <i className="bi bi-check-circle me-2"></i>Save Entry
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* History Modal */}
      {histModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold">📋 {histModal.name} — History</h5>
                <button className="btn-close" onClick={()=>setHistModal(null)}/>
              </div>
              <div className="modal-body p-0">
                <div className="p-3 d-flex justify-content-between align-items-center" style={{background:'#fdf4ff'}}>
                  <span className="text-muted small">Current balance:</span>
                  <span className="fw-bold text-danger fs-5">₹{histModal.totalDue}</span>
                </div>
                <table className="table jk-table align-middle mb-0">
                  <thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Balance</th><th>Items</th><th></th></tr></thead>
                  <tbody>
                    {history.map(t => (
                      <tr key={t._id}>
                        <td><small>{new Date(t.date).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}</small></td>
                        <td><span className={`badge ${t.type==='sale'?'bg-danger':'bg-success'}`}>{t.type}</span></td>
                        <td className="fw-bold">₹{t.type==='sale'?t.saleAmount:t.paidAmount}</td>
                        <td><small style={{color: t.balanceAfter>0?'#ef4444':'#22c55e'}}>₹{t.balanceAfter}</small></td>
                        <td><small className="text-muted">{t.items||'—'}</small></td>
                        <td><button className="btn btn-sm btn-outline-danger" onClick={()=>delTxn(t._id)}><i className="bi bi-trash"></i></button></td>
                      </tr>
                    ))}
                    {!history.length && <tr><td colSpan={6} className="text-center text-muted py-3">No transactions yet</td></tr>}
                  </tbody>
                </table>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={()=>setHistModal(null)}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function Dashboard() {
  const [data, setData]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState(null);

  const fetch = useCallback(async () => {
    setLoading(true); setError(null);
    try { const r = await axios.get('/api/dash/summary'); setData(r.data.summary); }
    catch { setError('Failed to load. Please refresh.'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  if (loading) return <div className="jk-loading"><div className="spinner-border" style={{color:'#9333ea'}}/><span className="mt-2 text-muted">Loading...</span></div>;
  if (error)   return <div className="alert alert-danger">{error} <button className="btn btn-sm btn-danger ms-2" onClick={fetch}>Retry</button></div>;

  const cards = [
    { icon:'👥', label:'Customers / கடனாளிகள்', value:data?.customers?.total||0,   sub:`${data?.customers?.pending||0} pending`, color:'#9333ea', bg:'#fdf4ff' },
    { icon:'💰', label:'Inru Sale / இன்று விற்பனை', value:`₹${data?.today?.sales||0}`,  sub:'Today sales',   color:'#E07B39', bg:'#FFF0E8' },
    { icon:'💵', label:'Collection / வசூல்',    value:`₹${data?.today?.collected||0}`,sub:'Today collected',color:'#22c55e', bg:'#dcfce7' },
    { icon:'📌', label:'Total Due / மொத்த கடன்', value:`₹${(data?.customers?.totalDue||0).toLocaleString('en-IN')}`,sub:`${data?.customers?.pending||0} customers`,color:'#ef4444',bg:'#fee2e2'},
  ];

  const quick = [
    { icon:'👥', label:'Add Customer / Customer சேர்',    path:'/customers', color:'#9333ea' },
    { icon:'💰', label:'Add Sale / Sale entry போடு',      path:'/customers', color:'#E07B39' },
    { icon:'📦', label:'Check Stock / Stock பார்',         path:'/stock',     color:'#22c55e' },
    { icon:'📊', label:'Monthly Report / மாத அறிக்கை',    path:'/reports',   color:'#6366f1' },
  ];

  return (
    <div>
      <div className="mb-4">
        <h4 className="fw-bold mb-1">💍 Dashboard</h4>
        <p className="text-muted small mb-0">{new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</p>
      </div>

      {/* Stat cards */}
      <div className="row g-3 mb-4">
        {cards.map(c => (
          <div key={c.label} className="col-6 col-md-3">
            <div className="jk-card" style={{borderTop:`3px solid ${c.color}`}}>
              <div className="card-body py-3 d-flex align-items-center gap-3">
                <div className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                  style={{width:44,height:44,background:c.bg,fontSize:'1.2rem'}}>{c.icon}</div>
                <div>
                  <div className="fw-bold" style={{color:c.color,fontSize:'1.15rem'}}>{c.value}</div>
                  <div className="text-muted" style={{fontSize:'.72rem',lineHeight:1.3}}>{c.label}</div>
                  <div className="text-muted" style={{fontSize:'.68rem'}}>{c.sub}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* WhatsApp command reminder */}
      <div className="jk-card p-3 mb-4" style={{background:'linear-gradient(135deg,#fdf4ff,#ede9fe)',border:'1px solid #e9d5ff'}}>
        <div className="fw-bold mb-2" style={{color:'#9333ea'}}>📱 WhatsApp Commands / WhatsApp Commands:</div>
        <div className="row g-2">
          {[
            ['💰 Sale', '"Kavitha 500 vaangi"'],
            ['💵 Payment', '"Kavitha 200 kuduthal"'],
            ['📊 Balance', '"Kavitha balance"'],
            ['📋 List', '"list"'],
          ].map(([label, cmd]) => (
            <div key={label} className="col-6 col-md-3">
              <div className="p-2 rounded-3 text-center" style={{background:'rgba(147,51,234,.1)'}}>
                <div className="fw-semibold" style={{fontSize:'.82rem',color:'#9333ea'}}>{label}</div>
                <div className="text-muted" style={{fontSize:'.75rem',fontFamily:'monospace'}}>{cmd}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chart + Quick Actions */}
      <div className="row g-3">
        <div className="col-12 col-lg-8">
          <div className="jk-card h-100">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-graph-up me-2" style={{color:'#9333ea'}}></i>6 Month Trend</h6>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={data?.trend||[]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f0ff"/>
                  <XAxis dataKey="month" tick={{fontSize:11,fill:'#888'}}/>
                  <YAxis tick={{fontSize:11,fill:'#888'}} tickFormatter={v=>`₹${v}`}/>
                  <Tooltip formatter={v=>[`₹${v}`,'']}/>
                  <Bar dataKey="sales"     name="Sales"     fill="#9333ea" radius={[4,4,0,0]}/>
                  <Bar dataKey="collected" name="Collected" fill="#22c55e" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        <div className="col-12 col-lg-4">
          <div className="jk-card h-100">
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-lightning-charge me-2" style={{color:'#9333ea'}}></i>Quick Actions</h6>
              {quick.map(q => (
                <Link key={q.label} to={q.path} className="d-flex align-items-center gap-2 p-2 mb-2 rounded-3 text-decoration-none"
                  style={{background:`${q.color}12`,border:`1px solid ${q.color}25`,transition:'transform .2s'}}
                  onMouseEnter={e=>e.currentTarget.style.transform='translateX(4px)'}
                  onMouseLeave={e=>e.currentTarget.style.transform='translateX(0)'}>
                  <span style={{fontSize:'1.1rem'}}>{q.icon}</span>
                  <span style={{color:q.color,fontWeight:500,fontSize:'.83rem'}}>{q.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

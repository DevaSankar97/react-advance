import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const [phone, setPhone] = useState('');
  const [pin, setPin]     = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate  = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    if (phone.length !== 10) { toast.error('10 digit mobile number enter pannunga'); return; }
    setLoading(true);
    try {
      await login('+91'+phone, pin||'1234');
      toast.success('Welcome! 💍');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed. Check phone number.');
    } finally { setLoading(false); }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center"
      style={{background:'linear-gradient(135deg,#fdf4ff,#ede9fe)'}}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12 col-sm-8 col-md-5 col-lg-4">
            <div className="card border-0 shadow p-4" style={{borderRadius:20}}>
              <div className="text-center mb-4">
                <div style={{fontSize:'3.5rem'}}>💍</div>
                <h3 className="fw-bold mt-2 mb-1" style={{color:'#9333ea'}}>JewelKit</h3>
                <p className="text-muted small">உங்கள் கடன் கணக்கு tracker</p>
              </div>

              <form onSubmit={submit}>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">
                    📱 Mobile Number / மொபைல் நம்பர்
                  </label>
                  <div className="input-group">
                    <span className="input-group-text fw-bold">+91</span>
                    <input type="tel" className="form-control form-control-lg"
                      placeholder="9876543210" maxLength={10}
                      value={phone} onChange={e=>setPhone(e.target.value.replace(/\D/g,''))}
                      required/>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="form-label fw-semibold small">
                    🔑 PIN (4 digit) — First time: 1234
                  </label>
                  <input type="password" className="form-control form-control-lg"
                    placeholder="4 digit PIN" maxLength={4}
                    value={pin} onChange={e=>setPin(e.target.value.replace(/\D/g,''))}/>
                  <div className="form-text">முதல் முறை login: PIN 1234 போடுங்க</div>
                </div>

                <button type="submit" className="btn btn-jk btn-lg w-100 fw-bold" disabled={loading}>
                  {loading
                    ? <><span className="spinner-border spinner-border-sm me-2"/>Loading...</>
                    : '✨ Login / உள்நுழை'}
                </button>
              </form>

              <hr className="my-3"/>
              <div className="text-center p-3 rounded-3" style={{background:'#fdf4ff'}}>
                <p className="small text-muted mb-1">📱 WhatsApp இல் பயன்படுத்த:</p>
                <p className="fw-bold mb-0" style={{color:'#9333ea'}}>
                  Kavitha 500 vaangi<br/>
                  <small className="text-muted fw-normal">(Sale entry)</small>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function Reports() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth()+1);
  const [year,  setYear]  = useState(now.getFullYear());
  const [data,  setData]  = useState(null);
  const [loading, setLoading] = useState(true);
  const [txns, setTxns]   = useState([]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [rep, tr] = await Promise.all([
        axios.get(`/api/dash/report?month=${month}&year=${year}`),
        axios.get(`/api/dash/transactions?month=${month}&year=${year}&limit=100`)
      ]);
      setData(rep.data.report);
      setTxns(tr.data.transactions);
    } catch { }
    finally { setLoading(false); }
  }, [month, year]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <div className="jk-loading"><div className="spinner-border" style={{color:'#9333ea'}}/></div>;

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1"><i className="bi bi-graph-up me-2" style={{color:'#9333ea'}}></i>Reports / அறிக்கை</h4>
          <p className="text-muted small mb-0">{MONTHS[month-1]} {year}</p>
        </div>
        <div className="d-flex gap-2">
          <select className="form-select form-select-sm" style={{width:'auto'}} value={month} onChange={e=>setMonth(parseInt(e.target.value))}>
            {MONTHS.map((m,i)=><option key={m} value={i+1}>{m}</option>)}
          </select>
          <select className="form-select form-select-sm" style={{width:'auto'}} value={year} onChange={e=>setYear(parseInt(e.target.value))}>
            {[2024,2025,2026,2027].map(y=><option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </div>

      {/* Summary cards */}
      <div className="row g-3 mb-4">
        {[
          { icon:'💰', label:'Total Sales / மொத்த விற்பனை', value:`₹${(data?.sales||0).toLocaleString('en-IN')}`,    color:'#9333ea', bg:'#fdf4ff' },
          { icon:'💵', label:'Collected / வசூல்',           value:`₹${(data?.collected||0).toLocaleString('en-IN')}`,color:'#22c55e', bg:'#dcfce7' },
          { icon:'📌', label:'Pending / பாக்கி',            value:`₹${(data?.totalPending||0).toLocaleString('en-IN')}`,color:'#ef4444',bg:'#fee2e2'},
          { icon:'📊', label:'Transactions',                 value:txns.length,                                       color:'#6366f1', bg:'#e0e7ff' },
        ].map(s=>(
          <div key={s.label} className="col-6 col-md-3">
            <div className="jk-card" style={{borderTop:`3px solid ${s.color}`}}>
              <div className="card-body py-3">
                <div className="d-flex align-items-center gap-2">
                  <div className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                    style={{width:40,height:40,background:s.bg,fontSize:'1.1rem'}}>{s.icon}</div>
                  <div>
                    <div className="fw-bold" style={{color:s.color}}>{s.value}</div>
                    <div className="text-muted" style={{fontSize:'.7rem'}}>{s.label}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Top customers owing money */}
      {data?.topCustomers?.length > 0 && (
        <div className="jk-card mb-4">
          <div className="card-body">
            <h6 className="fw-bold mb-3"><i className="bi bi-people me-2" style={{color:'#9333ea'}}></i>Top Pending Customers</h6>
            {data.topCustomers.filter(c=>c.totalDue>0).map((c,i)=>(
              <div key={c._id} className="d-flex justify-content-between align-items-center py-2 border-bottom">
                <div className="d-flex align-items-center gap-2">
                  <span className="badge rounded-pill" style={{background:'#fdf4ff',color:'#9333ea'}}>{i+1}</span>
                  <span className="fw-semibold">{c.name}</span>
                </div>
                <span className="fw-bold text-danger">₹{c.totalDue.toLocaleString('en-IN')}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Transaction list */}
      <div className="jk-card">
        <div className="card-body">
          <h6 className="fw-bold mb-3"><i className="bi bi-list-ul me-2" style={{color:'#9333ea'}}></i>All Transactions — {MONTHS[month-1]} {year}</h6>
          <div className="table-responsive">
            <table className="table jk-table align-middle mb-0">
              <thead><tr><th>Date</th><th>Customer</th><th>Type</th><th>Amount</th><th>Items</th><th>Balance</th></tr></thead>
              <tbody>
                {txns.map(t=>(
                  <tr key={t._id}>
                    <td><small>{new Date(t.date).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}</small></td>
                    <td className="fw-semibold">{t.customer?.name||'—'}</td>
                    <td><span className={`badge ${t.type==='sale'?'bg-danger':'bg-success'}`}>{t.type}</span></td>
                    <td className="fw-bold">₹{t.type==='sale'?t.saleAmount:t.paidAmount}</td>
                    <td><small className="text-muted">{t.items||'—'}</small></td>
                    <td><small style={{color:t.balanceAfter>0?'#ef4444':'#22c55e'}}>₹{t.balanceAfter}</small></td>
                  </tr>
                ))}
                {!txns.length && <tr><td colSpan={6} className="text-center text-muted py-4">No transactions this month</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const navItems = [
  { path:'/',          icon:'bi-speedometer2', label:'Dashboard',        labelTa:'Dashboard'   },
  { path:'/customers', icon:'bi-people-fill',  label:'Customers / கடன்', labelTa:'கடன் பட்டியல்'},
  { path:'/stock',     icon:'bi-gem',          label:'Stock / பொருள்',   labelTa:'பொருள் stock' },
  { path:'/reports',   icon:'bi-graph-up',     label:'Reports / அறிக்கை',labelTa:'அறிக்கை'     },
  { path:'/settings',  icon:'bi-gear-fill',    label:'Settings',         labelTa:'Settings'    },
];

export default function Layout() {
  const { seller, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="d-flex" style={{minHeight:'100vh'}}>
      {/* Sidebar */}
      <div className={`jk-sidebar d-flex flex-column ${collapsed?'collapsed':''}`}>
        <div className="p-3" style={{borderBottom:'1px solid rgba(255,255,255,.1)'}}>
          <div className="d-flex align-items-center gap-2">
            <span style={{fontSize:'1.6rem',flexShrink:0}}>💍</span>
            {!collapsed && (
              <div>
                <div className="text-white fw-bold" style={{fontSize:'.95rem'}}>JewelKit</div>
                <div style={{fontSize:'.65rem',color:'rgba(255,255,255,.4)'}}>{seller?.name}</div>
              </div>
            )}
          </div>
        </div>

        <nav className="flex-grow-1 py-2">
          {navItems.map(item => (
            <NavLink key={item.path} to={item.path} end={item.path==='/'}
              className={({isActive}) => `jk-nav-link ${isActive?'active':''}`}>
              <i className={`bi ${item.icon}`} style={{fontSize:'1.1rem',minWidth:20,textAlign:'center'}}></i>
              {!collapsed && <span style={{fontSize:'.83rem'}}>{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        <div className="p-3" style={{borderTop:'1px solid rgba(255,255,255,.08)'}}>
          {!collapsed && <div className="text-white-50 small mb-2">📱 {seller?.phone}</div>}
          <button onClick={() => { logout(); navigate('/login'); toast.success('Logged out!'); }}
            className="btn btn-sm w-100 text-white border-0 d-flex align-items-center gap-2"
            style={{background:'rgba(255,255,255,.1)',justifyContent:collapsed?'center':'flex-start'}}>
            <i className="bi bi-box-arrow-left"></i>
            {!collapsed && <span style={{fontSize:'.82rem'}}>Logout</span>}
          </button>
        </div>
      </div>

      {/* Main */}
      <div className="flex-grow-1 d-flex flex-column" style={{minWidth:0,maxHeight:'100vh',overflowY:'auto'}}>
        <div className="jk-topbar">
          <button className="btn btn-sm btn-light border-0" onClick={() => setCollapsed(!collapsed)}>
            <i className="bi bi-list fs-5"></i>
          </button>
          <div className="d-flex align-items-center gap-2">
            <small className="text-muted d-none d-md-block">
              {new Date().toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short'})}
            </small>
            <div className="rounded-circle d-flex align-items-center justify-content-center text-white fw-bold"
              style={{width:34,height:34,background:'#9333ea',fontSize:'.88rem',flexShrink:0}}>
              {seller?.name?.charAt(0)?.toUpperCase() || '?'}
            </div>
          </div>
        </div>

        <div className="p-3 p-md-4 flex-grow-1 fade-in">
          <Outlet/>
        </div>
      </div>
    </div>
  );
}

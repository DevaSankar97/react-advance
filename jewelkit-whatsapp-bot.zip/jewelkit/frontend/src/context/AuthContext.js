import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
const Ctx = createContext();
export const useAuth = () => useContext(Ctx);
export const AuthProvider = ({ children }) => {
  const [seller, setSeller]   = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const token = localStorage.getItem('jk_token');
    if (token) {
      axios.defaults.headers.common['Authorization'] = 'Bearer '+token;
      axios.get('/api/dash/summary')
        .then(() => { const s = JSON.parse(localStorage.getItem('jk_seller')||'{}'); setSeller(s); })
        .catch(() => logout())
        .finally(() => setLoading(false));
    } else { setLoading(false); }
  }, []);
  const login = async (phone, pin) => {
    const { data } = await axios.post('/api/dash/login', { phone, pin });
    localStorage.setItem('jk_token', data.token);
    localStorage.setItem('jk_seller', JSON.stringify(data.seller));
    axios.defaults.headers.common['Authorization'] = 'Bearer '+data.token;
    setSeller(data.seller); return data;
  };
  const logout = () => {
    localStorage.removeItem('jk_token'); localStorage.removeItem('jk_seller');
    delete axios.defaults.headers.common['Authorization']; setSeller(null);
  };
  return <Ctx.Provider value={{ seller, loading, login, logout }}>{children}</Ctx.Provider>;
};

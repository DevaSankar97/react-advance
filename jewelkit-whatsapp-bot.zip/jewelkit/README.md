# 💍 JewelKit — WhatsApp Bot for Jewellery Resellers

> The simplest way for uneducated jewellery sellers to track credit, stock & payments via WhatsApp in Tamil/English/Hindi.

---

## 🎯 What This Solves

Covering jewellery sellers who:
- ❌ Can't read English
- ❌ Never used an app
- ✅ Use WhatsApp every day
- ✅ Give credit to neighbours
- ✅ Forget who owes how much

---

## 📱 How It Works — WhatsApp First

Seller types in WhatsApp:
```
"Kavitha 500 vaangi"     → ✅ Sale entry + balance shown
"Kavitha 200 kuduthal"   → ✅ Payment recorded
"Kavitha balance"        → ✅ Shows ₹300 pending
"list"                   → ✅ All pending customers
"today"                  → ✅ Today's summary
"report"                 → ✅ Monthly report
"help"                   → ✅ All commands
```

---

## 🛠️ Tech Stack

| Layer | Tech |
|-------|------|
| WhatsApp | Twilio + Meta WhatsApp Cloud API (both) |
| Backend | Node.js + Express |
| Database | MongoDB |
| Dashboard | React + Bootstrap 5 |
| NLP | Keyword matching (Tamil/English/Hindi) |
| Cron | node-cron (reminders) |

---

## 🚀 Setup

### 1. Backend
```bash
cd jewelkit/backend
npm install
cp .env.example .env
# Fill in MONGODB_URI, JWT_SECRET, Twilio/Meta keys
npm run dev
# Runs on port 4000
```

### 2. Frontend Dashboard
```bash
cd jewelkit/frontend
npm install
npm start
# Opens on port 3000
```

### 3. Configure Twilio Webhook
```
Twilio Console → WhatsApp Sandbox → Webhook URL:
POST https://your-domain.com/webhook/twilio
```

### 4. Configure Meta Webhook
```
Meta Developer Console → WhatsApp → Webhooks:
URL: https://your-domain.com/webhook/meta
Verify Token: (your META_VERIFY_TOKEN from .env)
Subscribe to: messages
```

---

## 💬 WhatsApp Commands (Tamil)

| Command | Example | Action |
|---------|---------|--------|
| Sale | Kavitha 500 vaangi | Records ₹500 sale |
| Payment | Kavitha 200 kuduthal | Records ₹200 payment |
| Balance | Kavitha balance | Shows balance |
| List | list | All pending customers |
| Today | today | Today's summary |
| Report | report | Monthly report |
| Stock | stock | Stock summary |
| Help | help | All commands |

## 💬 WhatsApp Commands (English)

| Command | Example | Action |
|---------|---------|--------|
| Sale | Kavitha bought 500 | Records ₹500 sale |
| Payment | Kavitha paid 200 | Records ₹200 payment |

## 💬 WhatsApp Commands (Hindi)

| Command | Example | Action |
|---------|---------|--------|
| Sale | Kavitha ne 500 ka liya | Records ₹500 sale |
| Payment | Kavitha ne 200 diya | Records ₹200 payment |

---

## 🖥️ Dashboard Features

| Page | Features |
|------|---------|
| Dashboard | Stats, 6-month chart, WhatsApp commands |
| Customers | Add/edit, sale entry, payment, history, delete |
| Stock | Jewellery inventory, add/use stock, low stock alerts |
| Reports | Monthly P&L, transaction list, top pending |
| Settings | Language (Tamil/English/Hindi), commands guide |

---

## ⚙️ Cron Jobs (Automatic)

| Job | When | Action |
|-----|------|--------|
| Payment Reminders | 1st of every month 10 AM | Sends reminder to all pending customers |
| Low Stock Alerts | Every Monday 9 AM | Alerts seller about low stock |
| Subscription Expiry | Daily 8 AM | Warns seller before expiry |

---

## 💰 Business Model

| Plan | Price | Features |
|------|-------|---------|
| Free Trial | ₹0 | 14 days — WhatsApp bot |
| Paid | ₹99/month | Everything + reminders + alerts |

**Revenue at 500 sellers = ₹49,500/month**

---

## 📁 Project Structure

```
jewelkit/
├── backend/
│   ├── models/         Seller, Customer, Transaction, Stock
│   ├── routes/         twilioWebhook, metaWebhook, dashboard
│   ├── services/       nlpParser, botEngine, whatsappService, responses
│   └── server.js
└── frontend/
    ├── src/
    │   ├── components/ auth, dashboard, customers, stock, reports, settings
    │   ├── context/    AuthContext
    │   └── App.js
    └── package.json
```

---

## 🌟 Scale Plan

```
Phase 1: Chennai jewellery sellers (Tamil)
Phase 2: All Tamil Nadu + Andhra + Kerala + Karnataka
Phase 3: Hindi market (UP, Bihar, Rajasthan)
Phase 4: Add vegetable vendors, milk vendors, any credit business
Phase 5: 50,000 users × ₹99 = ₹49.5L/month
```

---

Made with ❤️ in Chennai, India 🇮🇳

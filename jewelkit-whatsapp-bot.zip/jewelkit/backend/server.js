const express    = require('express');
const mongoose   = require('mongoose');
const cors       = require('cors');
const dotenv     = require('dotenv');
const helmet     = require('helmet');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');
const cron       = require('node-cron');

dotenv.config();

const app = express();

// ── Security ──
app.use(helmet({ contentSecurityPolicy: false }));
if (process.env.NODE_ENV !== 'production') app.use(morgan('dev'));

// Rate limiting
app.use('/api/', rateLimit({ windowMs: 15*60*1000, max: 200 }));
// Webhook rate limit (more generous)
app.use('/webhook/', rateLimit({ windowMs: 1*60*1000, max: 100 }));

// CORS
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }));

// Body parsing — webhooks need raw
app.use('/webhook', express.urlencoded({ extended: false }));
app.use(express.json({ limit: '10mb' }));

// ── Routes ──
app.use('/webhook',  require('./routes/twilioWebhook'));
app.use('/webhook',  require('./routes/metaWebhook'));
app.use('/api/dash', require('./routes/dashboard'));

// Health check
app.get('/', (req, res) => res.json({
  status: 'JewelKit Bot Running 💍',
  version: '1.0.0',
  time: new Date().toISOString()
}));

// 404
app.use('*', (req, res) => res.status(404).json({ success: false, message: 'Route not found' }));

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: process.env.NODE_ENV === 'production' ? 'Server Error' : err.message });
});

// ── Cron Jobs ──
const { sendMonthlyReminders } = require('./services/botEngine');
const { sendWhatsApp }         = require('./services/whatsappService');
const Stock                    = require('./models/Stock');
const Seller                   = require('./models/Seller');

// Monthly payment reminders — 1st of every month at 10 AM
cron.schedule('0 10 1 * *', async () => {
  console.log('[CRON] Sending monthly payment reminders...');
  try {
    const count = await sendMonthlyReminders(sendWhatsApp);
    console.log(`[CRON] Sent ${count} reminders`);
  } catch (err) {
    console.error('[CRON] Reminder error:', err.message);
  }
});

// Low stock alerts — Every Monday 9 AM
cron.schedule('0 9 * * 1', async () => {
  console.log('[CRON] Checking low stock...');
  try {
    const R       = require('./services/responses');
    const sellers = await Seller.find({ isActive: true });
    for (const seller of sellers) {
      const stocks  = await Stock.find({ seller: seller._id, isActive: true });
      const lowItems= stocks.filter(s => s.quantity <= s.minQuantity);
      if (lowItems.length > 0) {
        const lang = seller.language || 'ta';
        const msg  = R.stockLow[lang](lowItems);
        await sendWhatsApp(seller.phone, msg).catch(console.error);
      }
    }
  } catch (err) {
    console.error('[CRON] Low stock check error:', err.message);
  }
});

// Subscription expiry reminders — Daily 8 AM
cron.schedule('0 8 * * *', async () => {
  try {
    const R       = require('./services/responses');
    const tomorrow= new Date(); tomorrow.setDate(tomorrow.getDate()+1);
    const expiring= await Seller.find({
      isActive: true,
      planExpiry: { $lte: tomorrow, $gte: new Date() }
    });
    for (const seller of expiring) {
      const lang = seller.language || 'ta';
      await sendWhatsApp(seller.phone, R.expired[lang]()).catch(console.error);
    }
  } catch (err) {
    console.error('[CRON] Expiry reminder error:', err.message);
  }
});

// ── Connect DB & Start ──
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('✅ MongoDB Connected');
    const PORT = process.env.PORT || 4000;
    app.listen(PORT, () => {
      console.log(`🚀 JewelKit Bot running on port ${PORT}`);
      console.log(`📱 Twilio webhook: POST /webhook/twilio`);
      console.log(`📱 Meta webhook:   GET/POST /webhook/meta`);
      console.log(`🖥️  Dashboard API: /api/dash`);
    });
  })
  .catch(err => { console.error('❌ MongoDB error:', err); process.exit(1); });

module.exports = app;

const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  seller:   { type: mongoose.Schema.Types.ObjectId, ref: 'Seller', required: true },
  customer: { type: mongoose.Schema.Types.ObjectId, ref: 'JewelCustomer', required: true },

  type: {
    type: String,
    enum: ['sale','payment','return','adjustment'],
    required: true
  },

  // Sale fields
  items:      String,    // "3 necklace, 2 bangles" — free text
  saleAmount: { type: Number, default: 0 },

  // Payment fields
  paidAmount: { type: Number, default: 0 },

  // Running balance after this transaction
  balanceBefore: { type: Number, default: 0 },
  balanceAfter:  { type: Number, default: 0 },

  notes:    String,
  source:   { type: String, enum: ['whatsapp','dashboard'], default: 'whatsapp' },
  rawText:  String,   // original WhatsApp message for audit
  date:     { type: Date, default: Date.now }
});

module.exports = mongoose.model('Transaction', transactionSchema);

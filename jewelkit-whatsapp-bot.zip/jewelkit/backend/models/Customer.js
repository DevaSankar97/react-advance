const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  seller:   { type: mongoose.Schema.Types.ObjectId, ref: 'Seller', required: true },
  name:     { type: String, required: true, trim: true },
  phone:    String,
  area:     String,
  notes:    String,
  totalDue: { type: Number, default: 0 },  // running balance
  isActive: { type: Boolean, default: true },
  createdAt:{ type: Date, default: Date.now }
});

// Normalize name for fuzzy matching (lowercase, trim spaces)
customerSchema.virtual('normalizedName').get(function() {
  return this.name.toLowerCase().trim();
});

module.exports = mongoose.model('JewelCustomer', customerSchema);

const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const sellerSchema = new mongoose.Schema({
  // Identity — phone number IS the login (no password for WhatsApp users)
  phone:        { type: String, required: true, unique: true }, // +91XXXXXXXXXX
  name:         { type: String, required: true, trim: true },
  businessName: { type: String, trim: true },
  area:         { type: String, trim: true },  // locality/colony
  city:         { type: String, default: 'Chennai' },
  language:     { type: String, enum: ['ta','en','hi'], default: 'ta' }, // Tamil default

  // WhatsApp source
  waSource:     { type: String, enum: ['twilio','meta'], default: 'twilio' },
  waId:         String,  // WhatsApp contact ID

  // Subscription
  plan:         { type: String, enum: ['free','paid'], default: 'free' },
  planExpiry:   { type: Date, default: () => new Date(Date.now() + 14*24*60*60*1000) }, // 14-day trial
  isActive:     { type: Boolean, default: true },

  // Dashboard access (for educated family member / you)
  dashboardPin: { type: String, select: false }, // 4-digit PIN
  dashboardEnabled: { type: Boolean, default: false },

  // Bot state — track conversation context
  botState: {
    step:       { type: String, default: 'idle' },
    context:    { type: mongoose.Schema.Types.Mixed, default: {} },
    lastMessage:Date,
  },

  // Settings
  settings: {
    reminderEnabled:  { type: Boolean, default: true },
    reminderDay:      { type: Number, default: 1 },    // 1st of month
    reminderHour:     { type: Number, default: 10 },   // 10 AM
    language:         { type: String, default: 'ta' },
  },

  createdAt: { type: Date, default: Date.now }
});

// Hash dashboard PIN
sellerSchema.pre('save', async function(next) {
  if (!this.isModified('dashboardPin') || !this.dashboardPin) return next();
  this.dashboardPin = await bcrypt.hash(this.dashboardPin, 10);
  next();
});

sellerSchema.methods.comparePin = async function(pin) {
  return bcrypt.compare(pin, this.dashboardPin);
};

module.exports = mongoose.model('Seller', sellerSchema);

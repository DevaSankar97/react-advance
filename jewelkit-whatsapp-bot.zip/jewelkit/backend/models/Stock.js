const mongoose = require('mongoose');

const stockSchema = new mongoose.Schema({
  seller:      { type: mongoose.Schema.Types.ObjectId, ref: 'Seller', required: true },
  name:        { type: String, required: true, trim: true }, // "Gold necklace", "Stone bangles"
  category: {
    type: String,
    enum: ['necklace','bangles','earrings','rings','anklets','chains','sets','other'],
    default: 'other'
  },
  quantity:    { type: Number, default: 0 },
  costPrice:   { type: Number, default: 0 },   // what seller paid
  sellPrice:   { type: Number, default: 0 },   // what she sells for
  minQuantity: { type: Number, default: 2 },   // alert below this
  notes:       String,
  isActive:    { type: Boolean, default: true },
  createdAt:   { type: Date, default: Date.now }
});

module.exports = mongoose.model('Stock', stockSchema);

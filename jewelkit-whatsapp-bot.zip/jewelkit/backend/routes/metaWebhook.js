const express = require('express');
const { processMessage } = require('../services/botEngine');
const { sendWhatsApp }   = require('../services/whatsappService');
const router = express.Router();

// @route GET /webhook/meta
// Meta verification handshake
router.get('/meta', (req, res) => {
  const mode      = req.query['hub.mode'];
  const token     = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === process.env.META_VERIFY_TOKEN) {
    console.log('[Meta] Webhook verified!');
    return res.status(200).send(challenge);
  }
  res.sendStatus(403);
});

// @route POST /webhook/meta
// Meta sends message events
router.post('/meta', async (req, res) => {
  try {
    // Acknowledge immediately (Meta requires < 200ms response)
    res.sendStatus(200);

    const body = req.body;
    if (body.object !== 'whatsapp_business_account') return;

    const entry   = body.entry?.[0];
    const changes = entry?.changes?.[0];
    const value   = changes?.value;

    // Process each message
    const messages = value?.messages || [];
    for (const msg of messages) {
      const from = msg.from;  // phone number without +
      let   text = '';

      if (msg.type === 'text') {
        text = msg.text?.body || '';
      } else if (msg.type === 'audio') {
        // Voice note — basic handling
        text = '[voice note]';
      } else if (msg.type === 'image') {
        text = '[image]';
      }

      if (!text || !from) continue;

      console.log(`[Meta] From: +${from} | Message: ${text}`);

      try {
        const reply = await processMessage(`+${from}`, text, 'meta');
        await sendWhatsApp(`+${from}`, reply, 'meta');
      } catch (err) {
        console.error(`Error processing message from ${from}:`, err.message);
      }
    }
  } catch (err) {
    console.error('Meta webhook error:', err);
    res.sendStatus(500);
  }
});

module.exports = router;

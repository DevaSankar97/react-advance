const express = require('express');
const { processMessage } = require('../services/botEngine');
const { sendWhatsApp }   = require('../services/whatsappService');
const router = express.Router();

// @route POST /webhook/twilio
// Twilio sends POST with Form data
router.post('/twilio', async (req, res) => {
  try {
    const from    = req.body.From || '';     // whatsapp:+91XXXXXXXXXX
    const body    = req.body.Body || '';     // message text
    const mediaUrl= req.body.MediaUrl0 || null; // voice note / image

    if (!from || !body.trim()) {
      return res.set('Content-Type', 'text/xml').send('<Response></Response>');
    }

    console.log(`[Twilio] From: ${from} | Message: ${body}`);

    // Process message through bot engine
    const reply = await processMessage(from, body.trim(), 'twilio');

    // Send reply back via Twilio
    await sendWhatsApp(from, reply, 'twilio');

    // Twilio expects XML response (empty = handled)
    res.set('Content-Type', 'text/xml').send('<Response></Response>');
  } catch (err) {
    console.error('Twilio webhook error:', err);
    res.set('Content-Type', 'text/xml').send('<Response></Response>');
  }
});

module.exports = router;

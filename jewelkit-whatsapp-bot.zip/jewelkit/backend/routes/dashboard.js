const express     = require('express');
const Seller      = require('../models/Seller');
const Customer    = require('../models/Customer');
const Transaction = require('../models/Transaction');
const Stock       = require('../models/Stock');
const jwt         = require('jsonwebtoken');
const router      = express.Router();

// ── Simple PIN auth for dashboard ──
const dashAuth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ success: false, message: 'No token' });
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.seller = await Seller.findById(decoded.id);
    if (!req.seller) return res.status(401).json({ success: false, message: 'Seller not found' });
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid token' });
  }
};

// @route POST /api/dash/login
// Login via phone + PIN (for dashboard access)
router.post('/login', async (req, res) => {
  try {
    const { phone, pin } = req.body;
    const seller = await Seller.findOne({ phone }).select('+dashboardPin');
    if (!seller) return res.status(404).json({ success: false, message: 'Seller not found' });

    // If no PIN set, create one
    if (!seller.dashboardPin) {
      seller.dashboardPin = pin || '1234';
      seller.dashboardEnabled = true;
      await seller.save();
    } else {
      const ok = await seller.comparePin(pin);
      if (!ok) return res.status(401).json({ success: false, message: 'Wrong PIN' });
    }

    const token = jwt.sign({ id: seller._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({
      success: true,
      token,
      seller: { id: seller._id, name: seller.name, phone: seller.phone, language: seller.language }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// All below require auth
router.use(dashAuth);

// @route GET /api/dash/summary
router.get('/summary', async (req, res) => {
  try {
    const now   = new Date();
    const m     = now.getMonth()+1, y = now.getFullYear();
    const start = new Date(y,m-1,1), end = new Date(y,m,1);
    const today = new Date(); today.setHours(0,0,0,0);
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate()+1);

    const customers   = await Customer.find({ seller: req.seller._id, isActive: true });
    const pendingCusts= customers.filter(c => c.totalDue > 0);
    const totalPending= pendingCusts.reduce((s,c) => s+c.totalDue, 0);

    const monthTxns   = await Transaction.find({ seller: req.seller._id, date: { $gte:start, $lt:end } });
    const todayTxns   = await Transaction.find({ seller: req.seller._id, date: { $gte:today, $lt:tomorrow } });

    const monthSales  = monthTxns.filter(t=>t.type==='sale').reduce((s,t)=>s+t.saleAmount,0);
    const monthPay    = monthTxns.filter(t=>t.type==='payment').reduce((s,t)=>s+t.paidAmount,0);
    const todaySales  = todayTxns.filter(t=>t.type==='sale').reduce((s,t)=>s+t.saleAmount,0);
    const todayPay    = todayTxns.filter(t=>t.type==='payment').reduce((s,t)=>s+t.paidAmount,0);

    const stocks      = await Stock.find({ seller: req.seller._id, isActive: true });
    const lowStock    = stocks.filter(s => s.quantity <= s.minQuantity);

    // 6-month trend
    const trend = [];
    for (let i=5; i>=0; i--) {
      const d = new Date(y,m-1-i,1);
      const tm=d.getMonth()+1, ty=d.getFullYear();
      const txns = await Transaction.find({ seller:req.seller._id, date:{ $gte:new Date(ty,tm-1,1), $lt:new Date(ty,tm,1) }});
      trend.push({
        month: d.toLocaleDateString('en-IN',{month:'short'}),
        sales:    txns.filter(t=>t.type==='sale').reduce((s,t)=>s+t.saleAmount,0),
        collected:txns.filter(t=>t.type==='payment').reduce((s,t)=>s+t.paidAmount,0),
      });
    }

    res.json({ success: true, summary: {
      customers: { total: customers.length, pending: pendingCusts.length, totalDue: totalPending },
      today:     { sales: todaySales, collected: todayPay },
      month:     { sales: monthSales, collected: monthPay },
      stock:     { total: stocks.length, lowStock: lowStock.length },
      trend
    }});
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route GET /api/dash/customers
router.get('/customers', async (req, res) => {
  try {
    const { search } = req.query;
    let query = { seller: req.seller._id, isActive: true };
    if (search) query.name = { $regex: search, $options: 'i' };
    const customers = await Customer.find(query).sort({ totalDue: -1 });
    res.json({ success: true, customers });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route POST /api/dash/customers
router.post('/customers', async (req, res) => {
  try {
    const c = await Customer.create({ ...req.body, seller: req.seller._id });
    res.status(201).json({ success: true, message: 'Customer added!', customer: c });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route PUT /api/dash/customers/:id
router.put('/customers/:id', async (req, res) => {
  try {
    const c = await Customer.findOneAndUpdate(
      { _id: req.params.id, seller: req.seller._id }, req.body, { new: true }
    );
    res.json({ success: true, message: 'Updated!', customer: c });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route GET /api/dash/transactions
router.get('/transactions', async (req, res) => {
  try {
    const { customerId, month, year, type, limit=50 } = req.query;
    let query = { seller: req.seller._id };
    if (customerId) query.customer = customerId;
    if (type)       query.type = type;
    if (month && year) {
      const m=parseInt(month),y=parseInt(year);
      query.date = { $gte:new Date(y,m-1,1), $lt:new Date(y,m,1) };
    }
    const txns = await Transaction.find(query)
      .populate('customer','name phone')
      .sort({ date:-1 }).limit(parseInt(limit));
    res.json({ success: true, transactions: txns });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route POST /api/dash/transactions
// Add transaction from dashboard
router.post('/transactions', async (req, res) => {
  try {
    const { customerId, type, amount, items, notes } = req.body;
    const customer = await Customer.findOne({ _id: customerId, seller: req.seller._id });
    if (!customer) return res.status(404).json({ success: false, message: 'Customer not found' });

    const balanceBefore = customer.totalDue;
    let balanceAfter    = balanceBefore;

    if (type === 'sale')    balanceAfter = balanceBefore + parseFloat(amount);
    if (type === 'payment') balanceAfter = Math.max(0, balanceBefore - parseFloat(amount));

    customer.totalDue = balanceAfter;
    await customer.save();

    const txn = await Transaction.create({
      seller: req.seller._id, customer: customerId,
      type, saleAmount: type==='sale'?amount:0,
      paidAmount: type==='payment'?amount:0,
      items, notes, balanceBefore, balanceAfter, source:'dashboard'
    });

    res.status(201).json({ success: true, message: 'Transaction added!', transaction: txn });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route DELETE /api/dash/transactions/:id
router.delete('/transactions/:id', async (req, res) => {
  try {
    const txn = await Transaction.findOne({ _id:req.params.id, seller:req.seller._id });
    if (!txn) return res.status(404).json({ success: false, message: 'Not found' });

    // Reverse the balance effect
    const customer = await Customer.findById(txn.customer);
    if (customer) {
      if (txn.type === 'sale')    customer.totalDue -= txn.saleAmount;
      if (txn.type === 'payment') customer.totalDue += txn.paidAmount;
      customer.totalDue = Math.max(0, customer.totalDue);
      await customer.save();
    }

    await Transaction.findByIdAndDelete(txn._id);
    res.json({ success: true, message: 'Transaction deleted & balance reversed' });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route GET /api/dash/stock
router.get('/stock', async (req, res) => {
  try {
    const stocks = await Stock.find({ seller: req.seller._id, isActive: true }).sort({ category:1, name:1 });
    const low    = stocks.filter(s => s.quantity <= s.minQuantity);
    res.json({ success: true, stocks, lowStockCount: low.length });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route POST /api/dash/stock
router.post('/stock', async (req, res) => {
  try {
    const s = await Stock.create({ ...req.body, seller: req.seller._id });
    res.status(201).json({ success: true, message: 'Stock item added!', stock: s });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route PUT /api/dash/stock/:id
router.put('/stock/:id', async (req, res) => {
  try {
    const s = await Stock.findOneAndUpdate(
      { _id: req.params.id, seller: req.seller._id }, req.body, { new: true }
    );
    res.json({ success: true, message: 'Updated!', stock: s });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route DELETE /api/dash/stock/:id
router.delete('/stock/:id', async (req, res) => {
  try {
    await Stock.findOneAndUpdate({ _id:req.params.id, seller:req.seller._id }, { isActive:false });
    res.json({ success: true, message: 'Item removed' });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route GET /api/dash/report
router.get('/report', async (req, res) => {
  try {
    const { month, year } = req.query;
    const m = parseInt(month)||new Date().getMonth()+1;
    const y = parseInt(year) ||new Date().getFullYear();

    const txns = await Transaction.find({
      seller: req.seller._id,
      date: { $gte:new Date(y,m-1,1), $lt:new Date(y,m,1) }
    }).populate('customer','name');

    const customers = await Customer.find({ seller: req.seller._id, isActive: true });
    const totalPending = customers.reduce((s,c)=>s+c.totalDue,0);

    res.json({ success: true,
      report: {
        month: m, year: y,
        sales:     txns.filter(t=>t.type==='sale').reduce((s,t)=>s+t.saleAmount,0),
        collected: txns.filter(t=>t.type==='payment').reduce((s,t)=>s+t.paidAmount,0),
        totalPending,
        transactions: txns,
        topCustomers: customers.sort((a,b)=>b.totalDue-a.totalDue).slice(0,5)
      }
    });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// @route PUT /api/dash/settings
router.put('/settings', async (req, res) => {
  try {
    const seller = await Seller.findByIdAndUpdate(req.seller._id, { settings: req.body }, { new: true });
    res.json({ success: true, message: 'Settings updated!', seller });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

module.exports = router;

// ══════════════════════════════════════════════
//  JewelKit WhatsApp Service
//  Supports: Twilio + Meta WhatsApp Cloud API
// ══════════════════════════════════════════════
const axios = require('axios');

// ── Send via Twilio ──
async function sendViaTwilio(to, message) {
  const client = require('twilio')(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );

  const toNum = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
  return client.messages.create({
    from: process.env.TWILIO_WHATSAPP_FROM,
    to:   toNum,
    body: message
  });
}

// ── Send via Meta WhatsApp Cloud API ──
async function sendViaMeta(to, message) {
  const phone = to.replace(/\D/g, '').replace(/^91/, '');
  const fullPhone = `91${phone}`;

  return axios.post(
    `https://graph.facebook.com/v18.0/${process.env.META_PHONE_NUMBER_ID}/messages`,
    {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: fullPhone,
      type: 'text',
      text: { preview_url: false, body: message }
    },
    {
      headers: {
        Authorization: `Bearer ${process.env.META_WHATSAPP_TOKEN}`,
        'Content-Type': 'application/json'
      }
    }
  );
}

// ── Smart send — try Meta first, fallback to Twilio ──
async function sendWhatsApp(to, message, preferredSource = 'meta') {
  if (preferredSource === 'twilio') {
    try { return await sendViaTwilio(to, message); }
    catch (err) {
      console.error('Twilio failed, trying Meta:', err.message);
      return sendViaMeta(to, message);
    }
  } else {
    try { return await sendViaMeta(to, message); }
    catch (err) {
      console.error('Meta failed, trying Twilio:', err.message);
      return sendViaTwilio(to, message);
    }
  }
}

module.exports = { sendWhatsApp, sendViaTwilio, sendViaMeta };

// ══════════════════════════════════════════════════════
//  JewelKit NLP Parser
//  Understands Tamil / English / Hindi messages
//  No AI needed — keyword matching is enough
// ══════════════════════════════════════════════════════

// ── Intent keywords ──
const INTENTS = {

  // SALE — customer bought something
  sale: {
    ta: ['vaangi','vaaangi','vaanginal','vittom','vittu','vittaen','koduthaen','koduthal','sale','vilai'],
    en: ['bought','sold','purchase','sale','taken','buyed','take'],
    hi: ['liya','kharida','becha','diya','le gaya','le gayi','leli']
  },

  // PAYMENT — customer paid money
  payment: {
    ta: ['kuduthal','kuduthanga','kuduthaanga','pay pannanga','pay pannal','payment','paiisa','kashu','kasu'],
    en: ['paid','pay','payment','gave','given','received','collected'],
    hi: ['diya','diye','payment kiya','paise diye','dedi','de diya']
  },

  // BALANCE — check how much is due
  balance: {
    ta: ['balance','bakki','kadan','kadhan','evlo','evvalo','iruku','amount','paar','paaru'],
    en: ['balance','due','pending','owe','how much','check'],
    hi: ['bakaya','kitna','kitne','balance','bacha','baki']
  },

  // LIST — show all pending customers
  list: {
    ta: ['list','pattiyalm','pattiyal','யாரு','ellam','yaar ellam','kodukala','kodukalaanga'],
    en: ['list','all','pending','who','show all','unpaid'],
    hi: ['list','sabhi','kaun','dikhao','baki hai']
  },

  // STOCK — inventory questions
  stock: {
    ta: ['stock','porul','iruku','evlo iruku','sarakku','item'],
    en: ['stock','item','inventory','how many','available'],
    hi: ['stock','maal','kitna hai','saman']
  },

  // ADD STOCK — restocking
  addstock: {
    ta: ['stock pottu','stock add','vaangi pottu','puthu stock','new stock','vandhuchi'],
    en: ['add stock','new stock','restock','bought stock','stock add'],
    hi: ['stock aaya','naya stock','stock aagaya','maal aaya']
  },

  // TODAY — today's summary
  today: {
    ta: ['iniku','indru','today','innaiku','innikku'],
    en: ['today','todays','today summary'],
    hi: ['aaj','aaj ka','today']
  },

  // MONTH REPORT
  report: {
    ta: ['report','maatha','month','maadam','summary','total','eppadi iruku'],
    en: ['report','month','monthly','summary','total','how much'],
    hi: ['report','mahina','mahine','summary','total']
  },

  // HELP
  help: {
    ta: ['help','உதவி','enna','yenna','command','vazhikaati'],
    en: ['help','what can','commands','how to','guide'],
    hi: ['help','madad','kya kar','kaise']
  },

  // REMIND — manually trigger reminder
  remind: {
    ta: ['remind','yaadhapaduthu','sollu','message podu'],
    en: ['remind','reminder','send reminder'],
    hi: ['remind','yaad dilao','message bhejo']
  },
};

// ── Number extraction ──
// Handles: 500, ₹500, Rs.500, five hundred, ஐந்நூறு
const TAMIL_NUMBERS = {
  'ஒன்று':1,'ரெண்டு':2,'இரண்டு':2,'மூன்று':3,'நான்கு':4,'ஐந்து':5,
  'ஆறு':6,'ஏழு':7,'எட்டு':8,'ஒன்பது':9,'பத்து':10,
  'இருபது':20,'முப்பது':30,'நாற்பது':40,'ஐம்பது':50,
  'அறுபது':60,'எழுபது':70,'எண்பது':80,'தொண்ணூறு':90,
  'நூறு':100,'இருநூறு':200,'முந்நூறு':300,'நாநூறு':400,'ஐந்நூறு':500,
  'ஆறுநூறு':600,'எழுநூறு':700,'எட்டுநூறு':800,'தொள்ளாயிரம்':900,
  'ஆயிரம்':1000,'இரண்டாயிரம்':2000,'ஐந்தாயிரம்':5000,'பத்தாயிரம்':10000
};

function extractNumber(text) {
  // Direct number
  const direct = text.match(/₹?\s*(\d+(?:\.\d+)?)/);
  if (direct) return parseFloat(direct[1]);

  // Tamil number words
  const lower = text.toLowerCase();
  for (const [word, val] of Object.entries(TAMIL_NUMBERS)) {
    if (lower.includes(word)) return val;
  }

  // English number words
  const engNums = {
    'one':1,'two':2,'three':3,'four':4,'five':5,
    'six':6,'seven':7,'eight':8,'nine':9,'ten':10,
    'hundred':100,'thousand':1000,'lakh':100000
  };
  for (const [word, val] of Object.entries(engNums)) {
    if (lower.includes(word)) return val;
  }

  return null;
}

// ── Name extraction ──
// Remove known keywords to find the customer name
function extractName(text, knownCustomers = []) {
  const clean = text
    .replace(/₹?\d+(\.\d+)?/g, '')
    .replace(/vaangi|vittom|kuduthal|kuduthanga|pay|paid|balance|bakki|sold|bought|liya|diya/gi, '')
    .replace(/[^\u0B80-\u0BFFa-zA-Z\s]/g, '')
    .trim();

  // First check if any known customer name is in the message
  for (const customer of knownCustomers) {
    const nameLower = customer.name.toLowerCase();
    if (text.toLowerCase().includes(nameLower)) {
      return customer.name;
    }
  }

  // Extract capitalized word or first meaningful word
  const words = clean.split(/\s+/).filter(w => w.length > 2);
  return words.length > 0 ? words[0] : null;
}

// ── Detect intent from message ──
function detectIntent(text) {
  const lower = text.toLowerCase();

  for (const [intent, langs] of Object.entries(INTENTS)) {
    const allKeywords = [...(langs.ta||[]), ...(langs.en||[]), ...(langs.hi||[])];
    if (allKeywords.some(kw => lower.includes(kw))) {
      return intent;
    }
  }

  // Default: if has number → likely a sale or payment
  if (/\d+/.test(text)) return 'ambiguous';

  return 'unknown';
}

// ── Detect language ──
function detectLanguage(text) {
  if (/[\u0B80-\u0BFF]/.test(text)) return 'ta'; // Tamil Unicode
  if (/[\u0900-\u097F]/.test(text)) return 'hi'; // Hindi Unicode
  return 'en';
}

// ── Main parse function ──
function parseMessage(text, knownCustomers = []) {
  const intent   = detectIntent(text);
  const language = detectLanguage(text);
  const amount   = extractNumber(text);
  const name     = extractName(text, knownCustomers);

  return { intent, language, amount, name, raw: text };
}

module.exports = { parseMessage, detectIntent, extractNumber, extractName, detectLanguage };

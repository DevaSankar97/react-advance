// ══════════════════════════════════════════════════
//  JewelKit Bot Response Templates
//  Tamil / English / Hindi
// ══════════════════════════════════════════════════

const R = {

  // ── Welcome / Registration ──
  welcome: {
    ta: (name) => `வணக்கம் ${name}! 🙏\nJewelKit-ல உங்களை வரவேற்கிறோம்! 💍\n\nஇனிமேல் உங்கள் கடன் கணக்கு எல்லாம் இங்கே வைக்கலாம்.\n\nகீழே உள்ளவற்றை type செய்யுங்கள்:\n💰 Sale: "Kavitha 500 vaangi"\n💵 Payment: "Kavitha 200 kuduthal"\n📊 Balance: "Kavitha balance"\n📋 List: "list"\n❓ Help: "help"`,
    en: (name) => `Welcome ${name}! 🙏\nWelcome to JewelKit! 💍\n\nYou can track all your credit accounts here.\n\nType:\n💰 Sale: "Kavitha bought 500"\n💵 Payment: "Kavitha paid 200"\n📊 Balance: "Kavitha balance"\n📋 List: "list"\n❓ Help: "help"`,
    hi: (name) => `Swagat hai ${name}! 🙏\nJewelKit mein aapka swagat! 💍\n\nYahan apne sabhi credit accounts track karein.\n\nType karein:\n💰 Sale: "Kavitha ne 500 ka liya"\n💵 Payment: "Kavitha ne 200 diya"\n📊 Balance: "Kavitha balance"\n📋 List: "list"\n❓ Help: "help"`,
  },

  // ── Sale recorded ──
  saleAdded: {
    ta: (name, amount, balance) =>
      `✅ Sale entry aagiyachu!\n\n👤 Customer: ${name}\n💰 Sale: ₹${amount}\n📌 Ippo balance: ₹${balance}\n\n💡 Tip: Balance check-panna "${name} balance" nu type pannunga`,
    en: (name, amount, balance) =>
      `✅ Sale recorded!\n\n👤 Customer: ${name}\n💰 Sale: ₹${amount}\n📌 Current balance: ₹${balance}\n\n💡 Tip: To check balance type "${name} balance"`,
    hi: (name, amount, balance) =>
      `✅ Sale record ho gayi!\n\n👤 Customer: ${name}\n💰 Sale: ₹${amount}\n📌 Abhi balance: ₹${balance}\n\n💡 Tip: Balance check karne ke liye "${name} balance" type karein`,
  },

  // ── Payment recorded ──
  paymentAdded: {
    ta: (name, amount, balance) =>
      `✅ Payment entry aagiyachu!\n\n👤 Customer: ${name}\n💵 Paid: ₹${amount}\n${balance > 0 ? `📌 Innum bakki: ₹${balance}` : '🎉 Full amount kuduthaanga! Balance illa!'}`,
    en: (name, amount, balance) =>
      `✅ Payment recorded!\n\n👤 Customer: ${name}\n💵 Paid: ₹${amount}\n${balance > 0 ? `📌 Still due: ₹${balance}` : '🎉 Fully paid! No balance!'}`,
    hi: (name, amount, balance) =>
      `✅ Payment record ho gayi!\n\n👤 Customer: ${name}\n💵 Paid: ₹${amount}\n${balance > 0 ? `📌 Abhi bhi baki: ₹${balance}` : '🎉 Poora paid! Kuch baki nahi!'}`,
  },

  // ── Balance check ──
  balance: {
    ta: (name, balance, lastTxn) =>
      `💍 ${name} balance:\n\n${balance > 0 ? `📌 Kodukka vendum: ₹${balance}` : '✅ Balance illa! Full clear!'}\n${lastTxn ? `📅 Kadaisi transaction: ${new Date(lastTxn).toLocaleDateString('ta-IN')}` : ''}`,
    en: (name, balance, lastTxn) =>
      `💍 ${name} balance:\n\n${balance > 0 ? `📌 Amount due: ₹${balance}` : '✅ No balance! Fully paid!'}\n${lastTxn ? `📅 Last transaction: ${new Date(lastTxn).toLocaleDateString('en-IN')}` : ''}`,
    hi: (name, balance, lastTxn) =>
      `💍 ${name} balance:\n\n${balance > 0 ? `📌 Dena hai: ₹${balance}` : '✅ Balance nahi! Poora clear!'}\n${lastTxn ? `📅 Last transaction: ${new Date(lastTxn).toLocaleDateString('hi-IN')}` : ''}`,
  },

  // ── Customer not found ──
  customerNotFound: {
    ta: (name) => `⚠️ "${name}" customer kaanom.\n\nPuthu customer-aa?\n"${name}" nu reply pannunga — save pannrom!\n\nIllana correct name sollunga.`,
    en: (name) => `⚠️ Customer "${name}" not found.\n\nNew customer?\nReply "${name}" — we'll save them!\n\nOr type the correct name.`,
    hi: (name) => `⚠️ Customer "${name}" nahi mila.\n\nNaya customer hai?\n"${name}" reply karein — save kar lete hain!\n\nYa sahi naam type karein.`,
  },

  // ── Pending list ──
  pendingList: {
    ta: (customers) => {
      if (!customers.length) return '🎉 Ellaarum pay pannitaanga! Pending balance illa!';
      const lines = customers.map((c,i) => `${i+1}. ${c.name} — ₹${c.totalDue}`).join('\n');
      const total = customers.reduce((s,c)=>s+c.totalDue,0);
      return `📋 Pending Balance List:\n━━━━━━━━━━━━━━\n${lines}\n━━━━━━━━━━━━━━\n💰 Motta total: ₹${total}`;
    },
    en: (customers) => {
      if (!customers.length) return '🎉 Everyone has paid! No pending balance!';
      const lines = customers.map((c,i) => `${i+1}. ${c.name} — ₹${c.totalDue}`).join('\n');
      const total = customers.reduce((s,c)=>s+c.totalDue,0);
      return `📋 Pending Balance List:\n━━━━━━━━━━━━━━\n${lines}\n━━━━━━━━━━━━━━\n💰 Total pending: ₹${total}`;
    },
    hi: (customers) => {
      if (!customers.length) return '🎉 Sab ne pay kar diya! Koi pending nahi!';
      const lines = customers.map((c,i) => `${i+1}. ${c.name} — ₹${c.totalDue}`).join('\n');
      const total = customers.reduce((s,c)=>s+c.totalDue,0);
      return `📋 Pending Balance List:\n━━━━━━━━━━━━━━\n${lines}\n━━━━━━━━━━━━━━\n💰 Kul pending: ₹${total}`;
    },
  },

  // ── Today summary ──
  todaySummary: {
    ta: (sales, payments, customers) =>
      `📊 Indru Summary:\n━━━━━━━━━━━━━━\n💰 Sale: ₹${sales}\n💵 Collection: ₹${payments}\n👥 Customers: ${customers}\n━━━━━━━━━━━━━━\nThanks! 💍`,
    en: (sales, payments, customers) =>
      `📊 Today's Summary:\n━━━━━━━━━━━━━━\n💰 Sales: ₹${sales}\n💵 Collected: ₹${payments}\n👥 Customers: ${customers}\n━━━━━━━━━━━━━━\nThanks! 💍`,
    hi: (sales, payments, customers) =>
      `📊 Aaj ka Summary:\n━━━━━━━━━━━━━━\n💰 Sales: ₹${sales}\n💵 Collection: ₹${payments}\n👥 Customers: ${customers}\n━━━━━━━━━━━━━━\nShukriya! 💍`,
  },

  // ── Monthly report ──
  monthReport: {
    ta: (month, sales, payments, profit, pending) =>
      `📈 ${month} Report:\n━━━━━━━━━━━━━━\n💰 Motta sale: ₹${sales}\n💵 Collection: ₹${payments}\n📌 Pending: ₹${pending}\n💚 Laabam: ₹${profit}\n━━━━━━━━━━━━━━\nNalla business! 🌟`,
    en: (month, sales, payments, profit, pending) =>
      `📈 ${month} Report:\n━━━━━━━━━━━━━━\n💰 Total sales: ₹${sales}\n💵 Collected: ₹${payments}\n📌 Pending: ₹${pending}\n💚 Profit: ₹${profit}\n━━━━━━━━━━━━━━\nGreat work! 🌟`,
    hi: (month, sales, payments, profit, pending) =>
      `📈 ${month} Report:\n━━━━━━━━━━━━━━\n💰 Kul sales: ₹${sales}\n💵 Collection: ₹${payments}\n📌 Pending: ₹${pending}\n💚 Munafa: ₹${profit}\n━━━━━━━━━━━━━━\nBahut achha! 🌟`,
  },

  // ── Payment reminder (sent to customers) ──
  paymentReminder: {
    ta: (sellerName, customerName, amount) =>
      `Vanakkam ${customerName} akka/anna! 🙏\n\n${sellerName} kitta ₹${amount} kodukka irukku.\n\nConvenient-a kudungal! 😊\nThank you! 💍`,
    en: (sellerName, customerName, amount) =>
      `Hello ${customerName}! 🙏\n\nYou have a pending payment of ₹${amount} with ${sellerName}.\n\nPlease pay at your convenience! 😊\nThank you! 💍`,
    hi: (sellerName, customerName, amount) =>
      `Namaste ${customerName} ji! 🙏\n\n${sellerName} ko ₹${amount} dena hai aapko.\n\nJab ho sake de dena! 😊\nShukriya! 💍`,
  },

  // ── Stock low alert ──
  stockLow: {
    ta: (items) => `⚠️ Stock Kuravaa Iruku!\n\n${items.map(i=>`• ${i.name}: ${i.quantity} mattum baaki`).join('\n')}\n\nSeekarama vaangidunga! 🛒`,
    en: (items) => `⚠️ Low Stock Alert!\n\n${items.map(i=>`• ${i.name}: Only ${i.quantity} left`).join('\n')}\n\nTime to restock! 🛒`,
    hi: (items) => `⚠️ Stock Kam Hai!\n\n${items.map(i=>`• ${i.name}: Sirf ${i.quantity} baki`).join('\n')}\n\nJaldi mangao! 🛒`,
  },

  // ── Help menu ──
  help: {
    ta: () => `💍 JewelKit Commands:\n━━━━━━━━━━━━━━\n💰 Sale:\n"Kavitha 500 vaangi"\n\n💵 Payment:\n"Kavitha 200 kuduthal"\n\n📊 Balance:\n"Kavitha balance"\n\n📋 Pending list:\n"list"\n\n📈 Indru report:\n"today"\n\n📅 Month report:\n"report"\n\n📦 Stock:\n"stock"\n━━━━━━━━━━━━━━\nSupport: WhatsApp panunga!`,
    en: () => `💍 JewelKit Commands:\n━━━━━━━━━━━━━━\n💰 Sale:\n"Kavitha bought 500"\n\n💵 Payment:\n"Kavitha paid 200"\n\n📊 Balance:\n"Kavitha balance"\n\n📋 List: "list"\n\n📈 Today: "today"\n\n📅 Report: "report"\n\n📦 Stock: "stock"\n━━━━━━━━━━━━━━\nSupport: WhatsApp us!`,
    hi: () => `💍 JewelKit Commands:\n━━━━━━━━━━━━━━\n💰 Sale:\n"Kavitha ne 500 ka liya"\n\n💵 Payment:\n"Kavitha ne 200 diya"\n\n📊 Balance:\n"Kavitha balance"\n\n📋 List: "list"\n\n📈 Aaj: "today"\n\n📅 Report: "report"\n\n📦 Stock: "stock"\n━━━━━━━━━━━━━━\nSupport: WhatsApp karein!`,
  },

  // ── Subscription expired ──
  expired: {
    ta: () => `⚠️ உங்கள் JewelKit subscription mudinjuchu.\n\nThanks panna:\nPhonePe/GPay: 9940612737\n₹99 adutha maasathukku\n\nPayment pannittu "paid" nu message pannunga!`,
    en: () => `⚠️ Your JewelKit subscription has expired.\n\nTo renew:\nPhonePe/GPay: 9940612737\n₹99 for next month\n\nAfter payment send "paid"!`,
    hi: () => `⚠️ Aapka JewelKit subscription khatam ho gaya.\n\nRenew karne ke liye:\nPhonePe/GPay: 9940612737\n₹99 agle mahine ke liye\n\nPayment ke baad "paid" bhejein!`,
  },

  // ── Error / unclear ──
  unclear: {
    ta: () => `🤔 Puriyala! Enna pannum nu solli type pannunga.\n"help" nu type pannunga — commands kaatturom!`,
    en: () => `🤔 I didn't understand! Please type more clearly.\nType "help" to see all commands!`,
    hi: () => `🤔 Samajh nahi aaya! Thoda clearly type karein.\n"help" type karein — sab commands dikhenge!`,
  },
};

module.exports = R;

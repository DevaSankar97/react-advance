// ══════════════════════════════════════════════
//  JewelKit Bot Engine
//  Core message processing logic
// ══════════════════════════════════════════════
const Seller      = require('../models/Seller');
const Customer    = require('../models/Customer');
const Transaction = require('../models/Transaction');
const Stock       = require('../models/Stock');
const { parseMessage } = require('./nlpParser');
const R           = require('./responses');

// ── Get or create seller by phone ──
async function getOrCreateSeller(phone, name = null) {
  let seller = await Seller.findOne({ phone });
  if (!seller) {
    seller = await Seller.create({
      phone,
      name: name || phone,
      language: 'ta',  // default Tamil
    });
  }
  return seller;
}

// ── Get all customers for a seller ──
async function getCustomers(sellerId) {
  return Customer.find({ seller: sellerId, isActive: true });
}

// ── Find customer by name (fuzzy) ──
async function findCustomer(sellerId, name) {
  if (!name) return null;
  const customers = await getCustomers(sellerId);
  const nameLower = name.toLowerCase().trim();

  // Exact match first
  let match = customers.find(c => c.name.toLowerCase() === nameLower);
  if (match) return match;

  // Partial match
  match = customers.find(c =>
    c.name.toLowerCase().includes(nameLower) ||
    nameLower.includes(c.name.toLowerCase())
  );
  return match || null;
}

// ── Process incoming WhatsApp message ──
async function processMessage(phone, text, source = 'twilio') {
  // Normalize phone
  const normalPhone = phone.replace('whatsapp:', '').replace(/\s/g,'');
  const seller = await getOrCreateSeller(normalPhone);
  const lang   = seller.language || 'ta';

  // Check subscription
  if (seller.plan === 'free' && new Date() > seller.planExpiry) {
    return R.expired[lang]();
  }

  // Get all customers for NLP context
  const customers = await getCustomers(seller._id);

  // Parse message
  const parsed = parseMessage(text, customers);

  // Update seller language if detected
  if (parsed.language && parsed.language !== seller.language) {
    seller.language = parsed.language;
    await seller.save();
  }

  const { intent, amount, name } = parsed;
  const useLang = parsed.language || lang;

  // ── Handle first-time user ──
  if (!seller.name || seller.name === normalPhone) {
    seller.name = text.trim();
    await seller.save();
    return R.welcome[useLang](seller.name);
  }

  // ── Route intent ──
  switch (intent) {

    case 'sale': {
      if (!name)   return R.unclear[useLang]();
      if (!amount) return R.unclear[useLang]();

      let customer = await findCustomer(seller._id, name);
      if (!customer) {
        // Auto-create new customer
        customer = await Customer.create({ seller: seller._id, name, totalDue: 0 });
      }

      const balanceBefore = customer.totalDue;
      const balanceAfter  = balanceBefore + amount;

      customer.totalDue = balanceAfter;
      await customer.save();

      await Transaction.create({
        seller: seller._id, customer: customer._id,
        type: 'sale', saleAmount: amount, items: text,
        balanceBefore, balanceAfter,
        source, rawText: text
      });

      return R.saleAdded[useLang](customer.name, amount, balanceAfter);
    }

    case 'payment': {
      if (!name)   return R.unclear[useLang]();
      if (!amount) return R.unclear[useLang]();

      const customer = await findCustomer(seller._id, name);
      if (!customer) return R.customerNotFound[useLang](name);

      const balanceBefore = customer.totalDue;
      const balanceAfter  = Math.max(0, balanceBefore - amount);

      customer.totalDue = balanceAfter;
      await customer.save();

      await Transaction.create({
        seller: seller._id, customer: customer._id,
        type: 'payment', paidAmount: amount,
        balanceBefore, balanceAfter,
        source, rawText: text
      });

      return R.paymentAdded[useLang](customer.name, amount, balanceAfter);
    }

    case 'balance': {
      if (!name) {
        // Show all balances if no name given
        const pending = customers.filter(c => c.totalDue > 0).sort((a,b) => b.totalDue - a.totalDue);
        return R.pendingList[useLang](pending);
      }
      const customer = await findCustomer(seller._id, name);
      if (!customer) return R.customerNotFound[useLang](name);

      const lastTxn = await Transaction.findOne({ customer: customer._id }).sort({ date: -1 });
      return R.balance[useLang](customer.name, customer.totalDue, lastTxn?.date);
    }

    case 'list': {
      const pending = customers.filter(c => c.totalDue > 0).sort((a,b) => b.totalDue - a.totalDue);
      return R.pendingList[useLang](pending);
    }

    case 'today': {
      const today = new Date(); today.setHours(0,0,0,0);
      const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate()+1);
      const txns = await Transaction.find({
        seller: seller._id,
        date: { $gte: today, $lt: tomorrow }
      });
      const sales    = txns.filter(t=>t.type==='sale').reduce((s,t)=>s+t.saleAmount,0);
      const payments = txns.filter(t=>t.type==='payment').reduce((s,t)=>s+t.paidAmount,0);
      const uniqueCustomers = [...new Set(txns.map(t=>t.customer.toString()))].length;
      return R.todaySummary[useLang](sales, payments, uniqueCustomers);
    }

    case 'report': {
      const now = new Date();
      const m   = now.getMonth()+1, y = now.getFullYear();
      const start = new Date(y,m-1,1), end = new Date(y,m,1);
      const txns = await Transaction.find({
        seller: seller._id,
        date: { $gte: start, $lt: end }
      });
      const sales    = txns.filter(t=>t.type==='sale').reduce((s,t)=>s+t.saleAmount,0);
      const payments = txns.filter(t=>t.type==='payment').reduce((s,t)=>s+t.paidAmount,0);
      const pending  = customers.reduce((s,c)=>s+c.totalDue,0);
      const monthName= now.toLocaleDateString('en-IN',{month:'long',year:'numeric'});
      return R.monthReport[useLang](monthName, sales, payments, payments, pending);
    }

    case 'stock': {
      const stocks = await Stock.find({ seller: seller._id, isActive: true });
      if (!stocks.length) {
        const msgs = { ta:'📦 Stock details illa. Dashboard-la add pannunga!', en:'📦 No stock found. Add items in dashboard!', hi:'📦 Stock nahi hai. Dashboard mein add karein!' };
        return msgs[useLang];
      }
      const lines = stocks.map(s => `• ${s.name}: ${s.quantity} pieces`).join('\n');
      const hdr = { ta:'📦 Stock Summary:', en:'📦 Stock Summary:', hi:'📦 Stock Summary:' };
      return `${hdr[useLang]}\n━━━━━━━━━━━━━━\n${lines}`;
    }

    case 'help': {
      return R.help[useLang]();
    }

    case 'ambiguous': {
      // Has a number but unclear intent — ask for clarification
      const msgs = {
        ta:`🤔 ₹${amount} sale-aa illaa payment-aa?\n"Sale" nu illaa "Payment" nu reply pannunga`,
        en:`🤔 Is ₹${amount} a sale or payment?\nReply "Sale" or "Payment"`,
        hi:`🤔 ₹${amount} sale hai ya payment?\n"Sale" ya "Payment" reply karein`
      };
      // Save context for next message
      seller.botState = { step: 'clarify_amount', context: { amount, text }, lastMessage: new Date() };
      await seller.save();
      return msgs[useLang];
    }

    default: {
      return R.unclear[useLang]();
    }
  }
}

// ── Send payment reminders to all customers ──
async function sendMonthlyReminders(sendWhatsApp) {
  const sellers = await Seller.find({ isActive: true, plan: 'paid' });
  let totalSent = 0;

  for (const seller of sellers) {
    const customers = await Customer.find({ seller: seller._id, totalDue: { $gt: 0 } });
    for (const customer of customers) {
      if (!customer.phone) continue;
      const lang = seller.language || 'ta';
      const msg  = R.paymentReminder[lang](seller.businessName || seller.name, customer.name, customer.totalDue);
      try {
        await sendWhatsApp(`+91${customer.phone.replace(/\D/g,'')}`, msg);
        totalSent++;
      } catch (err) {
        console.error(`Failed to send reminder to ${customer.phone}:`, err.message);
      }
    }
  }
  return totalSent;
}

module.exports = { processMessage, getOrCreateSeller, sendMonthlyReminders };

const mongoose = require('mongoose');

const mockTestSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    title: { type: String, required: true }, // "TNPSC Group 4 - Full Mock Test 01"
    type: { type: String, enum: ['full', 'topic_wise', 'previous_year'], default: 'full' },
    subject: { type: String }, // set when type === 'topic_wise'
    durationMinutes: { type: Number, required: true },
    totalMarks: { type: Number, required: true },
    negativeMarking: { type: Boolean, default: false },
    negativeMarkPerWrong: { type: Number, default: 0 },
    questions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Question' }],
    isFree: { type: Boolean, default: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('MockTest', mockTestSchema);

const mongoose = require('mongoose');

const cutoffTrendSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    year: { type: Number, required: true },
    post: { type: String }, // e.g. "Junior Assistant", "VAO" for TNPSC Group 4
    category: {
      type: String,
      enum: ['GENERAL', 'BC', 'BCM', 'MBC_DNC', 'SC', 'SCA', 'ST', 'OTHER'],
      default: 'GENERAL'
    },
    cutoffMarks: { type: Number, required: true },
    totalMarks: { type: Number },
    totalVacancies: { type: Number },
    sourceUrl: { type: String }
  },
  { timestamps: true }
);

cutoffTrendSchema.index({ exam: 1, year: 1, post: 1, category: 1 });

module.exports = mongoose.model('CutoffTrend', cutoffTrendSchema);

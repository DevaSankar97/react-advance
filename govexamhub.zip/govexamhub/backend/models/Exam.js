const mongoose = require('mongoose');

const examPatternStageSchema = new mongoose.Schema({
  stageName: { type: String, required: true }, // e.g. "Prelims", "Tier 1", "CBT 1"
  subjects: [{ type: String }],
  durationMinutes: { type: Number },
  totalMarks: { type: Number },
  totalQuestions: { type: Number },
  negativeMarking: { type: Boolean, default: false },
  negativeMarkPerWrong: { type: Number, default: 0 }
}, { _id: false });

const examSchema = new mongoose.Schema(
  {
    name: { type: String, required: true }, // "TNPSC Group 4"
    code: { type: String, required: true, unique: true, uppercase: true, trim: true }, // "TNPSC_GROUP4"
    category: {
      type: String,
      required: true,
      enum: ['TNPSC', 'RRB', 'IBPS', 'SSC', 'OTHER']
    },
    shortDescription: { type: String },
    conductingBody: { type: String }, // "Tamil Nadu Public Service Commission"
    officialSiteUrl: { type: String },
    eligibility: {
      minAge: Number,
      maxAge: Number,
      educationQualification: String
    },
    examPattern: [examPatternStageSchema],
    isActive: { type: Boolean, default: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Exam', examSchema);

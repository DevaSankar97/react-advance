const mongoose = require('mongoose');

const topicSchema = new mongoose.Schema({
  topicName: { type: String, required: true },
  subtopics: [{ type: String }],
  weightagePercent: { type: Number }, // approx % of questions from this topic
  oneMarkNotesUrl: { type: String } // link to short-notes PDF resource, filled later
}, { _id: false });

const syllabusSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    subject: { type: String, required: true }, // "General Tamil", "Aptitude", "General Science"
    topics: [topicSchema],
    officialSourceUrl: { type: String },
    lastVerifiedAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

syllabusSchema.index({ exam: 1, subject: 1 }, { unique: true });

module.exports = mongoose.model('Syllabus', syllabusSchema);

const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    title: { type: String, required: true },
    category: {
      type: String,
      enum: ['notification', 'admit_card', 'result', 'answer_key', 'exam_date', 'other'],
      default: 'notification'
    },
    description: { type: String },
    importantDate: { type: Date }, // exam date / last date to apply / result date etc
    sourceUrl: { type: String, required: true },
    // hash of title+url used by the scraper to detect duplicates so the same
    // notification isn't inserted twice on every scrape run
    dedupeHash: { type: String, required: true, unique: true },
    scrapedAt: { type: Date, default: Date.now },
    isActive: { type: Boolean, default: true }
  },
  { timestamps: true }
);

notificationSchema.index({ exam: 1, importantDate: -1 });

module.exports = mongoose.model('Notification', notificationSchema);

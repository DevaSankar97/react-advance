const mongoose = require('mongoose');

const answerSchema = new mongoose.Schema({
  question: { type: mongoose.Schema.Types.ObjectId, ref: 'Question', required: true },
  selectedOptionIndex: { type: Number }, // null/undefined = not attempted
  isCorrect: { type: Boolean, default: false }
}, { _id: false });

const mockTestAttemptSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    mockTest: { type: mongoose.Schema.Types.ObjectId, ref: 'MockTest', required: true },
    answers: [answerSchema],
    totalMarksScored: { type: Number, default: 0 },
    correctCount: { type: Number, default: 0 },
    wrongCount: { type: Number, default: 0 },
    unattemptedCount: { type: Number, default: 0 },
    timeTakenSeconds: { type: Number },
    startedAt: { type: Date, default: Date.now },
    submittedAt: { type: Date }
  },
  { timestamps: true }
);

module.exports = mongoose.model('MockTestAttempt', mockTestAttemptSchema);

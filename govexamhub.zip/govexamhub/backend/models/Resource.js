const mongoose = require('mongoose');

const resourceSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
    subject: { type: String, required: true },
    topic: { type: String },
    title: { type: String, required: true },
    type: {
      type: String,
      enum: ['one_mark_pdf', 'short_note', 'previous_year_paper', 'ebook'],
      required: true
    },
    fileUrl: { type: String, required: true }, // served from your storage/CDN
    fileSizeKb: { type: Number },
    language: { type: String, enum: ['english', 'tamil', 'bilingual'], default: 'english' },
    isVerified: { type: Boolean, default: false }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Resource', resourceSchema);

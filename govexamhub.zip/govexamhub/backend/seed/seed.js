/**
 * Seed script - run with `npm run seed`
 * Populates the database with a realistic TNPSC Group 4 example so the
 * frontend has real content to render immediately. Extend this same
 * pattern for RRB, IBPS, and SSC exams.
 */
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');

const Exam = require('../models/Exam');
const Syllabus = require('../models/Syllabus');
const Question = require('../models/Question');
const MockTest = require('../models/MockTest');
const CutoffTrend = require('../models/CutoffTrend');
const Notification = require('../models/Notification');
const Resource = require('../models/Resource');
const crypto = require('crypto');

async function seed() {
  await connectDB();
  console.log('Clearing existing data...');
  await Promise.all([
    Exam.deleteMany({}),
    Syllabus.deleteMany({}),
    Question.deleteMany({}),
    MockTest.deleteMany({}),
    CutoffTrend.deleteMany({}),
    Notification.deleteMany({}),
    Resource.deleteMany({})
  ]);

  console.log('Creating TNPSC Group 4 exam...');
  const tnpscGroup4 = await Exam.create({
    name: 'TNPSC Group 4',
    code: 'TNPSC_GROUP4',
    category: 'TNPSC',
    shortDescription: 'Combined Civil Services Examination - IV for Junior Assistant, VAO, Bill Collector and other posts.',
    conductingBody: 'Tamil Nadu Public Service Commission',
    officialSiteUrl: 'https://www.tnpsc.gov.in',
    eligibility: { minAge: 18, maxAge: 30, educationQualification: 'Pass in SSLC (10th) or equivalent' },
    examPattern: [
      {
        stageName: 'Written Examination',
        subjects: ['General Tamil / General English', 'General Studies', 'Aptitude and Mental Ability Test'],
        durationMinutes: 180,
        totalMarks: 300,
        totalQuestions: 200,
        negativeMarking: false,
        negativeMarkPerWrong: 0
      }
    ]
  });

  console.log('Creating syllabus...');
  await Syllabus.create([
    {
      exam: tnpscGroup4._id,
      subject: 'General Studies',
      officialSourceUrl: 'https://www.tnpsc.gov.in',
      topics: [
        { topicName: 'General Science', subtopics: ['Physics basics', 'Chemistry basics', 'Biology basics', 'Environmental science'], weightagePercent: 15 },
        { topicName: 'Current Events', subtopics: ['National', 'International', 'Tamil Nadu specific', 'Sports'], weightagePercent: 10 },
        { topicName: 'Geography', subtopics: ['Physical geography of India', 'Tamil Nadu geography', 'World geography basics'], weightagePercent: 10 },
        { topicName: 'History and Culture of India', subtopics: ['Ancient India', 'Medieval India', 'Modern India', 'Freedom struggle'], weightagePercent: 15 },
        { topicName: 'Indian Polity', subtopics: ['Constitution', 'Fundamental rights and duties', 'Union and state government'], weightagePercent: 12 },
        { topicName: 'Indian Economy', subtopics: ['Five year plans', 'Banking basics', 'Budget basics'], weightagePercent: 10 },
        { topicName: 'Tamil Nadu History, Culture, Heritage and Socio-Political Movements', subtopics: ['Tamil literature history', 'Socio-political movements in TN'], weightagePercent: 13 }
      ]
    },
    {
      exam: tnpscGroup4._id,
      subject: 'Aptitude and Mental Ability Test',
      officialSourceUrl: 'https://www.tnpsc.gov.in',
      topics: [
        { topicName: 'Simplification', subtopics: ['BODMAS', 'Fractions', 'Approximation'], weightagePercent: 10 },
        { topicName: 'Percentage', subtopics: ['Basic percentage', 'Percentage change problems'], weightagePercent: 8 },
        { topicName: 'Ratio and Proportion', subtopics: [], weightagePercent: 8 },
        { topicName: 'Time and Work', subtopics: [], weightagePercent: 8 },
        { topicName: 'Time and Distance', subtopics: ['Speed conversions', 'Trains', 'Boats and streams'], weightagePercent: 8 },
        { topicName: 'Simple Interest and Compound Interest', subtopics: [], weightagePercent: 6 },
        { topicName: 'Area and Volume', subtopics: [], weightagePercent: 6 },
        { topicName: 'Logical Reasoning', subtopics: ['Blood relations', 'Coding-decoding', 'Series', 'Puzzles'], weightagePercent: 14 },
        { topicName: 'Data Interpretation', subtopics: ['Tables', 'Bar graphs', 'Pie charts'], weightagePercent: 10 }
      ]
    }
  ]);

  console.log('Creating sample verified questions (PYQ + practice)...');
  const questions = await Question.create([
    {
      exam: tnpscGroup4._id,
      subject: 'Aptitude and Mental Ability Test',
      topic: 'Percentage',
      questionText: 'If 40% of a number is 80, what is the number?',
      options: ['160', '200', '180', '220'],
      correctOptionIndex: 1,
      explanation: '40% of x = 80  =>  x = 80 / 0.40 = 200.',
      marks: 1,
      source: 'practice',
      difficulty: 'easy',
      isVerified: true
    },
    {
      exam: tnpscGroup4._id,
      subject: 'General Studies',
      topic: 'Indian Polity',
      questionText: 'Which Article of the Indian Constitution abolishes untouchability?',
      options: ['Article 15', 'Article 16', 'Article 17', 'Article 18'],
      correctOptionIndex: 2,
      explanation: 'Article 17 of the Constitution abolishes untouchability and forbids its practice in any form.',
      marks: 1,
      source: 'pyq',
      year: 2022,
      difficulty: 'medium',
      isVerified: true
    },
    {
      exam: tnpscGroup4._id,
      subject: 'General Studies',
      topic: 'Geography',
      questionText: 'The Palk Strait separates India from which country?',
      options: ['Bangladesh', 'Myanmar', 'Sri Lanka', 'Maldives'],
      correctOptionIndex: 2,
      explanation: 'The Palk Strait lies between Tamil Nadu (India) and Sri Lanka.',
      marks: 1,
      source: 'one_mark',
      difficulty: 'easy',
      isVerified: true
    },
    {
      exam: tnpscGroup4._id,
      subject: 'Aptitude and Mental Ability Test',
      topic: 'Time and Work',
      questionText: 'A can finish a piece of work in 12 days and B can finish it in 18 days. Working together, how many days will they take?',
      options: ['7.2 days', '6.5 days', '8 days', '9 days'],
      correctOptionIndex: 0,
      explanation: 'Combined rate = 1/12 + 1/18 = 5/36 per day. Time = 36/5 = 7.2 days.',
      marks: 1,
      source: 'practice',
      difficulty: 'medium',
      isVerified: true
    }
  ]);

  console.log('Creating a sample mock test...');
  await MockTest.create({
    exam: tnpscGroup4._id,
    title: 'TNPSC Group 4 - Sample Full Mock Test 01',
    type: 'full',
    durationMinutes: 20,
    totalMarks: questions.reduce((sum, q) => sum + q.marks, 0),
    negativeMarking: false,
    questions: questions.map(q => q._id),
    isFree: true
  });

  console.log('Creating cutoff trend history...');
  await CutoffTrend.create([
    { exam: tnpscGroup4._id, year: 2021, post: 'Junior Assistant', category: 'GENERAL', cutoffMarks: 178, totalMarks: 300 },
    { exam: tnpscGroup4._id, year: 2022, post: 'Junior Assistant', category: 'GENERAL', cutoffMarks: 184, totalMarks: 300 },
    { exam: tnpscGroup4._id, year: 2023, post: 'Junior Assistant', category: 'GENERAL', cutoffMarks: 191, totalMarks: 300 }
  ]);

  console.log('Creating a sample notification...');
  const title = 'TNPSC Group 4 (VAO) 2026 Notification Released';
  const sourceUrl = 'https://www.tnpsc.gov.in';
  await Notification.create({
    exam: tnpscGroup4._id,
    title,
    category: 'notification',
    description: 'TNPSC has released the notification for Group 4 Village Administrative Officer and other posts. Check official site for full details and last date to apply.',
    sourceUrl,
    dedupeHash: crypto.createHash('sha256').update(`${tnpscGroup4._id}|${title}|${sourceUrl}`).digest('hex')
  });

  console.log('Creating a sample resource (one-mark PDF placeholder)...');
  await Resource.create({
    exam: tnpscGroup4._id,
    subject: 'General Studies',
    topic: 'Indian Polity',
    title: 'Indian Polity - One Mark Questions (Set 1)',
    type: 'one_mark_pdf',
    fileUrl: 'https://yourdomain.example/resources/tnpsc-group4-polity-one-mark-set1.pdf',
    language: 'bilingual',
    isVerified: true
  });

  console.log('Seed complete.');
  await mongoose.connection.close();
  process.exit(0);
}

seed().catch(err => {
  console.error('Seed failed:', err);
  process.exit(1);
});

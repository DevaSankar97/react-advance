/**
 * Scheduler
 * ---------------------------------------------------------
 * Registers cron jobs that run each exam board's scraper periodically.
 * This file is required from server.js so the schedule starts as soon
 * as the API server boots. Add one line here per new exam board scraper
 * you build (RRB, IBPS, SSC follow the same pattern as tnpscScraper.js).
 */

const cron = require('node-cron');
const { runTnpscScrape } = require('./tnpscScraper');

// Default: every 6 hours. Override via SCRAPE_INTERVAL_CRON in .env
// Cron format: minute hour day month weekday
const SCHEDULE = process.env.SCRAPE_INTERVAL_CRON || '0 */6 * * *';

function startScheduler() {
  console.log(`Notification scraper scheduled with cron pattern: "${SCHEDULE}"`);

  cron.schedule(SCHEDULE, () => {
    runTnpscScrape();
    // runRrbScrape();   // add once you build the RRB scraper the same way
    // runIbpsScrape();  // add once you build the IBPS scraper the same way
    // runSscScrape();   // add once you build the SSC scraper the same way
  });
}

module.exports = { startScheduler };

/**
 * TNPSC Notification Scraper
 * ---------------------------------------------------------
 * Fetches the "What's New" page from the official TNPSC website,
 * parses new notification entries, and POSTs any new ones to our
 * own /api/notifications endpoint (which deduplicates automatically).
 *
 * IMPORTANT - things you MUST adjust before relying on this in production:
 * 1. The CSS selectors below are placeholders. Open the actual TNPSC page,
 *    inspect the HTML, and update the selectors to match the real markup.
 *    Government sites change their HTML structure without notice, so this
 *    script needs occasional maintenance - that's normal for scrapers.
 * 2. Respect the site's robots.txt and terms of use. This script is rate
 *    limited (one request per run) and only reads public pages - it does
 *    not bypass any login, CAPTCHA, or paywall.
 * 3. Run this on a schedule (see scheduler.js) rather than continuously
 *    hammering the site - every 4-6 hours is more than enough for exam
 *    notifications, which don't change minute-to-minute.
 * 4. This scraper only extracts title + link + date. It deliberately does
 *    NOT attempt to auto-generate summaries or answer keys - that content
 *    needs a human review step (see the isVerified flag on Question model).
 */

const axios = require('axios');
const cheerio = require('cheerio');
const crypto = require('crypto');

const TNPSC_URL = process.env.TNPSC_NOTIFICATIONS_URL || 'https://www.tnpsc.gov.in/English/Whatsnew.aspx';
const API_BASE_URL = process.env.INTERNAL_API_BASE_URL || 'http://localhost:5000/api';
const EXAM_CODE_FALLBACK = 'TNPSC_GENERAL'; // used when a notification can't be mapped to a specific exam

async function fetchTnpscNotifications() {
  const { data: html } = await axios.get(TNPSC_URL, {
    timeout: 15000,
    headers: { 'User-Agent': 'GovExamHub-Bot/1.0 (+https://yourdomain.example/bot)' }
  });

  const $ = cheerio.load(html);
  const notifications = [];

  // PLACEHOLDER SELECTOR - update to match the real TNPSC "What's New" table/list markup
  $('table tr').each((i, el) => {
    const row = $(el);
    const linkEl = row.find('a').first();
    const title = linkEl.text().trim();
    const href = linkEl.attr('href');
    const dateText = row.find('td').last().text().trim();

    if (title && href) {
      notifications.push({
        title,
        sourceUrl: href.startsWith('http') ? href : `https://www.tnpsc.gov.in/${href.replace(/^\//, '')}`,
        rawDateText: dateText
      });
    }
  });

  return notifications;
}

function guessCategory(title) {
  const t = title.toLowerCase();
  if (t.includes('admit card') || t.includes('hall ticket')) return 'admit_card';
  if (t.includes('result')) return 'result';
  if (t.includes('answer key')) return 'answer_key';
  if (t.includes('exam date') || t.includes('schedule')) return 'exam_date';
  return 'notification';
}

async function pushToApi(notification, examCode) {
  try {
    const res = await axios.post(`${API_BASE_URL}/notifications`, {
      examCode,
      title: notification.title,
      category: guessCategory(notification.title),
      sourceUrl: notification.sourceUrl,
      importantDate: null // parse rawDateText into a real Date once you confirm the site's date format
    });
    return res.data;
  } catch (err) {
    console.error(`Failed to push notification "${notification.title}":`, err.response?.data || err.message);
    return null;
  }
}

async function runTnpscScrape() {
  console.log(`[${new Date().toISOString()}] Starting TNPSC notification scrape...`);
  try {
    const notifications = await fetchTnpscNotifications();
    console.log(`Found ${notifications.length} notification rows on the page.`);

    let created = 0;
    for (const notification of notifications) {
      const result = await pushToApi(notification, EXAM_CODE_FALLBACK);
      if (result && result._id) created += 1;
    }
    console.log(`Scrape complete. ${created} new notification(s) added.`);
  } catch (err) {
    console.error('TNPSC scrape failed:', err.message);
  }
}

// Allow running directly: `node scraper/tnpscScraper.js`
if (require.main === module) {
  require('dotenv').config();
  runTnpscScrape();
}

module.exports = { runTnpscScrape, fetchTnpscNotifications };

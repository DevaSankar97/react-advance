const asyncHandler = require('express-async-handler');
const crypto = require('crypto');
const Notification = require('../models/Notification');
const Exam = require('../models/Exam');

// GET /api/notifications -> latest notifications across all exams (home page feed)
const getAllNotifications = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit) || 20;
  const notifications = await Notification.find({ isActive: true })
    .populate('exam', 'name code category')
    .sort({ scrapedAt: -1 })
    .limit(limit);
  res.json(notifications);
});

// GET /api/exams/:code/notifications -> notifications for one exam
const getNotificationsByExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const notifications = await Notification.find({ exam: exam._id, isActive: true })
    .sort({ scrapedAt: -1 });
  res.json(notifications);
});

// POST /api/notifications -> used by the scraper (or admin) to insert a new notification.
// Deduplicates using a hash of exam+title+sourceUrl so re-running the scraper
// doesn't create duplicate entries.
const createNotification = asyncHandler(async (req, res) => {
  const { examCode, title, category, description, importantDate, sourceUrl } = req.body;
  const exam = await Exam.findOne({ code: examCode.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found for this notification');
  }

  const dedupeHash = crypto
    .createHash('sha256')
    .update(`${exam._id}|${title}|${sourceUrl}`)
    .digest('hex');

  const existing = await Notification.findOne({ dedupeHash });
  if (existing) {
    return res.status(200).json({ message: 'Already exists, skipped', notification: existing });
  }

  const notification = await Notification.create({
    exam: exam._id,
    title,
    category,
    description,
    importantDate,
    sourceUrl,
    dedupeHash
  });

  res.status(201).json(notification);
});

module.exports = { getAllNotifications, getNotificationsByExam, createNotification };

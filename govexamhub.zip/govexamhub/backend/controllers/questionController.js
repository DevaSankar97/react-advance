const asyncHandler = require('express-async-handler');
const Question = require('../models/Question');
const Exam = require('../models/Exam');

// GET /api/exams/:code/questions?source=pyq&subject=Aptitude&year=2023
const getQuestions = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const filter = { exam: exam._id, isVerified: true };
  if (req.query.source) filter.source = req.query.source;
  if (req.query.subject) filter.subject = req.query.subject;
  if (req.query.topic) filter.topic = req.query.topic;
  if (req.query.year) filter.year = parseInt(req.query.year);

  const questions = await Question.find(filter).sort({ year: -1, createdAt: -1 });
  res.json(questions);
});

// POST /api/exams/:code/questions -> add a question (admin / bulk import).
// isVerified defaults to false so AI-drafted or scraped content is reviewed
// before it can appear in a live mock test or PYQ list.
const createQuestion = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const question = await Question.create({ ...req.body, exam: exam._id });
  res.status(201).json(question);
});

// PATCH /api/questions/:id/verify -> mark a question reviewed and safe to publish
const verifyQuestion = asyncHandler(async (req, res) => {
  const question = await Question.findByIdAndUpdate(
    req.params.id,
    { isVerified: true },
    { new: true }
  );
  if (!question) {
    res.status(404);
    throw new Error('Question not found');
  }
  res.json(question);
});

module.exports = { getQuestions, createQuestion, verifyQuestion };

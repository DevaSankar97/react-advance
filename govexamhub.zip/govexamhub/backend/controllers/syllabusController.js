const asyncHandler = require('express-async-handler');
const Syllabus = require('../models/Syllabus');
const Exam = require('../models/Exam');

// GET /api/exams/:code/syllabus -> full syllabus (all subjects) for an exam
const getSyllabusByExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const syllabus = await Syllabus.find({ exam: exam._id }).sort({ subject: 1 });
  res.json(syllabus);
});

// POST /api/exams/:code/syllabus -> add/replace a subject's syllabus (admin)
const upsertSyllabus = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const { subject, topics, officialSourceUrl } = req.body;
  const syllabus = await Syllabus.findOneAndUpdate(
    { exam: exam._id, subject },
    { exam: exam._id, subject, topics, officialSourceUrl, lastVerifiedAt: new Date() },
    { new: true, upsert: true, runValidators: true }
  );
  res.status(201).json(syllabus);
});

module.exports = { getSyllabusByExam, upsertSyllabus };

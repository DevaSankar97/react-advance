const asyncHandler = require('express-async-handler');
const Exam = require('../models/Exam');

// GET /api/exams  -> list all exams, optionally filter by category
const getExams = asyncHandler(async (req, res) => {
  const filter = { isActive: true };
  if (req.query.category) filter.category = req.query.category.toUpperCase();
  const exams = await Exam.find(filter).sort({ category: 1, name: 1 });
  res.json(exams);
});

// GET /api/exams/:code -> single exam by code, e.g. TNPSC_GROUP4
const getExamByCode = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  res.json(exam);
});

// POST /api/exams -> create exam (admin)
const createExam = asyncHandler(async (req, res) => {
  const exam = await Exam.create(req.body);
  res.status(201).json(exam);
});

// PUT /api/exams/:code -> update exam (admin)
const updateExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findOneAndUpdate(
    { code: req.params.code.toUpperCase() },
    req.body,
    { new: true, runValidators: true }
  );
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  res.json(exam);
});

// DELETE /api/exams/:code -> soft delete (admin)
const deleteExam = asyncHandler(async (req, res) => {
  const exam = await Exam.findOneAndUpdate(
    { code: req.params.code.toUpperCase() },
    { isActive: false },
    { new: true }
  );
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  res.json({ message: 'Exam deactivated' });
});

module.exports = { getExams, getExamByCode, createExam, updateExam, deleteExam };

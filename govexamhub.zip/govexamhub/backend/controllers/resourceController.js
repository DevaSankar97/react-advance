const asyncHandler = require('express-async-handler');
const Resource = require('../models/Resource');
const Exam = require('../models/Exam');

// GET /api/exams/:code/resources?type=one_mark_pdf&subject=Aptitude
const getResources = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const filter = { exam: exam._id, isVerified: true };
  if (req.query.type) filter.type = req.query.type;
  if (req.query.subject) filter.subject = req.query.subject;

  const resources = await Resource.find(filter).sort({ subject: 1, topic: 1 });
  res.json(resources);
});

// POST /api/exams/:code/resources -> add a resource (admin / bulk upload)
const createResource = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const resource = await Resource.create({ ...req.body, exam: exam._id });
  res.status(201).json(resource);
});

module.exports = { getResources, createResource };

const asyncHandler = require('express-async-handler');
const CutoffTrend = require('../models/CutoffTrend');
const Exam = require('../models/Exam');

// GET /api/exams/:code/cutoffs -> historical cutoff data, optionally by post/category
const getCutoffTrends = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const filter = { exam: exam._id };
  if (req.query.post) filter.post = req.query.post;
  if (req.query.category) filter.category = req.query.category.toUpperCase();

  const trends = await CutoffTrend.find(filter).sort({ year: 1 });
  res.json(trends);
});

// POST /api/exams/:code/cutoffs -> add a year's cutoff record (admin)
const addCutoffTrend = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const trend = await CutoffTrend.create({ ...req.body, exam: exam._id });
  res.status(201).json(trend);
});

module.exports = { getCutoffTrends, addCutoffTrend };

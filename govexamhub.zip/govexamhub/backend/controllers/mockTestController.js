const asyncHandler = require('express-async-handler');
const mongoose = require('mongoose');
const MockTest = require('../models/MockTest');
const MockTestAttempt = require('../models/MockTestAttempt');
const Question = require('../models/Question');
const Exam = require('../models/Exam');

// GET /api/exams/:code/mocktests -> list available mock tests for an exam
const getMockTests = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const mockTests = await MockTest.find({ exam: exam._id })
    .select('-questions') // don't leak questions/answers in the listing
    .sort({ createdAt: -1 });
  res.json(mockTests);
});

// GET /api/mocktests/:id/start -> get test with questions (options only, no answers)
const startMockTest = asyncHandler(async (req, res) => {
  const mockTest = await MockTest.findById(req.params.id).populate({
    path: 'questions',
    select: 'questionText options subject topic marks negativeMarks' // correctOptionIndex + explanation withheld
  });
  if (!mockTest) {
    res.status(404);
    throw new Error('Mock test not found');
  }
  res.json(mockTest);
});

// POST /api/exams/:code/mocktests/generate -> auto-generate a randomized mock
// test from the verified question bank. This is the "automation" piece for
// mock tests: once questions exist and are verified, tests build themselves.
const generateMockTest = asyncHandler(async (req, res) => {
  const exam = await Exam.findOne({ code: req.params.code.toUpperCase() });
  if (!exam) {
    res.status(404);
    throw new Error('Exam not found');
  }
  const { title, subject, questionCount = 25, durationMinutes = 30, negativeMarking = false, negativeMarkPerWrong = 0 } = req.body;

  const filter = { exam: exam._id, isVerified: true };
  if (subject) filter.subject = subject;

  const questions = await Question.aggregate([
    { $match: filter },
    { $sample: { size: questionCount } }
  ]);

  if (questions.length === 0) {
    res.status(400);
    throw new Error('No verified questions available to generate a test. Add and verify questions first.');
  }

  const mockTest = await MockTest.create({
    exam: exam._id,
    title: title || `${exam.name} - Auto Mock Test (${new Date().toLocaleDateString()})`,
    type: subject ? 'topic_wise' : 'full',
    subject,
    durationMinutes,
    totalMarks: questions.reduce((sum, q) => sum + (q.marks || 1), 0),
    negativeMarking,
    negativeMarkPerWrong,
    questions: questions.map(q => q._id)
  });

  res.status(201).json(mockTest);
});

// POST /api/mocktests/:id/submit -> score a submitted attempt
const submitMockTest = asyncHandler(async (req, res) => {
  const { userId, answers, timeTakenSeconds } = req.body; // answers: [{questionId, selectedOptionIndex}]

  const mockTest = await MockTest.findById(req.params.id).populate('questions');
  if (!mockTest) {
    res.status(404);
    throw new Error('Mock test not found');
  }

  let totalMarksScored = 0;
  let correctCount = 0;
  let wrongCount = 0;
  let unattemptedCount = 0;

  const scoredAnswers = mockTest.questions.map(question => {
    const submitted = answers.find(a => a.questionId === String(question._id));
    if (!submitted || submitted.selectedOptionIndex === null || submitted.selectedOptionIndex === undefined) {
      unattemptedCount += 1;
      return { question: question._id, selectedOptionIndex: null, isCorrect: false };
    }
    const isCorrect = submitted.selectedOptionIndex === question.correctOptionIndex;
    if (isCorrect) {
      correctCount += 1;
      totalMarksScored += question.marks || 1;
    } else {
      wrongCount += 1;
      if (mockTest.negativeMarking) totalMarksScored -= mockTest.negativeMarkPerWrong || 0;
    }
    return { question: question._id, selectedOptionIndex: submitted.selectedOptionIndex, isCorrect };
  });

  const attempt = await MockTestAttempt.create({
    user: userId,
    mockTest: mockTest._id,
    answers: scoredAnswers,
    totalMarksScored,
    correctCount,
    wrongCount,
    unattemptedCount,
    timeTakenSeconds,
    submittedAt: new Date()
  });

  res.status(201).json(attempt);
});

// GET /api/mocktests/attempts/:attemptId -> full result with explanations
const getAttemptResult = asyncHandler(async (req, res) => {
  const attempt = await MockTestAttempt.findById(req.params.attemptId)
    .populate({
      path: 'answers.question',
      select: 'questionText options correctOptionIndex explanation subject topic'
    })
    .populate('mockTest', 'title totalMarks');
  if (!attempt) {
    res.status(404);
    throw new Error('Attempt not found');
  }
  res.json(attempt);
});

module.exports = {
  getMockTests,
  startMockTest,
  generateMockTest,
  submitMockTest,
  getAttemptResult
};

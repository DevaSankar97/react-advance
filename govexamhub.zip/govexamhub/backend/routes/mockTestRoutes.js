const express = require('express');
const router = express.Router();
const { startMockTest, submitMockTest, getAttemptResult } = require('../controllers/mockTestController');
const { verifyQuestion } = require('../controllers/questionController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

router.get('/:id/start', startMockTest);
router.post('/:id/submit', protect, submitMockTest);
router.get('/attempts/:attemptId', protect, getAttemptResult);

// Question review/verification (admin) - lives here to keep questionRoutes minimal
router.patch('/questions/:id/verify', protect, adminOnly, verifyQuestion);

module.exports = router;

const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');

const { getExams, getExamByCode, createExam, updateExam, deleteExam } = require('../controllers/examController');
const { getSyllabusByExam, upsertSyllabus } = require('../controllers/syllabusController');
const { getNotificationsByExam } = require('../controllers/notificationController');
const { getQuestions, createQuestion } = require('../controllers/questionController');
const { getMockTests, generateMockTest } = require('../controllers/mockTestController');
const { getCutoffTrends, addCutoffTrend } = require('../controllers/cutoffController');
const { getResources, createResource } = require('../controllers/resourceController');

// Core exam CRUD
router.get('/', getExams);
router.post('/', protect, adminOnly, createExam);
router.get('/:code', getExamByCode);
router.put('/:code', protect, adminOnly, updateExam);
router.delete('/:code', protect, adminOnly, deleteExam);

// Nested resources, scoped by exam code
router.get('/:code/syllabus', getSyllabusByExam);
router.post('/:code/syllabus', protect, adminOnly, upsertSyllabus);

router.get('/:code/notifications', getNotificationsByExam);

router.get('/:code/questions', getQuestions);
router.post('/:code/questions', protect, adminOnly, createQuestion);

router.get('/:code/mocktests', getMockTests);
router.post('/:code/mocktests/generate', protect, adminOnly, generateMockTest);

router.get('/:code/cutoffs', getCutoffTrends);
router.post('/:code/cutoffs', protect, adminOnly, addCutoffTrend);

router.get('/:code/resources', getResources);
router.post('/:code/resources', protect, adminOnly, createResource);

module.exports = router;

const express = require('express');
const router = express.Router();
const { getAllNotifications, createNotification } = require('../controllers/notificationController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

router.get('/', getAllNotifications);
// Used by the scraper service (internal) and by admins to manually add a notification
router.post('/', createNotification);

module.exports = router;

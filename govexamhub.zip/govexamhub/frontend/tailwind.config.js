/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#0B1424',
          900: '#101B2D',
          800: '#172438',
          700: '#22314A'
        },
        brass: {
          400: '#D9B24C',
          500: '#C9A227',
          600: '#A9841D'
        },
        paper: '#EDEAE0',
        ledger: '#2F5233'
      },
      fontFamily: {
        display: ['Fraunces', 'serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace']
      }
    }
  },
  plugins: []
};

import React, { useEffect, useState } from 'react';
import { notificationsApi } from '../api/endpoints';

export default function NotificationTicker() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    notificationsApi.latest(10)
      .then(setNotifications)
      .catch(() => setNotifications([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="border border-navy-700 bg-navy-900 rounded-sm overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2 bg-navy-800 border-b border-navy-700">
        <span className="w-2 h-2 rounded-full bg-brass-500 animate-pulse" />
        <span className="font-mono text-xs uppercase tracking-widest text-brass-400">Live Notice Board</span>
      </div>
      <div className="divide-y divide-navy-800">
        {loading && (
          <p className="px-4 py-3 text-sm text-paper/50 font-mono">Fetching latest notifications...</p>
        )}
        {!loading && notifications.length === 0 && (
          <p className="px-4 py-3 text-sm text-paper/50 font-mono">
            No notifications yet — run the scraper or seed script to populate this feed.
          </p>
        )}
        {notifications.map((n) => (
          <a
            key={n._id}
            href={n.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between gap-4 px-4 py-3 hover:bg-navy-800/60 transition-colors"
          >
            <div className="flex items-center gap-3 min-w-0">
              <span className="shrink-0 font-mono text-[10px] uppercase px-2 py-0.5 rounded-sm bg-brass-500/15 text-brass-400 border border-brass-500/30">
                {n.category?.replace('_', ' ')}
              </span>
              <span className="truncate text-sm text-paper/90">{n.title}</span>
            </div>
            <span className="shrink-0 font-mono text-xs text-paper/40">
              {n.exam?.code?.replace('_', ' ')}
            </span>
          </a>
        ))}
      </div>
    </div>
  );
}

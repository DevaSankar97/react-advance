import React from 'react';
import { Link } from 'react-router-dom';

export default function ExamCard({ exam }) {
  return (
    <Link
      to={`/exams/${exam.code}`}
      className="group relative block bg-navy-900 border border-navy-700 rounded-sm p-5 hover:border-brass-500/60 transition-colors"
    >
      {/* perforation strip, like a tear-off admit card edge */}
      <div className="absolute left-0 top-0 bottom-0 w-3 perforated-edge border-r border-navy-700" />
      <div className="pl-4">
        <div className="flex items-center justify-between mb-3">
          <span className="font-mono text-[10px] uppercase tracking-widest text-brass-500 border border-brass-500/40 px-2 py-0.5 rounded-sm">
            {exam.category}
          </span>
          <span className="font-mono text-[10px] text-paper/40">{exam.code}</span>
        </div>
        <h3 className="font-display text-lg text-paper group-hover:text-brass-400 transition-colors">
          {exam.name}
        </h3>
        <p className="text-sm text-paper/60 mt-1 line-clamp-2">{exam.shortDescription}</p>
        <div className="mt-4 flex items-center gap-2 text-xs font-mono text-paper/40">
          <span>View syllabus &amp; mock tests</span>
          <span className="group-hover:translate-x-1 transition-transform">→</span>
        </div>
      </div>
    </Link>
  );
}

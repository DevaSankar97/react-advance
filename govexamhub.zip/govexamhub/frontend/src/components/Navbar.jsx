import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <header className="border-b border-navy-700 bg-navy-950/95 backdrop-blur sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full border-2 border-brass-500 flex items-center justify-center font-mono text-brass-500 text-xs">GH</div>
          <span className="font-display text-xl tracking-wide text-paper">GovExamHub</span>
        </Link>
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-paper/80">
          <Link to="/exams/TNPSC_GROUP4" className="hover:text-brass-400 transition-colors">TNPSC</Link>
          <Link to="/exams" className="hover:text-brass-400 transition-colors">RRB</Link>
          <Link to="/exams" className="hover:text-brass-400 transition-colors">IBPS</Link>
          <Link to="/exams" className="hover:text-brass-400 transition-colors">SSC</Link>
          <Link to="/login" className="px-4 py-1.5 border border-brass-500 rounded-sm text-brass-400 hover:bg-brass-500 hover:text-navy-950 transition-colors">
            Sign in
          </Link>
        </nav>
      </div>
    </header>
  );
}

import React, { useState } from 'react';

export default function Tabs({ tabs }) {
  const [active, setActive] = useState(tabs[0].label);
  const activeTab = tabs.find((t) => t.label === active);

  return (
    <div>
      <div className="flex flex-wrap gap-1 border-b border-navy-700 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.label}
            onClick={() => setActive(tab.label)}
            className={`px-4 py-2.5 font-mono text-xs uppercase tracking-wider border-b-2 transition-colors ${
              active === tab.label
                ? 'border-brass-500 text-brass-400'
                : 'border-transparent text-paper/50 hover:text-paper/80'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div>{activeTab?.content}</div>
    </div>
  );
}

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import ExamsList from './pages/ExamsList';
import ExamDetail from './pages/ExamDetail';
import MockTestRunner from './pages/MockTestRunner';
import MockTestResult from './pages/MockTestResult';
import Login from './pages/Login';
import Register from './pages/Register';

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/exams" element={<ExamsList />} />
        <Route path="/exams/:code" element={<ExamDetail />} />
        <Route path="/mocktest/:id" element={<MockTestRunner />} />
        <Route path="/mocktest/result/:attemptId" element={<MockTestResult />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </div>
  );
}

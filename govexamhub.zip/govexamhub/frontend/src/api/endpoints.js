import apiClient from './client';

export const examsApi = {
  list: (category) => apiClient.get('/exams', { params: category ? { category } : {} }).then(r => r.data),
  get: (code) => apiClient.get(`/exams/${code}`).then(r => r.data),
  syllabus: (code) => apiClient.get(`/exams/${code}/syllabus`).then(r => r.data),
  notifications: (code) => apiClient.get(`/exams/${code}/notifications`).then(r => r.data),
  questions: (code, params) => apiClient.get(`/exams/${code}/questions`, { params }).then(r => r.data),
  mockTests: (code) => apiClient.get(`/exams/${code}/mocktests`).then(r => r.data),
  cutoffs: (code, params) => apiClient.get(`/exams/${code}/cutoffs`, { params }).then(r => r.data),
  resources: (code, params) => apiClient.get(`/exams/${code}/resources`, { params }).then(r => r.data)
};

export const notificationsApi = {
  latest: (limit = 20) => apiClient.get('/notifications', { params: { limit } }).then(r => r.data)
};

export const mockTestApi = {
  start: (id) => apiClient.get(`/mocktests/${id}/start`).then(r => r.data),
  submit: (id, payload) => apiClient.post(`/mocktests/${id}/submit`, payload).then(r => r.data),
  result: (attemptId) => apiClient.get(`/mocktests/attempts/${attemptId}`).then(r => r.data)
};

export const authApi = {
  register: (payload) => apiClient.post('/auth/register', payload).then(r => r.data),
  login: (payload) => apiClient.post('/auth/login', payload).then(r => r.data)
};

import React, { useEffect, useState } from 'react';
import { examsApi } from '../api/endpoints';
import NotificationTicker from '../components/NotificationTicker';
import ExamCard from '../components/ExamCard';

export default function Home() {
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    examsApi.list().then(setExams).catch(() => setExams([])).finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      {/* Hero */}
      <section className="mb-14">
        <p className="font-mono text-xs uppercase tracking-widest text-brass-500 mb-3">
          TNPSC &middot; RRB &middot; IBPS &middot; SSC
        </p>
        <h1 className="font-display text-4xl md:text-5xl leading-tight text-paper max-w-2xl">
          Every syllabus, every notification, every mock test —
          <span className="text-brass-400"> filed and up to date.</span>
        </h1>
        <p className="text-paper/60 mt-4 max-w-xl">
          One portal for government exam preparation. Verified syllabus breakdowns,
          previous year papers with solutions, timed mock tests, and a notification
          board that updates itself.
        </p>
      </section>

      {/* Notice board */}
      <section className="mb-14">
        <NotificationTicker />
      </section>

      {/* Exam grid */}
      <section>
        <h2 className="font-display text-2xl text-paper mb-5">Choose your exam</h2>
        {loading && <p className="text-paper/50 font-mono text-sm">Loading exams...</p>}
        {!loading && exams.length === 0 && (
          <p className="text-paper/50 font-mono text-sm">
            No exams found — run <code className="text-brass-400">npm run seed</code> in the backend to load sample data.
          </p>
        )}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {exams.map((exam) => (
            <ExamCard key={exam._id} exam={exam} />
          ))}
        </div>
      </section>
    </div>
  );
}

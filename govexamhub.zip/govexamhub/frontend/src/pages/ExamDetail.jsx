import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { examsApi } from '../api/endpoints';
import Tabs from '../components/Tabs';

function SyllabusPanel({ syllabus }) {
  if (syllabus.length === 0) return <EmptyState text="No syllabus added yet for this exam." />;
  return (
    <div className="space-y-6">
      {syllabus.map((s) => (
        <div key={s._id} className="border border-navy-700 rounded-sm">
          <div className="bg-navy-800 px-4 py-2.5 border-b border-navy-700">
            <h3 className="font-display text-lg text-brass-400">{s.subject}</h3>
          </div>
          <div className="divide-y divide-navy-800">
            {s.topics.map((topic, i) => (
              <div key={i} className="px-4 py-3 flex items-start justify-between gap-4">
                <div>
                  <p className="text-paper/90 font-medium">{topic.topicName}</p>
                  {topic.subtopics?.length > 0 && (
                    <p className="text-sm text-paper/50 mt-0.5">{topic.subtopics.join(' · ')}</p>
                  )}
                </div>
                {topic.weightagePercent && (
                  <span className="shrink-0 font-mono text-xs text-brass-400 border border-brass-500/30 rounded-sm px-2 py-0.5">
                    ~{topic.weightagePercent}%
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function NotificationsPanel({ notifications }) {
  if (notifications.length === 0) return <EmptyState text="No notifications yet — the scraper will populate this automatically." />;
  return (
    <div className="space-y-3">
      {notifications.map((n) => (
        <a key={n._id} href={n.sourceUrl} target="_blank" rel="noopener noreferrer"
          className="block border border-navy-700 rounded-sm p-4 hover:border-brass-500/50 transition-colors">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-[10px] uppercase px-2 py-0.5 rounded-sm bg-brass-500/15 text-brass-400 border border-brass-500/30">
              {n.category?.replace('_', ' ')}
            </span>
            <span className="font-mono text-xs text-paper/40">
              {new Date(n.scrapedAt).toLocaleDateString()}
            </span>
          </div>
          <p className="text-paper/90">{n.title}</p>
          {n.description && <p className="text-sm text-paper/50 mt-1">{n.description}</p>}
        </a>
      ))}
    </div>
  );
}

function PyqPanel({ questions }) {
  const pyqs = questions.filter((q) => q.source === 'pyq');
  if (pyqs.length === 0) return <EmptyState text="No previous year questions added yet." />;
  return (
    <div className="space-y-4">
      {pyqs.map((q) => (
        <div key={q._id} className="border border-navy-700 rounded-sm p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-mono text-xs text-brass-400">{q.subject} {q.year ? `· ${q.year}` : ''}</span>
          </div>
          <p className="text-paper/90 mb-2">{q.questionText}</p>
          <ul className="text-sm text-paper/70 space-y-1 mb-2">
            {q.options.map((opt, i) => (
              <li key={i} className={i === q.correctOptionIndex ? 'text-ledger font-medium' : ''}>
                {String.fromCharCode(65 + i)}. {opt} {i === q.correctOptionIndex && '✓'}
              </li>
            ))}
          </ul>
          {q.explanation && (
            <p className="text-xs text-paper/50 border-t border-navy-800 pt-2 mt-2">{q.explanation}</p>
          )}
        </div>
      ))}
    </div>
  );
}

function MockTestsPanel({ mockTests }) {
  if (mockTests.length === 0) return <EmptyState text="No mock tests yet — generate one from the verified question bank." />;
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {mockTests.map((mt) => (
        <div key={mt._id} className="border border-navy-700 rounded-sm p-4">
          <h4 className="font-display text-paper mb-2">{mt.title}</h4>
          <div className="flex gap-4 text-xs font-mono text-paper/50 mb-3">
            <span>{mt.durationMinutes} min</span>
            <span>{mt.totalMarks} marks</span>
            <span className="uppercase">{mt.type.replace('_', ' ')}</span>
          </div>
          <Link
            to={`/mocktest/${mt._id}`}
            className="inline-block px-4 py-1.5 rounded-sm border border-brass-500 text-brass-400 text-sm hover:bg-brass-500 hover:text-navy-950 transition-colors"
          >
            Start test
          </Link>
        </div>
      ))}
    </div>
  );
}

function CutoffPanel({ cutoffs }) {
  if (cutoffs.length === 0) return <EmptyState text="No cutoff data added yet." />;
  return (
    <div className="border border-navy-700 rounded-sm overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-navy-800 text-paper/60 font-mono text-xs uppercase">
          <tr>
            <th className="text-left px-4 py-2">Year</th>
            <th className="text-left px-4 py-2">Post</th>
            <th className="text-left px-4 py-2">Category</th>
            <th className="text-right px-4 py-2">Cutoff</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-navy-800">
          {cutoffs.map((c) => (
            <tr key={c._id}>
              <td className="px-4 py-2 font-mono text-brass-400">{c.year}</td>
              <td className="px-4 py-2">{c.post}</td>
              <td className="px-4 py-2">{c.category}</td>
              <td className="px-4 py-2 text-right font-mono">{c.cutoffMarks}/{c.totalMarks}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function EmptyState({ text }) {
  return <p className="text-paper/40 font-mono text-sm border border-dashed border-navy-700 rounded-sm p-6 text-center">{text}</p>;
}

export default function ExamDetail() {
  const { code } = useParams();
  const [exam, setExam] = useState(null);
  const [syllabus, setSyllabus] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [mockTests, setMockTests] = useState([]);
  const [cutoffs, setCutoffs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      examsApi.get(code),
      examsApi.syllabus(code),
      examsApi.notifications(code),
      examsApi.questions(code, {}),
      examsApi.mockTests(code),
      examsApi.cutoffs(code)
    ])
      .then(([e, s, n, q, mt, c]) => {
        setExam(e); setSyllabus(s); setNotifications(n); setQuestions(q); setMockTests(mt); setCutoffs(c);
      })
      .catch(() => setExam(null))
      .finally(() => setLoading(false));
  }, [code]);

  if (loading) return <div className="max-w-6xl mx-auto px-6 py-12 text-paper/50 font-mono text-sm">Loading exam...</div>;
  if (!exam) return <div className="max-w-6xl mx-auto px-6 py-12 text-paper/50 font-mono text-sm">Exam not found. Seed the database first.</div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <p className="font-mono text-xs uppercase tracking-widest text-brass-500 mb-2">{exam.category} &middot; {exam.code}</p>
      <h1 className="font-display text-4xl text-paper mb-2">{exam.name}</h1>
      <p className="text-paper/60 max-w-2xl mb-8">{exam.shortDescription}</p>

      <Tabs
        tabs={[
          { label: 'Syllabus', content: <SyllabusPanel syllabus={syllabus} /> },
          { label: 'Notifications', content: <NotificationsPanel notifications={notifications} /> },
          { label: 'Previous Papers', content: <PyqPanel questions={questions} /> },
          { label: 'Mock Tests', content: <MockTestsPanel mockTests={mockTests} /> },
          { label: 'Cutoff Trends', content: <CutoffPanel cutoffs={cutoffs} /> }
        ]}
      />
    </div>
  );
}

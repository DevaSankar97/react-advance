import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockTestApi } from '../api/endpoints';

export default function MockTestRunner() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [test, setTest] = useState(null);
  const [answers, setAnswers] = useState({}); // questionId -> selectedOptionIndex
  const [secondsLeft, setSecondsLeft] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [startedAt] = useState(Date.now());

  useEffect(() => {
    mockTestApi.start(id).then((data) => {
      setTest(data);
      setSecondsLeft(data.durationMinutes * 60);
    });
  }, [id]);

  const handleSubmit = useCallback(async () => {
    if (submitting || !test) return;
    setSubmitting(true);
    const payload = {
      userId: localStorage.getItem('govexamhub_user_id') || 'guest',
      answers: Object.entries(answers).map(([questionId, selectedOptionIndex]) => ({ questionId, selectedOptionIndex })),
      timeTakenSeconds: Math.round((Date.now() - startedAt) / 1000)
    };
    try {
      const attempt = await mockTestApi.submit(id, payload);
      navigate(`/mocktest/result/${attempt._id}`);
    } catch (err) {
      alert(err.response?.data?.message || 'Submission failed. Sign in and try again.');
      setSubmitting(false);
    }
  }, [answers, id, navigate, startedAt, submitting, test]);

  useEffect(() => {
    if (secondsLeft === null) return;
    if (secondsLeft <= 0) {
      handleSubmit();
      return;
    }
    const timer = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [secondsLeft, handleSubmit]);

  if (!test) return <div className="max-w-3xl mx-auto px-6 py-12 text-paper/50 font-mono text-sm">Loading test...</div>;

  const minutes = String(Math.floor(secondsLeft / 60)).padStart(2, '0');
  const seconds = String(secondsLeft % 60).padStart(2, '0');
  const answeredCount = Object.keys(answers).length;

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <div className="flex items-center justify-between mb-8 sticky top-16 bg-navy-950/95 backdrop-blur py-3 z-30 border-b border-navy-700">
        <div>
          <h1 className="font-display text-xl text-paper">{test.title}</h1>
          <p className="text-xs text-paper/50 font-mono">{answeredCount} / {test.questions.length} answered</p>
        </div>
        <div className="font-mono text-2xl text-brass-400 tabular-nums">{minutes}:{seconds}</div>
      </div>

      <div className="space-y-6">
        {test.questions.map((q, idx) => (
          <div key={q._id} className="border border-navy-700 rounded-sm p-5">
            <p className="font-mono text-xs text-paper/40 mb-2">Q{idx + 1} · {q.subject}</p>
            <p className="text-paper/90 mb-4">{q.questionText}</p>
            <div className="space-y-2">
              {q.options.map((opt, i) => (
                <label
                  key={i}
                  className={`flex items-center gap-3 px-3 py-2 rounded-sm border cursor-pointer transition-colors ${
                    answers[q._id] === i
                      ? 'border-brass-500 bg-brass-500/10'
                      : 'border-navy-700 hover:border-navy-600'
                  }`}
                >
                  <input
                    type="radio"
                    name={q._id}
                    checked={answers[q._id] === i}
                    onChange={() => setAnswers((prev) => ({ ...prev, [q._id]: i }))}
                    className="accent-brass-500"
                  />
                  <span className="text-sm text-paper/80">{opt}</span>
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={handleSubmit}
        disabled={submitting}
        className="mt-8 w-full py-3 rounded-sm bg-brass-500 text-navy-950 font-medium hover:bg-brass-400 transition-colors disabled:opacity-50"
      >
        {submitting ? 'Submitting...' : 'Submit test'}
      </button>
    </div>
  );
}

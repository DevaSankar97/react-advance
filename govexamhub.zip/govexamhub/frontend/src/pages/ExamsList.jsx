import React, { useEffect, useState } from 'react';
import { examsApi } from '../api/endpoints';
import ExamCard from '../components/ExamCard';

const CATEGORIES = ['ALL', 'TNPSC', 'RRB', 'IBPS', 'SSC'];

export default function ExamsList() {
  const [exams, setExams] = useState([]);
  const [category, setCategory] = useState('ALL');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    examsApi.list(category === 'ALL' ? undefined : category)
      .then(setExams)
      .catch(() => setExams([]))
      .finally(() => setLoading(false));
  }, [category]);

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <h1 className="font-display text-3xl text-paper mb-6">All exams</h1>
      <div className="flex gap-2 mb-8">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-3 py-1.5 rounded-sm font-mono text-xs uppercase tracking-wider border transition-colors ${
              category === c
                ? 'border-brass-500 bg-brass-500/15 text-brass-400'
                : 'border-navy-700 text-paper/60 hover:text-paper'
            }`}
          >
            {c}
          </button>
        ))}
      </div>
      {loading && <p className="text-paper/50 font-mono text-sm">Loading...</p>}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {exams.map((exam) => (
          <ExamCard key={exam._id} exam={exam} />
        ))}
      </div>
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { mockTestApi } from '../api/endpoints';

export default function MockTestResult() {
  const { attemptId } = useParams();
  const [attempt, setAttempt] = useState(null);

  useEffect(() => {
    mockTestApi.result(attemptId).then(setAttempt).catch(() => setAttempt(null));
  }, [attemptId]);

  if (!attempt) return <div className="max-w-3xl mx-auto px-6 py-12 text-paper/50 font-mono text-sm">Loading result...</div>;

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <h1 className="font-display text-3xl text-paper mb-1">{attempt.mockTest.title}</h1>
      <p className="text-paper/50 font-mono text-sm mb-8">Result summary</p>

      <div className="grid grid-cols-4 gap-3 mb-10">
        <Stat label="Score" value={`${attempt.totalMarksScored}/${attempt.mockTest.totalMarks}`} highlight />
        <Stat label="Correct" value={attempt.correctCount} color="text-ledger" />
        <Stat label="Wrong" value={attempt.wrongCount} color="text-red-400" />
        <Stat label="Skipped" value={attempt.unattemptedCount} color="text-paper/50" />
      </div>

      <div className="space-y-4">
        {attempt.answers.map((a, idx) => (
          <div key={idx} className="border border-navy-700 rounded-sm p-4">
            <p className="text-paper/90 mb-2">Q{idx + 1}. {a.question.questionText}</p>
            <ul className="text-sm space-y-1 mb-2">
              {a.question.options.map((opt, i) => {
                const isCorrectOpt = i === a.question.correctOptionIndex;
                const isSelected = i === a.selectedOptionIndex;
                return (
                  <li
                    key={i}
                    className={
                      isCorrectOpt ? 'text-ledger font-medium'
                      : isSelected ? 'text-red-400 line-through'
                      : 'text-paper/60'
                    }
                  >
                    {String.fromCharCode(65 + i)}. {opt} {isCorrectOpt && '✓'} {isSelected && !isCorrectOpt && '(your answer)'}
                  </li>
                );
              })}
            </ul>
            {a.question.explanation && (
              <p className="text-xs text-paper/50 border-t border-navy-800 pt-2">{a.question.explanation}</p>
            )}
          </div>
        ))}
      </div>

      <Link to="/exams" className="inline-block mt-8 text-brass-400 font-mono text-sm hover:underline">
        &larr; Back to exams
      </Link>
    </div>
  );
}

function Stat({ label, value, color = 'text-paper', highlight = false }) {
  return (
    <div className={`border rounded-sm p-4 text-center ${highlight ? 'border-brass-500 bg-brass-500/10' : 'border-navy-700'}`}>
      <p className={`font-mono text-2xl ${color}`}>{value}</p>
      <p className="text-xs text-paper/50 uppercase tracking-wide mt-1">{label}</p>
    </div>
  );
}

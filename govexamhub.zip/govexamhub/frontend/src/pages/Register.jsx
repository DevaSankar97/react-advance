import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authApi } from '../api/endpoints';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const data = await authApi.register({ name, email, password });
      localStorage.setItem('govexamhub_token', data.token);
      localStorage.setItem('govexamhub_user_id', data._id);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div className="max-w-sm mx-auto px-6 py-16">
      <h1 className="font-display text-2xl text-paper mb-6">Create an account</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text" required placeholder="Full name" value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full bg-navy-900 border border-navy-700 rounded-sm px-3 py-2 text-paper placeholder:text-paper/40 focus:border-brass-500 outline-none"
        />
        <input
          type="email" required placeholder="Email" value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-navy-900 border border-navy-700 rounded-sm px-3 py-2 text-paper placeholder:text-paper/40 focus:border-brass-500 outline-none"
        />
        <input
          type="password" required placeholder="Password" value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full bg-navy-900 border border-navy-700 rounded-sm px-3 py-2 text-paper placeholder:text-paper/40 focus:border-brass-500 outline-none"
        />
        {error && <p className="text-red-400 text-sm">{error}</p>}
        <button type="submit" className="w-full py-2.5 rounded-sm bg-brass-500 text-navy-950 font-medium hover:bg-brass-400 transition-colors">
          Create account
        </button>
      </form>
      <p className="text-sm text-paper/50 mt-4">
        Already have an account? <Link to="/login" className="text-brass-400 hover:underline">Sign in</Link>
      </p>
    </div>
  );
}

# GovExamHub

A study platform for government competitive exams in India (TNPSC, RRB, IBPS, SSC) —
syllabus breakdowns, previous year questions with solutions, timed mock tests, an
automated notification feed, and cutoff trend tracking.

**Stack:** Node.js + Express (backend) · MongoDB + Mongoose (database) · React + Vite + Tailwind (frontend)

```
govexamhub/
├── backend/         Express API, MongoDB models, scraper, seed data
├── frontend/         React app (Vite)
└── docker-compose.yml   Local MongoDB container (optional)
```

## 1. Prerequisites

- Node.js 18+ and npm
- MongoDB running locally, OR Docker (to use the included docker-compose.yml), OR a MongoDB Atlas connection string

## 2. Start MongoDB

Option A — Docker (easiest):
```bash
docker compose up -d
```

Option B — Atlas: create a free cluster at mongodb.com/atlas and copy the connection string.

## 3. Backend setup

```bash
cd backend
cp .env.example .env
# edit .env: set MONGO_URI (mongodb://localhost:27017/govexamhub for Docker option),
# and set JWT_SECRET to any long random string
npm install
npm run seed      # loads sample TNPSC Group 4 data (exam, syllabus, questions, mock test, cutoffs, notification)
npm run dev        # starts the API on http://localhost:5000
```

Health check: open http://localhost:5000/api/health — should return `{"status":"ok"}`.

The scraper scheduler (scraper/scheduler.js) starts automatically with the server and
runs the TNPSC notification scraper every 6 hours by default (configurable via
`SCRAPE_INTERVAL_CRON` in .env). You can also run it manually:
```bash
npm run scrape:tnpsc
```
**Before relying on the scraper in production**, open `scraper/tnpscScraper.js` and update
the CSS selectors to match the real TNPSC "What's New" page HTML — the ones shipped here
are placeholders since official sites change markup without notice and don't offer a
public API. Build `rrbScraper.js`, `ibpsScraper.js`, and `sscScraper.js` the same way for
the other boards, then register them in `scheduler.js`.

## 4. Frontend setup

In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173 — the Vite dev server proxies `/api` requests to the backend
on port 5000 (see `vite.config.js`), so no CORS setup is needed in development.

## 5. What's already working end-to-end

- Home page with live notification ticker + exam grid (seeded TNPSC Group 4 example)
- Exam detail page: syllabus (topic + weightage), notifications, previous year questions
  with solutions, mock test list, cutoff trend table
- Full mock-test flow: start test → timed question view → submit → scored result page
  with per-question explanations
- Auth: register/login with JWT, used to attribute mock test attempts to a user
- Auto-generate a randomized mock test from the verified question bank:
  `POST /api/exams/TNPSC_GROUP4/mocktests/generate` (admin token required)

## 6. Content pipeline — what's automated vs. what needs a human

| Content | How it flows into the app |
|---|---|
| Notifications | Scraper (`scraper/`) → dedup → `Notification` collection → ticker/feed. Runs on schedule. |
| Syllabus | Entered once via `POST /api/exams/:code/syllabus` (admin). Rarely changes; periodic manual re-check against official source is enough — full re-scraping isn't needed. |
| PYQs | Import the raw paper (scrape or manual), but **solutions must be reviewed** — see `isVerified` flag on the `Question` model. Nothing with `isVerified: false` is served to students. |
| Mock tests | Auto-generated (`generateMockTest` controller) by randomly sampling verified questions. Zero manual work once the question bank is built. |
| One-mark PDFs / short notes | `Resource` model — upload the file, set `isVerified` after a review pass. |
| Cutoff trends | Manual entry per year/post/category via `POST /api/exams/:code/cutoffs` — this is small, infrequent data, not worth automating. |

## 7. Extending to RRB / IBPS / SSC

Everything is modeled around `Exam.category` (`TNPSC` / `RRB` / `IBPS` / `SSC`), so adding
a new exam is just:
1. `POST /api/exams` with the new exam's details and `examPattern`
2. `POST /api/exams/:code/syllabus` per subject
3. Add questions, generate mock tests, add cutoff history
4. Copy `scraper/tnpscScraper.js` → `scraper/rrbScraper.js` (etc.), point it at the
   right official site, register it in `scheduler.js`

## 8. Production notes

- Set `NODE_ENV=production` and a strong `JWT_SECRET` before deploying
- Put the frontend build (`npm run build` → `frontend/dist`) behind a CDN/static host;
  point it at your deployed API URL (update the axios baseURL or use an env var)
- Consider rate-limiting the scraper requests and checking each target site's
  robots.txt / terms of use before scaling up scraping frequency

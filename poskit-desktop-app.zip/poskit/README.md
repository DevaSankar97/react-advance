# 🛒 POSKit — Complete Point of Sale System

## Features
- ✅ Fast POS billing with barcode scanner support
- ✅ Products & inventory management
- ✅ GST + Non-GST billing (toggle per bill)
- ✅ Customer management & credit tracking
- ✅ Expenses tracking
- ✅ Staff management + attendance
- ✅ Profit & Loss reports
- ✅ Thermal receipt printing
- ✅ Works offline (SQLite local database)
- ✅ Installable as desktop app (Windows .exe / Mac .dmg / Linux)
- ✅ PWA — installable from browser on any device

## Quick Start

### Development
```bash
npm install
npm run electron-dev    # Electron desktop app
npm start               # Browser only (PWA)
```

### Build Desktop App
```bash
npm run build-win       # Windows .exe installer
npm run build-mac       # Mac .dmg installer
npm run build-linux     # Linux AppImage
npm run build-all       # All platforms
```

### Build output
Installers saved to: `dist/` folder

## POS Keyboard Shortcuts
- `Barcode scan` → Auto-adds product to cart
- `Enter` in search → Select first product
- `Escape` → Clear search

## Database
- Local SQLite database (works offline)
- Location: `%APPDATA%/POSKit/poskit.db` (Windows)
- Location: `~/Library/Application Support/POSKit/poskit.db` (Mac)

## Pages
| Page | Description |
|------|-------------|
| POS Billing | Fast billing with cart, barcode, payment |
| Dashboard | Today stats, revenue chart, recent bills |
| Products | Add/edit products, stock management |
| Reports | Monthly P&L, top products, payment modes |
| Settings | Business info, GST, printer settings |

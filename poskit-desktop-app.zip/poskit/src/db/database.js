// ══════════════════════════════════════════════════════
//  POSKit Database Helper
//  Works in Electron (SQLite) and PWA (localStorage fallback)
// ══════════════════════════════════════════════════════

const isElectron = () => typeof window !== 'undefined' && window.electron?.isElectron;

// ── Electron SQLite wrapper ──
export const db = {
  async query(sql, params = []) {
    if (isElectron()) {
      const result = await window.electron.db.query(sql, params);
      if (!result.success) throw new Error(result.error);
      return result.data;
    }
    throw new Error('SQLite only available in Electron');
  },

  async run(sql, params = []) {
    if (isElectron()) {
      const result = await window.electron.db.query(sql, params);
      if (!result.success) throw new Error(result.error);
      return result.data;
    }
    throw new Error('SQLite only available in Electron');
  },

  async transaction(operations) {
    if (isElectron()) {
      const result = await window.electron.db.transaction(operations);
      if (!result.success) throw new Error(result.error);
      return result.data;
    }
    throw new Error('SQLite only available in Electron');
  },
};

// ── Settings helper ──
export const settings = {
  async get(key) {
    if (isElectron()) return window.electron.settings.get(key);
    const val = localStorage.getItem(`poskit_${key}`);
    return val ? JSON.parse(val) : null;
  },
  async set(key, value) {
    if (isElectron()) return window.electron.settings.set(key, value);
    localStorage.setItem(`poskit_${key}`, JSON.stringify(value));
  },
  async getAll() {
    if (isElectron()) return window.electron.settings.getAll();
    const obj = {};
    Object.keys(localStorage).filter(k=>k.startsWith('poskit_')).forEach(k => {
      try { obj[k.replace('poskit_','')] = JSON.parse(localStorage.getItem(k)); } catch {}
    });
    return obj;
  },
};

// ── Bill number generator ──
export async function getNextBillNumber() {
  const s = await settings.getAll();
  const prefix = s.bill_prefix || 'INV';
  const next   = (s.bill_next_number || 1);
  const num    = String(next).padStart(4, '0');
  await settings.set('bill_next_number', next + 1);
  return `${prefix}-${num}`;
}

// ── GST calculator ──
export function calcGST(amount, gstRate, isIntraState = true) {
  const gstAmount = Math.round((amount * gstRate) / 100 * 100) / 100;
  return {
    subTotal:  amount,
    gstAmount,
    cgst:      isIntraState ? Math.round(gstAmount / 2 * 100) / 100 : 0,
    sgst:      isIntraState ? Math.round(gstAmount / 2 * 100) / 100 : 0,
    igst:      !isIntraState ? gstAmount : 0,
    total:     Math.round((amount + gstAmount) * 100) / 100,
  };
}

// ── Print receipt ──
export async function printReceipt(html) {
  if (isElectron()) {
    return window.electron.print.receipt(html);
  }
  // Browser fallback
  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
  win.print();
  win.close();
}

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { db, getNextBillNumber, printReceipt } from '../../db/database';
import toast from 'react-hot-toast';

// ── Number to words ──
function numToWords(n) {
  const a=['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
  const b=['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
  if(n===0)return'Zero'; if(n<0)return'Minus '+numToWords(-n);
  if(n<20)return a[n]; if(n<100)return b[Math.floor(n/10)]+(n%10?' '+a[n%10]:'');
  if(n<1000)return a[Math.floor(n/100)]+' Hundred'+(n%100?' '+numToWords(n%100):'');
  if(n<100000)return numToWords(Math.floor(n/1000))+' Thousand'+(n%1000?' '+numToWords(n%1000):'');
  if(n<10000000)return numToWords(Math.floor(n/100000))+' Lakh'+(n%100000?' '+numToWords(n%100000):'');
  return numToWords(Math.floor(n/10000000))+' Crore'+(n%10000000?' '+numToWords(n%10000000):'');
}

export default function POS() {
  const { bizSettings, cartItems, addToCart, updateCartItem, removeFromCart, clearCart, cartTotals } = useApp();
  const barcodeRef = useRef(null);

  const [search, setSearch]         = useState('');
  const [products, setProducts]     = useState([]);
  const [filteredProds, setFiltered] = useState([]);
  const [customer, setCustomer]     = useState(null);
  const [customerSearch, setCustSearch] = useState('');
  const [customers, setCustomers]   = useState([]);
  const [discount, setDiscount]     = useState('');
  const [discountType, setDiscType] = useState('flat');
  const [isGstBill, setIsGst]       = useState(false);
  const [payMode, setPayMode]       = useState('cash');
  const [payRef, setPayRef]         = useState('');
  const [tenderedAmount, setTendered] = useState('');
  const [showPayModal, setPayModal] = useState(false);
  const [showSuccess, setSuccess]   = useState(false);
  const [lastBill, setLastBill]     = useState(null);
  const [barcodeBuffer, setBarcodeBuffer] = useState('');
  const [categories, setCategories] = useState(['All']);
  const [activeCat, setActiveCat]   = useState('All');

  const totals = cartTotals(parseFloat(discount)||0, discountType, isGstBill);

  // Load products
  const loadProducts = useCallback(async () => {
    try {
      const result = await db.query('SELECT * FROM products WHERE is_active = 1 ORDER BY name');
      setProducts(result);
      const cats = ['All', ...new Set(result.map(p => p.category))];
      setCategories(cats);
    } catch (err) { console.error(err); }
  }, []);

  useEffect(() => { loadProducts(); }, [loadProducts]);

  // Filter products
  useEffect(() => {
    let filtered = products;
    if (activeCat !== 'All') filtered = filtered.filter(p => p.category === activeCat);
    if (search) {
      const s = search.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(s) ||
        p.barcode?.includes(s) ||
        p.category?.toLowerCase().includes(s)
      );
    }
    setFiltered(filtered);
  }, [products, search, activeCat]);

  // Load customers
  const loadCustomers = useCallback(async (q = '') => {
    try {
      const result = await db.query(
        `SELECT * FROM customers WHERE is_active=1 AND (name LIKE ? OR phone LIKE ?) LIMIT 5`,
        [`%${q}%`, `%${q}%`]
      );
      setCustomers(result);
    } catch {}
  }, []);

  useEffect(() => { if (customerSearch) loadCustomers(customerSearch); }, [customerSearch, loadCustomers]);

  // ── Barcode scanner support ──
  useEffect(() => {
    let buffer = '';
    let timer;
    const handleKey = (e) => {
      if (e.key === 'Enter' && buffer.length > 2) {
        // Barcode scanned
        const product = products.find(p => p.barcode === buffer);
        if (product) {
          addToCart(product, 1);
          toast.success(`${product.name} added!`);
        } else {
          toast.error(`Barcode ${buffer} not found`);
        }
        buffer = '';
        clearTimeout(timer);
      } else if (e.key.length === 1) {
        buffer += e.key;
        clearTimeout(timer);
        timer = setTimeout(() => { buffer = ''; }, 200);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [products, addToCart]);

  // ── Complete bill ──
  const completeBill = async () => {
    if (!cartItems.length) { toast.error('Add items to cart!'); return; }
    try {
      const billNumber  = await getNextBillNumber();
      const paid        = parseFloat(tenderedAmount) || totals.finalTotal;
      const changeAmt   = paid - totals.finalTotal;

      // Save bill
      const billResult = await db.run(
        `INSERT INTO bills (bill_number, customer_id, customer_name, customer_phone,
          subtotal, discount, discount_type, gst_amount, cgst, sgst, igst,
          round_off, total, paid_amount, change_amount, payment_mode, payment_ref,
          is_gst_bill, status)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          billNumber,
          customer?.id || null,
          customer?.name || 'Walk-in Customer',
          customer?.phone || '',
          totals.subtotal, parseFloat(discount)||0, discountType,
          totals.gstAmount, totals.cgst, totals.sgst, 0,
          totals.roundOff, totals.finalTotal,
          paid, changeAmt > 0 ? changeAmt : 0,
          payMode, payRef, isGstBill ? 1 : 0, 'completed'
        ]
      );

      const billId = billResult.lastInsertRowid;

      // Save bill items + update stock
      for (const item of cartItems) {
        await db.run(
          `INSERT INTO bill_items (bill_id, product_id, product_name, barcode, hsn_code,
            quantity, unit, purchase_price, sell_price, gst_rate, discount, total)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          [billId, item.id, item.name, item.barcode||'', item.hsn_code||'',
           item.quantity, item.unit, item.purchase_price||0,
           item.sell_price, item.gst_rate||0, 0, item.total]
        );
        // Reduce stock
        await db.run(
          'UPDATE products SET stock = stock - ? WHERE id = ?',
          [item.quantity, item.id]
        );
      }

      // Update customer balance if credit
      if (customer && payMode === 'credit') {
        await db.run(
          'UPDATE customers SET balance = balance + ? WHERE id = ?',
          [totals.finalTotal, customer.id]
        );
      }

      // Save last bill for receipt
      setLastBill({
        billNumber, billId, customer,
        items: [...cartItems],
        totals, discount: parseFloat(discount)||0, discountType,
        payMode, payRef, paid, change: changeAmt > 0 ? changeAmt : 0,
        isGstBill, date: new Date()
      });

      clearCart();
      setCustomer(null); setCustSearch('');
      setDiscount(''); setPayMode('cash');
      setTendered(''); setPayRef('');
      setPayModal(false); setSuccess(true);

      loadProducts(); // refresh stock
    } catch (err) {
      toast.error('Bill failed: ' + err.message);
      console.error(err);
    }
  };

  const generateReceiptHTML = (bill) => {
    const s     = bizSettings;
    const width = s.thermal_width === 58 ? '220px' : s.thermal_width === 80 ? '302px' : '400px';
    const items = bill.items.map(i =>
      `<tr><td style="padding:2px 0">${i.name}</td><td style="text-align:right">${i.quantity} × ₹${i.sell_price}</td><td style="text-align:right;font-weight:bold">₹${i.total.toFixed(2)}</td></tr>`
    ).join('');
    return `<!DOCTYPE html>
<html><head><style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:monospace;font-size:12px;width:${width};padding:4px;}
.center{text-align:center;} .bold{font-weight:bold;} .line{border-top:1px dashed #000;margin:4px 0;}
table{width:100%;border-collapse:collapse;} th{text-align:left;border-bottom:1px solid #000;}
</style></head><body>
<div class="center bold" style="font-size:16px">${s.business_name}</div>
${s.business_address?`<div class="center">${s.business_address}</div>`:''}
${s.business_phone?`<div class="center">Ph: ${s.business_phone}</div>`:''}
${bill.isGstBill&&s.gstin?`<div class="center">GSTIN: ${s.gstin}</div>`:''}
<div class="line"></div>
<div class="bold">Invoice: ${bill.billNumber}</div>
<div>Date: ${bill.date.toLocaleDateString('en-IN')} ${bill.date.toLocaleTimeString('en-IN')}</div>
<div>Customer: ${bill.customer?.name||'Walk-in'}</div>
<div class="line"></div>
<table>
<tr><th>Item</th><th style="text-align:right">Qty×Rate</th><th style="text-align:right">Amt</th></tr>
${items}
</table>
<div class="line"></div>
<table>
<tr><td>Sub Total</td><td style="text-align:right">₹${bill.totals.subtotal.toFixed(2)}</td></tr>
${bill.discount>0?`<tr><td>Discount</td><td style="text-align:right">-₹${bill.totals.discount.toFixed(2)}</td></tr>`:''}
${bill.isGstBill&&bill.totals.gstAmount>0?`<tr><td>CGST+SGST</td><td style="text-align:right">₹${bill.totals.gstAmount.toFixed(2)}</td></tr>`:''}
${bill.totals.roundOff!==0?`<tr><td>Round Off</td><td style="text-align:right">₹${bill.totals.roundOff.toFixed(2)}</td></tr>`:''}
<tr class="bold"><td>TOTAL</td><td style="text-align:right">₹${bill.totals.finalTotal.toFixed(2)}</td></tr>
<tr><td>Paid (${bill.payMode})</td><td style="text-align:right">₹${bill.paid.toFixed(2)}</td></tr>
${bill.change>0?`<tr><td>Change</td><td style="text-align:right">₹${bill.change.toFixed(2)}</td></tr>`:''}
</table>
<div class="line"></div>
<div style="font-size:10px">In Words: ${numToWords(bill.totals.finalTotal)} Rupees Only</div>
<div class="line"></div>
<div class="center">${s.footer_text||'Thank you!'}</div>
</body></html>`;
  };

  const handlePrint = async () => {
    if (!lastBill) return;
    const html = generateReceiptHTML(lastBill);
    await printReceipt(html);
  };

  return (
    <div className="pos-layout">
      {/* LEFT — Product selection */}
      <div className="pos-left">
        {/* Search bar */}
        <div className="pos-search">
          <div className="input-group">
            <span className="input-group-text bg-white border-end-0">
              <i className="bi bi-search text-muted"></i>
            </span>
            <input className="form-control border-start-0 ps-0" ref={barcodeRef}
              placeholder="Search product or scan barcode..."
              value={search} onChange={e=>setSearch(e.target.value)} autoFocus/>
          </div>
        </div>

        {/* Category tabs */}
        <div className="pos-cats">
          {categories.map(cat => (
            <button key={cat} onClick={()=>setActiveCat(cat)}
              className={`pos-cat-btn ${activeCat===cat?'active':''}`}>
              {cat}
            </button>
          ))}
        </div>

        {/* Product grid */}
        <div className="pos-products">
          {filteredProds.map(p => {
            const isLow = p.stock <= (bizSettings.low_stock_alert||5);
            return (
              <div key={p.id} className={`pos-product-card ${p.stock<=0?'out-of-stock':''}`}
                onClick={() => { if(p.stock>0) addToCart(p,1); else toast.error(`${p.name} — Out of stock!`); }}>
                <div className="pos-product-name">{p.name}</div>
                <div className="pos-product-price">₹{p.sell_price}</div>
                <div className={`pos-product-stock ${isLow?'low':''}`}>
                  {p.stock<=0 ? '❌ Out of stock' : `Stock: ${p.stock} ${p.unit}`}
                </div>
              </div>
            );
          })}
          {!filteredProds.length && (
            <div className="pos-empty">
              <i className="bi bi-search fs-2 d-block mb-2"></i>
              No products found
            </div>
          )}
        </div>
      </div>

      {/* RIGHT — Cart + Payment */}
      <div className="pos-right">
        {/* Customer */}
        <div className="pos-customer">
          <div className="pos-section-title">
            <i className="bi bi-person me-2"></i>Customer
            {customer && (
              <button className="btn btn-sm btn-link text-danger ms-auto p-0" onClick={()=>{setCustomer(null);setCustSearch('');}}>
                <i className="bi bi-x-circle"></i>
              </button>
            )}
          </div>
          {customer ? (
            <div className="pos-customer-selected">
              <strong>{customer.name}</strong>
              {customer.phone && <span className="ms-2 text-muted small">{customer.phone}</span>}
              {customer.balance>0 && <span className="ms-2 text-danger small">Credit: ₹{customer.balance}</span>}
            </div>
          ) : (
            <div className="position-relative">
              <input className="form-control form-control-sm" placeholder="Search customer..."
                value={customerSearch} onChange={e=>{setCustSearch(e.target.value);loadCustomers(e.target.value);}}/>
              {customers.length > 0 && customerSearch && (
                <div className="pos-customer-dropdown">
                  {customers.map(c => (
                    <div key={c.id} className="pos-customer-item" onClick={()=>{setCustomer(c);setCustSearch('');setCustomers([]);}}>
                      <strong>{c.name}</strong> {c.phone&&<small className="text-muted ms-1">{c.phone}</small>}
                    </div>
                  ))}
                  <div className="pos-customer-item text-primary" onClick={()=>{setCustomer({name:'Walk-in Customer',phone:''});setCustSearch('');setCustomers([]); }}>
                    + Walk-in Customer
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Cart items */}
        <div className="pos-cart">
          {cartItems.length === 0 ? (
            <div className="pos-cart-empty">
              <i className="bi bi-cart3 fs-1 d-block mb-2"></i>
              <div>Cart is empty</div>
              <small className="text-muted">Search or scan a product</small>
            </div>
          ) : (
            cartItems.map(item => (
              <div key={item.id} className="pos-cart-item">
                <div className="pos-cart-item-name">
                  {item.name}
                  {item.gst_rate>0 && <span className="badge bg-light text-muted ms-1" style={{fontSize:'.65rem'}}>GST {item.gst_rate}%</span>}
                </div>
                <div className="pos-cart-item-controls">
                  <button className="pos-qty-btn" onClick={()=>updateCartItem(item.id, item.quantity-1)}>
                    <i className="bi bi-dash"></i>
                  </button>
                  <input className="pos-qty-input" type="number" value={item.quantity}
                    onChange={e=>updateCartItem(item.id, parseFloat(e.target.value)||0)}/>
                  <button className="pos-qty-btn" onClick={()=>updateCartItem(item.id, item.quantity+1)}>
                    <i className="bi bi-plus"></i>
                  </button>
                  <span className="pos-item-total">₹{item.total.toFixed(2)}</span>
                  <button className="pos-remove-btn" onClick={()=>removeFromCart(item.id)}>
                    <i className="bi bi-x"></i>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Discount + GST toggle */}
        <div className="pos-options">
          <div className="d-flex gap-2 align-items-center mb-2">
            <div className="input-group input-group-sm" style={{maxWidth:180}}>
              <span className="input-group-text">Discount</span>
              <input type="number" className="form-control" placeholder="0"
                value={discount} onChange={e=>setDiscount(e.target.value)}/>
              <button className="btn btn-outline-secondary" onClick={()=>setDiscType(t=>t==='flat'?'percent':'flat')}>
                {discountType==='flat'?'₹':'%'}
              </button>
            </div>
            <div className="form-check form-switch ms-2 mb-0">
              <input className="form-check-input" type="checkbox" id="gstToggle"
                checked={isGstBill} onChange={e=>setIsGst(e.target.checked)}
                disabled={!bizSettings.is_gst_registered}/>
              <label className="form-check-label small" htmlFor="gstToggle">GST Bill</label>
            </div>
          </div>
        </div>

        {/* Totals */}
        <div className="pos-totals">
          {totals.discount > 0 && (
            <div className="pos-total-row">
              <span>Sub Total</span><span>₹{totals.subtotal.toFixed(2)}</span>
            </div>
          )}
          {totals.discount > 0 && (
            <div className="pos-total-row text-success">
              <span>Discount</span><span>- ₹{totals.discount.toFixed(2)}</span>
            </div>
          )}
          {isGstBill && totals.gstAmount > 0 && (
            <>
              <div className="pos-total-row text-muted">
                <span>CGST + SGST</span><span>₹{totals.gstAmount.toFixed(2)}</span>
              </div>
            </>
          )}
          {totals.roundOff !== 0 && (
            <div className="pos-total-row text-muted">
              <span>Round Off</span><span>₹{totals.roundOff.toFixed(2)}</span>
            </div>
          )}
          <div className="pos-total-grand">
            <span>TOTAL</span><span>₹{totals.finalTotal.toFixed(2)}</span>
          </div>
        </div>

        {/* Payment mode */}
        <div className="pos-payment-modes">
          {['cash','upi','card','credit'].map(mode => (
            <button key={mode} onClick={()=>setPayMode(mode)}
              className={`pos-pay-btn ${payMode===mode?'active':''}`}>
              {mode==='cash'?'💵':mode==='upi'?'📱':mode==='card'?'💳':'🤝'} {mode.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Action buttons */}
        <div className="pos-actions">
          <button className="btn btn-outline-danger" onClick={clearCart} disabled={!cartItems.length}>
            <i className="bi bi-trash me-1"></i>Clear
          </button>
          <button className="pos-charge-btn" onClick={()=>setPayModal(true)} disabled={!cartItems.length}>
            <i className="bi bi-cash-stack me-2"></i>
            Charge ₹{totals.finalTotal.toFixed(2)}
          </button>
        </div>
      </div>

      {/* Payment Modal */}
      {showPayModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.6)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content" style={{borderRadius:16}}>
              <div className="modal-header border-0 pb-0">
                <h5 className="fw-bold">💰 Payment</h5>
                <button className="btn-close" onClick={()=>setPayModal(false)}/>
              </div>
              <div className="modal-body">
                <div className="text-center mb-3">
                  <div className="text-muted small">Amount to Collect</div>
                  <div className="pos-charge-amount">₹{totals.finalTotal.toFixed(2)}</div>
                </div>

                <div className="d-flex gap-2 mb-3 flex-wrap">
                  {['cash','upi','card','credit'].map(m=>(
                    <button key={m} onClick={()=>setPayMode(m)}
                      className={`btn btn-sm flex-fill fw-semibold ${payMode===m?'btn-primary':'btn-outline-secondary'}`}>
                      {m==='cash'?'💵':m==='upi'?'📱':m==='card'?'💳':'🤝'} {m}
                    </button>
                  ))}
                </div>

                {payMode==='cash' && (
                  <div className="mb-3">
                    <label className="form-label fw-semibold small">Tendered Amount (₹)</label>
                    <div className="input-group input-group-lg">
                      <span className="input-group-text fw-bold">₹</span>
                      <input type="number" className="form-control form-control-lg text-center fw-bold"
                        value={tenderedAmount} onChange={e=>setTendered(e.target.value)}
                        placeholder={totals.finalTotal} autoFocus/>
                    </div>
                    {parseFloat(tenderedAmount) > totals.finalTotal && (
                      <div className="text-center mt-2 p-2 rounded" style={{background:'#f0fdf4'}}>
                        <div className="text-muted small">Change</div>
                        <div className="fw-bold text-success fs-4">
                          ₹{(parseFloat(tenderedAmount)-totals.finalTotal).toFixed(2)}
                        </div>
                      </div>
                    )}
                    {/* Quick amount buttons */}
                    <div className="d-flex gap-2 mt-2 flex-wrap">
                      {[100,200,500,1000,2000].filter(v=>v>=totals.finalTotal).slice(0,4).map(v=>(
                        <button key={v} className="btn btn-sm btn-outline-secondary flex-fill"
                          onClick={()=>setTendered(v)}>₹{v}</button>
                      ))}
                      <button className="btn btn-sm btn-outline-primary flex-fill"
                        onClick={()=>setTendered(totals.finalTotal)}>Exact</button>
                    </div>
                  </div>
                )}

                {(payMode==='upi'||payMode==='card') && (
                  <div className="mb-3">
                    <label className="form-label fw-semibold small">Reference / Transaction ID</label>
                    <input className="form-control" placeholder="Enter reference number"
                      value={payRef} onChange={e=>setPayRef(e.target.value)}/>
                  </div>
                )}
              </div>
              <div className="modal-footer border-0">
                <button className="btn btn-secondary" onClick={()=>setPayModal(false)}>Cancel</button>
                <button className="btn btn-success fw-bold px-4 fs-6" onClick={completeBill}>
                  <i className="bi bi-check-circle me-2"></i>Complete Bill
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccess && lastBill && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.6)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content" style={{borderRadius:16}}>
              <div className="modal-body text-center p-4">
                <div style={{fontSize:'4rem',lineHeight:1}} className="mb-3">✅</div>
                <h4 className="fw-bold text-success mb-1">Bill Completed!</h4>
                <div className="text-muted mb-1">Invoice: <strong>{lastBill.billNumber}</strong></div>
                <div className="fs-4 fw-bold mb-1">₹{lastBill.totals.finalTotal.toFixed(2)}</div>
                {lastBill.change>0 && <div className="text-success mb-3">Change: ₹{lastBill.change.toFixed(2)}</div>}

                <div className="d-flex gap-2 justify-content-center">
                  <button className="btn btn-outline-secondary" onClick={handlePrint}>
                    <i className="bi bi-printer me-2"></i>Print Receipt
                  </button>
                  <button className="btn btn-primary" onClick={()=>setSuccess(false)}>
                    <i className="bi bi-plus-circle me-2"></i>New Bill
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useEffect, useCallback } from 'react';
import { db } from '../../db/database';
import toast from 'react-hot-toast';

const blank = { name:'', barcode:'', category:'General', unit:'piece', purchase_price:'', sell_price:'', mrp:'', gst_rate:'0', hsn_code:'', stock:'0', min_stock:'5' };

const GST_RATES = [0, 3, 5, 12, 18, 28];

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [modal, setModal]       = useState(false);
  const [stockModal, setStockModal] = useState(null);
  const [editId, setEditId]     = useState(null);
  const [form, setForm]         = useState(blank);
  const [search, setSearch]     = useState('');
  const [catFilter, setCat]     = useState('');
  const [categories, setCategories] = useState([]);
  const [stockQty, setStockQty] = useState('');
  const [stockType, setStockType] = useState('add');
  const f = (k,v) => setForm(p=>({...p,[k]:v}));

  const load = useCallback(async () => {
    setLoading(true);
    try {
      let sql = `SELECT * FROM products WHERE is_active=1`;
      const params = [];
      if (catFilter) { sql += ' AND category=?'; params.push(catFilter); }
      if (search)    { sql += ' AND (name LIKE ? OR barcode LIKE ?)'; params.push(`%${search}%`,`%${search}%`); }
      sql += ' ORDER BY category, name';
      const result = await db.query(sql, params);
      setProducts(result);
      const cats = [...new Set(result.map(p=>p.category))];
      setCategories(cats);
    } catch (err) { toast.error('Failed to load products'); }
    finally { setLoading(false); }
  }, [search, catFilter]);

  useEffect(() => { load(); }, [load]);

  const save = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await db.run(
          `UPDATE products SET name=?,barcode=?,category=?,unit=?,purchase_price=?,sell_price=?,mrp=?,gst_rate=?,hsn_code=?,min_stock=? WHERE id=?`,
          [form.name,form.barcode||null,form.category,form.unit,parseFloat(form.purchase_price)||0,
           parseFloat(form.sell_price),parseFloat(form.mrp)||0,parseFloat(form.gst_rate)||0,
           form.hsn_code,parseFloat(form.min_stock)||5, editId]
        );
        toast.success('Product updated!');
      } else {
        await db.run(
          `INSERT INTO products (name,barcode,category,unit,purchase_price,sell_price,mrp,gst_rate,hsn_code,stock,min_stock) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
          [form.name,form.barcode||null,form.category,form.unit,parseFloat(form.purchase_price)||0,
           parseFloat(form.sell_price),parseFloat(form.mrp)||0,parseFloat(form.gst_rate)||0,
           form.hsn_code,parseFloat(form.stock)||0,parseFloat(form.min_stock)||5]
        );
        toast.success('Product added!');
      }
      setModal(false); setForm(blank); setEditId(null); load();
    } catch (err) { toast.error(err.message.includes('UNIQUE')?'Barcode already exists!':'Failed to save'); }
  };

  const adjustStock = async () => {
    if (!stockQty) { toast.error('Enter quantity'); return; }
    const qty = parseFloat(stockQty);
    const newStock = stockType==='add' ? stockModal.stock+qty : Math.max(0, stockModal.stock-qty);
    try {
      await db.run('UPDATE products SET stock=? WHERE id=?', [newStock, stockModal.id]);
      await db.run(`INSERT INTO stock_adjustments (product_id,type,quantity,reason) VALUES (?,?,?,?)`,
        [stockModal.id, stockType, qty, `Manual ${stockType}`]);
      toast.success(`Stock ${stockType==='add'?'added':'reduced'}: ${qty}`);
      setStockModal(null); setStockQty(''); load();
    } catch { toast.error('Failed'); }
  };

  const del = async (id) => {
    if (!window.confirm('Delete product?')) return;
    try { await db.run('UPDATE products SET is_active=0 WHERE id=?', [id]); toast.success('Deleted'); load(); }
    catch { toast.error('Failed'); }
  };

  const lowStock = products.filter(p=>p.stock<=p.min_stock);
  const totalValue = products.reduce((s,p)=>s+(p.stock*p.purchase_price),0);

  return (
    <div className="p-4">
      <div className="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-2">
        <div>
          <h4 className="fw-bold mb-1"><i className="bi bi-grid-fill me-2 text-primary"></i>Products & Inventory</h4>
          <p className="text-muted small mb-0">{products.length} products • Stock value: ₹{totalValue.toLocaleString('en-IN')}</p>
        </div>
        <button className="btn btn-primary fw-semibold" onClick={()=>{setModal(true);setForm(blank);setEditId(null);}}>
          <i className="bi bi-plus-circle me-2"></i>Add Product
        </button>
      </div>

      {/* Low stock alert */}
      {lowStock.length > 0 && (
        <div className="alert alert-warning border-0 mb-4 d-flex gap-2" style={{borderLeft:'4px solid #f59e0b',borderRadius:10}}>
          <i className="bi bi-exclamation-triangle-fill text-warning fs-5"></i>
          <div><strong>⚠️ {lowStock.length} products</strong> running low: {lowStock.slice(0,3).map(p=>p.name).join(', ')}{lowStock.length>3?'...':''}</div>
        </div>
      )}

      {/* Filters */}
      <div className="d-flex gap-2 mb-3 flex-wrap">
        <div className="input-group" style={{maxWidth:260}}>
          <span className="input-group-text"><i className="bi bi-search text-muted"></i></span>
          <input className="form-control" placeholder="Search name, barcode..." value={search} onChange={e=>setSearch(e.target.value)}/>
        </div>
        <select className="form-select" style={{width:'auto'}} value={catFilter} onChange={e=>setCat(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map(c=><option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table align-middle mb-0">
              <thead style={{background:'#f8f9fa'}}>
                <tr>
                  <th className="text-muted small fw-semibold py-3 ps-3">PRODUCT</th>
                  <th className="text-muted small fw-semibold">BARCODE</th>
                  <th className="text-muted small fw-semibold">CATEGORY</th>
                  <th className="text-muted small fw-semibold">PRICE</th>
                  <th className="text-muted small fw-semibold">GST</th>
                  <th className="text-muted small fw-semibold">STOCK</th>
                  <th className="text-muted small fw-semibold">ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={7} className="text-center py-5"><div className="spinner-border text-primary"/></td></tr>
                ) : products.map(p => {
                  const isLow = p.stock <= p.min_stock;
                  const profit= p.sell_price - p.purchase_price;
                  const margin= p.purchase_price>0 ? Math.round(profit/p.purchase_price*100) : 0;
                  return (
                    <tr key={p.id}>
                      <td className="ps-3">
                        <div className="fw-semibold">{p.name}</div>
                        <small className="text-muted">{p.unit}</small>
                      </td>
                      <td><small className="text-muted font-monospace">{p.barcode||'—'}</small></td>
                      <td><span className="badge bg-light text-dark">{p.category}</span></td>
                      <td>
                        <div className="fw-bold">₹{p.sell_price}</div>
                        {p.purchase_price>0 && <small className="text-success">Margin: {margin}%</small>}
                      </td>
                      <td><span className="badge" style={{background:'#e0e7ff',color:'#6366f1'}}>{p.gst_rate}%</span></td>
                      <td>
                        <div className={`fw-bold ${isLow?'text-danger':''}`}>{p.stock} {p.unit}</div>
                        {isLow && <small className="text-danger">⚠️ Low</small>}
                      </td>
                      <td>
                        <div className="d-flex gap-1">
                          <button className="btn btn-sm btn-success" title="Adjust Stock" onClick={()=>{setStockModal(p);setStockQty('');setStockType('add');}}>
                            <i className="bi bi-box-seam"></i>
                          </button>
                          <button className="btn btn-sm btn-outline-primary" title="Edit" onClick={()=>{setForm({name:p.name,barcode:p.barcode||'',category:p.category,unit:p.unit,purchase_price:p.purchase_price,sell_price:p.sell_price,mrp:p.mrp||'',gst_rate:p.gst_rate,hsn_code:p.hsn_code||'',stock:p.stock,min_stock:p.min_stock});setEditId(p.id);setModal(true);}}>
                            <i className="bi bi-pencil"></i>
                          </button>
                          <button className="btn btn-sm btn-outline-danger" title="Delete" onClick={()=>del(p.id)}>
                            <i className="bi bi-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {!loading && !products.length && (
                  <tr><td colSpan={7} className="text-center py-5 text-muted">
                    <i className="bi bi-grid fs-1 d-block mb-2" style={{opacity:.3}}></i>
                    No products yet. Add your first product!
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {modal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div className="modal-content" style={{borderRadius:16}}>
              <div className="modal-header border-0">
                <h5 className="fw-bold">{editId?'✏️ Edit':'📦 Add'} Product</h5>
                <button className="btn-close" onClick={()=>setModal(false)}/>
              </div>
              <div className="modal-body">
                <form id="prodForm" onSubmit={save}>
                  <div className="row g-3">
                    <div className="col-md-8">
                      <label className="form-label fw-semibold small">Product Name *</label>
                      <input className="form-control" placeholder="e.g. Basmati Rice 1kg" value={form.name} onChange={e=>f('name',e.target.value)} required/>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">Barcode</label>
                      <input className="form-control" placeholder="Scan or type" value={form.barcode} onChange={e=>f('barcode',e.target.value)}/>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">Category</label>
                      <input className="form-control" placeholder="General" value={form.category} onChange={e=>f('category',e.target.value)} list="catList"/>
                      <datalist id="catList">{categories.map(c=><option key={c} value={c}/>)}</datalist>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">Unit</label>
                      <select className="form-select" value={form.unit} onChange={e=>f('unit',e.target.value)}>
                        {['piece','kg','g','litre','ml','box','packet','dozen','set','other'].map(u=><option key={u} value={u}>{u}</option>)}
                      </select>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">GST Rate (%)</label>
                      <select className="form-select" value={form.gst_rate} onChange={e=>f('gst_rate',e.target.value)}>
                        {GST_RATES.map(r=><option key={r} value={r}>{r}% GST</option>)}
                      </select>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">Purchase Price (₹)</label>
                      <div className="input-group"><span className="input-group-text">₹</span>
                        <input type="number" className="form-control" placeholder="0" value={form.purchase_price} onChange={e=>f('purchase_price',e.target.value)}/></div>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">Selling Price (₹) *</label>
                      <div className="input-group"><span className="input-group-text">₹</span>
                        <input type="number" className="form-control" placeholder="0" value={form.sell_price} onChange={e=>f('sell_price',e.target.value)} required/></div>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">MRP (₹)</label>
                      <div className="input-group"><span className="input-group-text">₹</span>
                        <input type="number" className="form-control" placeholder="0" value={form.mrp} onChange={e=>f('mrp',e.target.value)}/></div>
                    </div>
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">HSN Code</label>
                      <input className="form-control" placeholder="HSN code" value={form.hsn_code} onChange={e=>f('hsn_code',e.target.value)}/>
                    </div>
                    {!editId && (
                      <div className="col-md-4">
                        <label className="form-label fw-semibold small">Opening Stock</label>
                        <input type="number" className="form-control" placeholder="0" value={form.stock} onChange={e=>f('stock',e.target.value)}/>
                      </div>
                    )}
                    <div className="col-md-4">
                      <label className="form-label fw-semibold small">Min Stock Alert</label>
                      <input type="number" className="form-control" placeholder="5" value={form.min_stock} onChange={e=>f('min_stock',e.target.value)}/>
                    </div>
                    {form.sell_price && form.purchase_price && (
                      <div className="col-12">
                        <div className="p-3 rounded-3" style={{background:'#f0fdf4',border:'1px solid #86efac'}}>
                          <div className="row text-center">
                            <div className="col-4">
                              <div className="fw-bold text-success">₹{(parseFloat(form.sell_price)-parseFloat(form.purchase_price)).toFixed(2)}</div>
                              <small className="text-muted">Profit per unit</small>
                            </div>
                            <div className="col-4">
                              <div className="fw-bold text-primary">{parseFloat(form.purchase_price)>0?Math.round((parseFloat(form.sell_price)-parseFloat(form.purchase_price))/parseFloat(form.purchase_price)*100):0}%</div>
                              <small className="text-muted">Margin</small>
                            </div>
                            <div className="col-4">
                              <div className="fw-bold text-orange">{parseFloat(form.gst_rate)>0?`₹${(parseFloat(form.sell_price)*parseFloat(form.gst_rate)/100).toFixed(2)}`:'No GST'}</div>
                              <small className="text-muted">GST amount</small>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </form>
              </div>
              <div className="modal-footer border-0">
                <button className="btn btn-secondary" onClick={()=>setModal(false)}>Cancel</button>
                <button type="submit" form="prodForm" className="btn btn-primary fw-semibold">
                  <i className="bi bi-check-circle me-2"></i>{editId?'Update':'Add Product'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {stockModal && (
        <div className="modal show d-block" style={{background:'rgba(0,0,0,.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content" style={{borderRadius:16}}>
              <div className="modal-header border-0">
                <h5 className="fw-bold">📦 Stock — {stockModal.name}</h5>
                <button className="btn-close" onClick={()=>setStockModal(null)}/>
              </div>
              <div className="modal-body">
                <div className="text-center mb-3 p-3 rounded-3" style={{background:'#f0fdf4'}}>
                  <div className="text-muted small">Current Stock</div>
                  <div className="fw-bold fs-2" style={{color:'var(--ok-primary)'}}>{stockModal.stock} {stockModal.unit}</div>
                </div>
                <div className="d-flex gap-2 mb-3">
                  {[{v:'add',l:'📦 Add Stock'},{v:'reduce',l:'➖ Reduce Stock'}].map(t=>(
                    <button key={t.v} onClick={()=>setStockType(t.v)}
                      className={`btn flex-fill fw-semibold ${stockType===t.v?'btn-primary':'btn-outline-secondary'}`}>{t.l}</button>
                  ))}
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold small">Quantity to {stockType==='add'?'Add':'Reduce'} *</label>
                  <input type="number" className="form-control form-control-lg text-center fw-bold"
                    placeholder="Enter quantity" value={stockQty} onChange={e=>setStockQty(e.target.value)} autoFocus/>
                </div>
                {stockQty && (
                  <div className="text-center p-2 rounded-3" style={{background:'#e0e7ff'}}>
                    <small className="text-muted">New Stock After:</small>
                    <div className="fw-bold" style={{color:'#6366f1'}}>
                      {stockType==='add'
                        ? stockModal.stock + parseFloat(stockQty||0)
                        : Math.max(0, stockModal.stock - parseFloat(stockQty||0))} {stockModal.unit}
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer border-0">
                <button className="btn btn-secondary" onClick={()=>setStockModal(null)}>Cancel</button>
                <button className="btn btn-primary fw-semibold" onClick={adjustStock}>
                  <i className="bi bi-check-circle me-2"></i>Update Stock
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

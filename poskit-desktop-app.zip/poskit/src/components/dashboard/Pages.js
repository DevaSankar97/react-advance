// ── DASHBOARD ──
import React, { useState, useEffect, useCallback } from 'react';
import { db } from '../../db/database';
import { useApp } from '../../context/AppContext';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line } from 'recharts';

export function Dashboard() {
  const { bizSettings } = useApp();
  const [stats, setStats]   = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const today   = new Date().toISOString().split('T')[0];
      const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0];

      const [todayBills, monthBills, totalProducts, lowStock, recentBills, topProducts] = await Promise.all([
        db.query(`SELECT COUNT(*) as cnt, SUM(total) as rev FROM bills WHERE date(created_at)=? AND status='completed'`, [today]),
        db.query(`SELECT COUNT(*) as cnt, SUM(total) as rev, SUM(gst_amount) as gst FROM bills WHERE date(created_at)>=? AND status='completed'`, [monthStart]),
        db.query(`SELECT COUNT(*) as cnt FROM products WHERE is_active=1`),
        db.query(`SELECT COUNT(*) as cnt FROM products WHERE is_active=1 AND stock<=min_stock`),
        db.query(`SELECT b.*, c.name as cust_name FROM bills b LEFT JOIN customers c ON b.customer_id=c.id ORDER BY b.created_at DESC LIMIT 8`),
        db.query(`SELECT bi.product_name, SUM(bi.quantity) as qty, SUM(bi.total) as rev FROM bill_items bi JOIN bills b ON bi.bill_id=b.id WHERE date(b.created_at)>=? GROUP BY bi.product_id ORDER BY rev DESC LIMIT 5`, [monthStart]),
      ]);

      // 7-day trend
      const trend = [];
      for (let i=6; i>=0; i--) {
        const d = new Date(); d.setDate(d.getDate()-i);
        const ds = d.toISOString().split('T')[0];
        const r = await db.query(`SELECT COUNT(*) as cnt, COALESCE(SUM(total),0) as rev FROM bills WHERE date(created_at)=? AND status='completed'`, [ds]);
        trend.push({ day:d.toLocaleDateString('en-IN',{weekday:'short'}), bills:r[0].cnt, revenue:r[0].rev });
      }

      setStats({
        todayBills: todayBills[0], monthBills: monthBills[0],
        totalProducts: totalProducts[0].cnt,
        lowStock: lowStock[0].cnt,
        recentBills, topProducts, trend
      });
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  if (loading) return <div className="pos-loading"><div className="spinner-border text-primary"/></div>;
  const s = stats;

  return (
    <div className="p-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 className="fw-bold mb-1">📊 Dashboard</h4>
          <p className="text-muted small mb-0">{new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</p>
        </div>
        <button className="btn btn-sm btn-outline-secondary" onClick={load}><i className="bi bi-arrow-clockwise me-1"></i>Refresh</button>
      </div>

      {/* Stats */}
      <div className="row g-3 mb-4">
        {[
          {icon:'🛒', label:"Today's Sales",   value:`₹${(s.todayBills.rev||0).toLocaleString('en-IN')}`,   sub:`${s.todayBills.cnt} bills`,         color:'#25D366', bg:'#dcfce7'},
          {icon:'📅', label:'Month Revenue',   value:`₹${(s.monthBills.rev||0).toLocaleString('en-IN')}`,  sub:`${s.monthBills.cnt} bills`,          color:'#6366f1', bg:'#e0e7ff'},
          {icon:'🧾', label:'Month GST',       value:`₹${(s.monthBills.gst||0).toLocaleString('en-IN')}`,  sub:'Tax collected',                       color:'#f59e0b', bg:'#fef9c3'},
          {icon:'⚠️', label:'Low Stock',       value:s.lowStock,                                            sub:`of ${s.totalProducts} products`,     color:'#ef4444', bg:'#fee2e2'},
        ].map(st=>(
          <div key={st.label} className="col-6 col-md-3">
            <div className="card border-0 shadow-sm h-100" style={{borderRadius:12,borderTop:`3px solid ${st.color}`}}>
              <div className="card-body d-flex align-items-center gap-3 py-3">
                <div className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                  style={{width:46,height:46,background:st.bg,fontSize:'1.2rem'}}>{st.icon}</div>
                <div>
                  <div className="fw-bold" style={{color:st.color,fontSize:'1.1rem'}}>{st.value}</div>
                  <div className="text-muted" style={{fontSize:'.75rem'}}>{st.label}</div>
                  <div style={{fontSize:'.68rem',color:'#aaa'}}>{st.sub}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-3">
        {/* Revenue chart */}
        <div className="col-12 col-lg-7">
          <div className="card border-0 shadow-sm h-100" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-bar-chart me-2 text-primary"></i>Last 7 Days Revenue</h6>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={s.trend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="day" tick={{fontSize:11}}/>
                  <YAxis tick={{fontSize:11}} tickFormatter={v=>`₹${v}`}/>
                  <Tooltip formatter={v=>[`₹${v}`,'']}/>
                  <Bar dataKey="revenue" name="Revenue" fill="#6366f1" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Top products */}
        <div className="col-12 col-lg-5">
          <div className="card border-0 shadow-sm h-100" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-trophy me-2 text-warning"></i>Top Products This Month</h6>
              {s.topProducts.map((p,i)=>(
                <div key={i} className="d-flex justify-content-between align-items-center py-2 border-bottom">
                  <div className="d-flex align-items-center gap-2">
                    <span className="badge rounded-pill" style={{background:'#e0e7ff',color:'#6366f1',minWidth:24}}>{i+1}</span>
                    <div style={{fontSize:'.88rem'}}>{p.product_name}</div>
                  </div>
                  <div className="text-end">
                    <div className="fw-bold" style={{fontSize:'.88rem',color:'#6366f1'}}>₹{p.rev.toFixed(0)}</div>
                    <small className="text-muted">{p.qty} sold</small>
                  </div>
                </div>
              ))}
              {!s.topProducts.length && <div className="text-muted text-center py-3 small">No sales this month</div>}
            </div>
          </div>
        </div>

        {/* Recent bills */}
        <div className="col-12">
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3"><i className="bi bi-receipt me-2 text-primary"></i>Recent Bills</h6>
              <div className="table-responsive">
                <table className="table align-middle mb-0" style={{fontSize:'.88rem'}}>
                  <thead style={{background:'#f8f9fa'}}><tr>
                    <th className="fw-semibold text-muted small py-2 ps-3">BILL #</th>
                    <th className="fw-semibold text-muted small">CUSTOMER</th>
                    <th className="fw-semibold text-muted small">AMOUNT</th>
                    <th className="fw-semibold text-muted small">PAYMENT</th>
                    <th className="fw-semibold text-muted small">TIME</th>
                  </tr></thead>
                  <tbody>
                    {s.recentBills.map(b=>(
                      <tr key={b.id}>
                        <td className="ps-3 fw-bold text-primary">{b.bill_number}</td>
                        <td>{b.customer_name||'Walk-in'}</td>
                        <td className="fw-bold">₹{b.total.toFixed(2)}</td>
                        <td><span className="badge bg-light text-dark">{b.payment_mode}</span></td>
                        <td className="text-muted"><small>{new Date(b.created_at).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}</small></td>
                      </tr>
                    ))}
                    {!s.recentBills.length && <tr><td colSpan={5} className="text-center text-muted py-3">No bills today</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── REPORTS ──
export function Reports() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth()+1);
  const [year, setYear]   = useState(now.getFullYear());
  const [data, setData]   = useState(null);
  const [loading, setLoading] = useState(true);
  const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const start = `${year}-${String(month).padStart(2,'0')}-01`;
      const end   = month===12 ? `${year+1}-01-01` : `${year}-${String(month+1).padStart(2,'0')}-01`;

      const [summary, byPayment, topProds, expenses, daily] = await Promise.all([
        db.query(`SELECT COUNT(*) as bills, COALESCE(SUM(total),0) as revenue, COALESCE(SUM(gst_amount),0) as gst, COALESCE(SUM(discount),0) as discount FROM bills WHERE created_at>=? AND created_at<? AND status='completed'`, [start,end]),
        db.query(`SELECT payment_mode, COUNT(*) as cnt, SUM(total) as total FROM bills WHERE created_at>=? AND created_at<? AND status='completed' GROUP BY payment_mode`, [start,end]),
        db.query(`SELECT bi.product_name, SUM(bi.quantity) as qty, SUM(bi.total) as rev, SUM(bi.quantity*(bi.sell_price-bi.purchase_price)) as profit FROM bill_items bi JOIN bills b ON bi.bill_id=b.id WHERE b.created_at>=? AND b.created_at<? AND b.status='completed' GROUP BY bi.product_id ORDER BY rev DESC LIMIT 10`, [start,end]),
        db.query(`SELECT category, SUM(amount) as total FROM expenses WHERE date>=? AND date<? GROUP BY category`, [start,end]),
        db.query(`SELECT date(created_at) as day, COUNT(*) as bills, SUM(total) as revenue FROM bills WHERE created_at>=? AND created_at<? AND status='completed' GROUP BY date(created_at) ORDER BY day`, [start,end]),
      ]);

      const totalExpenses = expenses.reduce((s,e)=>s+e.total,0);
      const revenue       = summary[0].revenue;
      const netProfit     = revenue - totalExpenses;

      setData({ summary:summary[0], byPayment, topProds, expenses, daily, totalExpenses, netProfit });
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, [month, year]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <div className="pos-loading"><div className="spinner-border text-primary"/></div>;

  return (
    <div className="p-4">
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div><h4 className="fw-bold mb-1"><i className="bi bi-graph-up me-2 text-primary"></i>Reports</h4></div>
        <div className="d-flex gap-2">
          <select className="form-select form-select-sm" style={{width:'auto'}} value={month} onChange={e=>setMonth(parseInt(e.target.value))}>
            {MONTHS.map((m,i)=><option key={m} value={i+1}>{m}</option>)}
          </select>
          <select className="form-select form-select-sm" style={{width:'auto'}} value={year} onChange={e=>setYear(parseInt(e.target.value))}>
            {[2024,2025,2026,2027].map(y=><option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </div>

      {/* Summary */}
      <div className="row g-3 mb-4">
        {[
          {icon:'💰',label:'Revenue',      value:`₹${(data.summary.revenue||0).toLocaleString('en-IN')}`,    color:'#6366f1',bg:'#e0e7ff'},
          {icon:'🧾',label:'GST Collected',value:`₹${(data.summary.gst||0).toLocaleString('en-IN')}`,       color:'#f59e0b',bg:'#fef9c3'},
          {icon:'💸',label:'Expenses',     value:`₹${data.totalExpenses.toLocaleString('en-IN')}`,           color:'#ef4444',bg:'#fee2e2'},
          {icon:'💚',label:'Net Profit',   value:`₹${data.netProfit.toLocaleString('en-IN')}`,               color:'#22c55e',bg:'#dcfce7'},
        ].map(s=>(
          <div key={s.label} className="col-6 col-md-3">
            <div className="card border-0 shadow-sm" style={{borderRadius:12,borderTop:`3px solid ${s.color}`}}>
              <div className="card-body py-3 d-flex align-items-center gap-3">
                <div className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
                  style={{width:44,height:44,background:s.bg,fontSize:'1.1rem'}}>{s.icon}</div>
                <div>
                  <div className="fw-bold" style={{color:s.color,fontSize:'1.1rem'}}>{s.value}</div>
                  <div className="text-muted" style={{fontSize:'.72rem'}}>{s.label}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-3">
        {/* Daily chart */}
        <div className="col-12 col-lg-8">
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">Daily Revenue</h6>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={data.daily}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="day" tick={{fontSize:10}} tickFormatter={v=>v.split('-')[2]}/>
                  <YAxis tick={{fontSize:10}} tickFormatter={v=>`₹${v}`}/>
                  <Tooltip formatter={v=>[`₹${v}`,'']}/>
                  <Line type="monotone" dataKey="revenue" name="Revenue" stroke="#6366f1" strokeWidth={2} dot={{r:3}}/>
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Payment breakdown */}
        <div className="col-12 col-lg-4">
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">Payment Modes</h6>
              {data.byPayment.map(p=>(
                <div key={p.payment_mode} className="d-flex justify-content-between py-2 border-bottom align-items-center">
                  <span>{p.payment_mode==='cash'?'💵':p.payment_mode==='upi'?'📱':p.payment_mode==='card'?'💳':'🤝'} {p.payment_mode}</span>
                  <div className="text-end">
                    <div className="fw-bold">₹{p.total.toFixed(0)}</div>
                    <small className="text-muted">{p.cnt} bills</small>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top products */}
        <div className="col-12">
          <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
            <div className="card-body">
              <h6 className="fw-bold mb-3">Top Products</h6>
              <div className="table-responsive">
                <table className="table align-middle mb-0" style={{fontSize:'.88rem'}}>
                  <thead style={{background:'#f8f9fa'}}><tr>
                    <th className="fw-semibold text-muted small">RANK</th>
                    <th className="fw-semibold text-muted small">PRODUCT</th>
                    <th className="fw-semibold text-muted small">QTY SOLD</th>
                    <th className="fw-semibold text-muted small">REVENUE</th>
                    <th className="fw-semibold text-muted small">PROFIT</th>
                  </tr></thead>
                  <tbody>
                    {data.topProds.map((p,i)=>(
                      <tr key={i}>
                        <td>{i===0?'🥇':i===1?'🥈':i===2?'🥉':`#${i+1}`}</td>
                        <td className="fw-semibold">{p.product_name}</td>
                        <td>{p.qty}</td>
                        <td className="fw-bold text-primary">₹{p.rev.toFixed(0)}</td>
                        <td className="text-success">₹{(p.profit||0).toFixed(0)}</td>
                      </tr>
                    ))}
                    {!data.topProds.length && <tr><td colSpan={5} className="text-center text-muted py-3">No sales data</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── SETTINGS ──
export function Settings() {
  const { bizSettings, updateSettingsBulk } = useApp();
  const [form, setForm] = useState({...bizSettings});
  const [saving, setSaving] = useState(false);
  const f = (k,v) => setForm(p=>({...p,[k]:v}));

  useEffect(() => { setForm({...bizSettings}); }, [bizSettings]);

  const save = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      await updateSettingsBulk(form);
      const toast = (await import('react-hot-toast')).default;
      toast.success('Settings saved!');
    } catch { }
    finally { setSaving(false); }
  };

  return (
    <div className="p-4">
      <div className="mb-4"><h4 className="fw-bold mb-1"><i className="bi bi-gear-fill me-2 text-primary"></i>Settings</h4></div>
      <form onSubmit={save}>
        <div className="row g-4">
          {/* Business info */}
          <div className="col-12 col-lg-6">
            <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
              <div className="card-header bg-white border-bottom py-3">
                <h6 className="fw-bold mb-0"><i className="bi bi-shop me-2 text-primary"></i>Business Details</h6>
              </div>
              <div className="card-body">
                <div className="mb-3"><label className="form-label fw-semibold small">Business Name *</label>
                  <input className="form-control" value={form.business_name||''} onChange={e=>f('business_name',e.target.value)} required/></div>
                <div className="mb-3"><label className="form-label fw-semibold small">Phone</label>
                  <input className="form-control" value={form.business_phone||''} onChange={e=>f('business_phone',e.target.value)}/></div>
                <div className="mb-3"><label className="form-label fw-semibold small">Email</label>
                  <input type="email" className="form-control" value={form.business_email||''} onChange={e=>f('business_email',e.target.value)}/></div>
                <div className="mb-3"><label className="form-label fw-semibold small">Address</label>
                  <textarea className="form-control" rows={2} value={form.business_address||''} onChange={e=>f('business_address',e.target.value)}/></div>
                <div className="mb-3"><label className="form-label fw-semibold small">Receipt Footer</label>
                  <input className="form-control" value={form.footer_text||''} onChange={e=>f('footer_text',e.target.value)}/></div>
              </div>
            </div>
          </div>

          {/* GST settings */}
          <div className="col-12 col-lg-6">
            <div className="card border-0 shadow-sm mb-4" style={{borderRadius:12}}>
              <div className="card-header bg-white border-bottom py-3">
                <h6 className="fw-bold mb-0"><i className="bi bi-receipt me-2 text-primary"></i>GST & Invoice</h6>
              </div>
              <div className="card-body">
                <div className="form-check form-switch mb-3">
                  <input className="form-check-input" type="checkbox" id="gstReg"
                    checked={!!form.is_gst_registered} onChange={e=>f('is_gst_registered',e.target.checked)}/>
                  <label className="form-check-label fw-semibold" htmlFor="gstReg">GST Registered Business</label>
                </div>
                {form.is_gst_registered && (
                  <>
                    <div className="mb-3"><label className="form-label fw-semibold small">GSTIN</label>
                      <input className="form-control text-uppercase" placeholder="22AAAAA0000A1Z5" value={form.gstin||''} onChange={e=>f('gstin',e.target.value.toUpperCase())}/></div>
                    <div className="mb-3"><label className="form-label fw-semibold small">State Code</label>
                      <input className="form-control" placeholder="33 (Tamil Nadu)" value={form.state_code||''} onChange={e=>f('state_code',e.target.value)}/></div>
                    <div className="mb-3"><label className="form-label fw-semibold small">Default GST Rate (%)</label>
                      <select className="form-select" value={form.default_gst_rate||18} onChange={e=>f('default_gst_rate',parseInt(e.target.value))}>
                        {[0,3,5,12,18,28].map(r=><option key={r} value={r}>{r}%</option>)}
                      </select></div>
                  </>
                )}
                <div className="row g-2">
                  <div className="col-md-6"><label className="form-label fw-semibold small">Invoice Prefix</label>
                    <input className="form-control" placeholder="INV" value={form.bill_prefix||'INV'} onChange={e=>f('bill_prefix',e.target.value)}/></div>
                  <div className="col-md-6"><label className="form-label fw-semibold small">Starting Number</label>
                    <input type="number" className="form-control" value={form.bill_next_number||1} onChange={e=>f('bill_next_number',parseInt(e.target.value))}/></div>
                </div>
              </div>
            </div>

            {/* POS settings */}
            <div className="card border-0 shadow-sm" style={{borderRadius:12}}>
              <div className="card-header bg-white border-bottom py-3">
                <h6 className="fw-bold mb-0"><i className="bi bi-printer me-2 text-primary"></i>POS & Printer</h6>
              </div>
              <div className="card-body">
                <div className="mb-3"><label className="form-label fw-semibold small">Thermal Printer Width</label>
                  <select className="form-select" value={form.thermal_width||80} onChange={e=>f('thermal_width',parseInt(e.target.value))}>
                    <option value={58}>58mm (Small)</option>
                    <option value={80}>80mm (Standard)</option>
                    <option value={112}>112mm (Wide)</option>
                  </select></div>
                <div className="mb-3"><label className="form-label fw-semibold small">Low Stock Alert Below</label>
                  <input type="number" className="form-control" value={form.low_stock_alert||5} onChange={e=>f('low_stock_alert',parseInt(e.target.value))}/></div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <button type="submit" className="btn btn-primary btn-lg fw-semibold px-5" disabled={saving}>
            {saving?<><span className="spinner-border spinner-border-sm me-2"/>Saving...</>:<><i className="bi bi-check-circle me-2"/>Save Settings</>}
          </button>
        </div>
      </form>
    </div>
  );
}

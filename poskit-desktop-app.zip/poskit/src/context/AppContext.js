import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { settings } from '../db/database';

const AppContext = createContext();
export const useApp = () => useContext(AppContext);

const DEFAULT_SETTINGS = {
  business_name:   'My Shop',
  business_phone:  '',
  business_address:'',
  business_email:  '',
  gstin:           '',
  is_gst_registered: false,
  default_gst_rate: 18,
  state_code:      '33',  // Tamil Nadu
  currency:        '₹',
  bill_prefix:     'INV',
  bill_next_number: 1,
  thermal_width:   80,    // mm
  show_mrp:        true,
  footer_text:     'Thank you for shopping with us!',
  payment_modes:   ['cash','upi','card','credit'],
  low_stock_alert: 5,
};

export const AppProvider = ({ children }) => {
  const [bizSettings, setBizSettings] = useState(DEFAULT_SETTINGS);
  const [loading, setLoading]         = useState(true);
  const [currentStaff, setCurrentStaff] = useState(null);
  const [cartItems, setCartItems]     = useState([]);
  const [notification, setNotification] = useState(null);

  // Load settings on mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const all = await settings.getAll();
        setBizSettings(prev => ({ ...prev, ...all }));
      } catch (err) {
        console.error('Settings load error:', err);
      } finally {
        setLoading(false);
      }
    };
    loadSettings();
  }, []);

  const updateSettings = useCallback(async (key, value) => {
    await settings.set(key, value);
    setBizSettings(prev => ({ ...prev, [key]: value }));
  }, []);

  const updateSettingsBulk = useCallback(async (updates) => {
    for (const [key, value] of Object.entries(updates)) {
      await settings.set(key, value);
    }
    setBizSettings(prev => ({ ...prev, ...updates }));
  }, []);

  // Cart management
  const addToCart = useCallback((product, quantity = 1) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.id === product.id);
      if (existing) {
        return prev.map(i => i.id === product.id
          ? { ...i, quantity: i.quantity + quantity, total: (i.quantity + quantity) * i.sell_price }
          : i
        );
      }
      return [...prev, { ...product, quantity, total: quantity * product.sell_price }];
    });
  }, []);

  const updateCartItem = useCallback((id, quantity) => {
    if (quantity <= 0) {
      setCartItems(prev => prev.filter(i => i.id !== id));
    } else {
      setCartItems(prev => prev.map(i => i.id === id
        ? { ...i, quantity, total: quantity * i.sell_price }
        : i
      ));
    }
  }, []);

  const removeFromCart = useCallback((id) => {
    setCartItems(prev => prev.filter(i => i.id !== id));
  }, []);

  const clearCart = useCallback(() => setCartItems([]), []);

  // Cart totals
  const cartTotals = useCallback((discountVal = 0, discountType = 'flat', isGstBill = false) => {
    const subtotal  = cartItems.reduce((s, i) => s + i.total, 0);
    const discount  = discountType === 'percent' ? (subtotal * discountVal / 100) : discountVal;
    const afterDisc = subtotal - discount;
    let gstAmount = 0;
    if (isGstBill && bizSettings.is_gst_registered) {
      gstAmount = cartItems.reduce((s, i) => {
        const base = (i.total - (discount * (i.total / subtotal)));
        return s + (base * (i.gst_rate || 0) / 100);
      }, 0);
    }
    const total     = afterDisc + gstAmount;
    const roundOff  = Math.round(total) - total;
    return {
      subtotal: Math.round(subtotal * 100) / 100,
      discount: Math.round(discount * 100) / 100,
      gstAmount: Math.round(gstAmount * 100) / 100,
      cgst: Math.round(gstAmount / 2 * 100) / 100,
      sgst: Math.round(gstAmount / 2 * 100) / 100,
      total: Math.round(total * 100) / 100,
      roundOff: Math.round(roundOff * 100) / 100,
      finalTotal: Math.round(total),
    };
  }, [cartItems, bizSettings]);

  // Show notification
  const notify = useCallback((msg, type = 'success') => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  }, []);

  return (
    <AppContext.Provider value={{
      bizSettings, loading, currentStaff, setCurrentStaff,
      cartItems, addToCart, updateCartItem, removeFromCart, clearCart, cartTotals,
      updateSettings, updateSettingsBulk, notification, notify,
    }}>
      {children}
    </AppContext.Provider>
  );
};

import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AppProvider } from './context/AppContext';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './index.css';

import POS       from './components/pos/POS';
import Products  from './components/products/Products';
import { Dashboard, Reports, Settings } from './components/dashboard/Pages';

// ── Nav items ──
const NAV = [
  { path:'/',         icon:'bi-cash-register',  label:'POS Billing'  },
  { path:'/dashboard',icon:'bi-speedometer2',   label:'Dashboard'    },
  { path:'/products', icon:'bi-grid-fill',       label:'Products'     },
  { path:'/reports',  icon:'bi-graph-up',        label:'Reports'      },
  { path:'/settings', icon:'bi-gear-fill',       label:'Settings'     },
];

// ── Layout wrapper ──
function AppLayout() {
  const navigate  = useNavigate();
  const location  = useLocation();
  const isElectron= typeof window !== 'undefined' && window.electron?.isElectron;

  return (
    <div className="pos-app">
      {/* Electron title bar */}
      {isElectron && (
        <div className="electron-titlebar">
          <span className="title">🛒 POSKit</span>
          <div className="window-controls">
            <button className="wc-btn wc-close" onClick={()=>window.electron?.app?.quit?.()}/>
            <button className="wc-btn wc-min"/>
            <button className="wc-btn wc-max"/>
          </div>
        </div>
      )}

      <div className="pos-body">
        {/* Sidebar */}
        <div className="pos-sidebar">
          <div className="pos-sidebar-logo">
            <div className="name">🛒 POSKit</div>
            <div className="sub">Point of Sale System</div>
          </div>
          <nav className="pos-nav">
            {NAV.map(item => (
              <button key={item.path} className={`pos-nav-item ${location.pathname===item.path?'active':''}`}
                onClick={()=>navigate(item.path)}>
                <i className={`bi ${item.icon}`}></i>
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Bottom info */}
          <div style={{padding:'12px',borderTop:'1px solid rgba(255,255,255,.1)'}}>
            <div style={{fontSize:'.68rem',color:'rgba(255,255,255,.4)',textAlign:'center'}}>
              POSKit v1.0.0
            </div>
          </div>
        </div>

        {/* Main */}
        <div className="pos-main">
          {/* Topbar — only show outside POS */}
          {location.pathname !== '/' && (
            <div className="pos-topbar">
              <i className={`bi ${NAV.find(n=>n.path===location.pathname)?.icon||'bi-circle'} text-primary fs-5`}></i>
              <span className="fw-semibold">{NAV.find(n=>n.path===location.pathname)?.label}</span>
              <div className="ms-auto d-flex align-items-center gap-2">
                <small className="text-muted">{new Date().toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short'})}</small>
              </div>
            </div>
          )}

          <div className="pos-content fade-in">
            <Routes>
              <Route path="/"          element={<POS/>}/>
              <Route path="/dashboard" element={<Dashboard/>}/>
              <Route path="/products"  element={<Products/>}/>
              <Route path="/reports"   element={<Reports/>}/>
              <Route path="/settings"  element={<Settings/>}/>
            </Routes>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Toaster position="top-right" toastOptions={{
          success:{ style:{ background:'#22c55e', color:'#fff' } },
          error:  { style:{ background:'#ef4444', color:'#fff' } },
          duration: 2000
        }}/>
        <AppLayout/>
      </BrowserRouter>
    </AppProvider>
  );
}

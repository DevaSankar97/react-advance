const { contextBridge, ipcRenderer } = require('electron');

// Expose safe APIs to renderer process
contextBridge.exposeInMainWorld('electron', {
  // Database
  db: {
    query:       (sql, params)   => ipcRenderer.invoke('db:query', { sql, params }),
    transaction: (operations)    => ipcRenderer.invoke('db:transaction', operations),
  },
  // Settings
  settings: {
    get:    (key)        => ipcRenderer.invoke('settings:get', key),
    set:    (key, value) => ipcRenderer.invoke('settings:set', key, value),
    getAll: ()           => ipcRenderer.invoke('settings:getAll'),
  },
  // Print
  print: {
    receipt: (html) => ipcRenderer.invoke('print:receipt', html),
  },
  // App
  app: {
    version:      ()    => ipcRenderer.invoke('app:version'),
    platform:     ()    => ipcRenderer.invoke('app:platform'),
    openExternal: (url) => ipcRenderer.invoke('app:openExternal', url),
  },
  // Dialog
  dialog: {
    saveFile: (options) => ipcRenderer.invoke('dialog:saveFile', options),
  },
  // Check if running in Electron
  isElectron: true,
});

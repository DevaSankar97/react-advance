const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path   = require('path');
const isDev  = process.env.NODE_ENV === 'development' || !app.isPackaged;

// ── Keep a global reference to prevent garbage collection ──
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1280,
    height: 800,
    minWidth:  1024,
    minHeight: 700,
    title: 'POSKit',
    icon: path.join(__dirname, '../public/icon.png'),
    webPreferences: {
      preload:         path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation:true,
    },
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    show: false,  // don't show until ready
  });

  // Load app
  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../build/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

// ── App lifecycle ──
app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ── Database IPC handlers ──
let db;

function getDb() {
  if (!db) {
    const Database  = require('better-sqlite3');
    const Store     = require('electron-store');
    const store     = new Store();
    const dbPath    = store.get('dbPath') || path.join(app.getPath('userData'), 'poskit.db');
    db = new Database(dbPath);
    initDb(db);
  }
  return db;
}

function initDb(db) {
  db.exec(`
    PRAGMA journal_mode=WAL;
    PRAGMA foreign_keys=ON;

    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS products (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      name          TEXT NOT NULL,
      barcode       TEXT UNIQUE,
      category      TEXT DEFAULT 'General',
      unit          TEXT DEFAULT 'piece',
      purchase_price REAL DEFAULT 0,
      sell_price    REAL NOT NULL,
      mrp           REAL DEFAULT 0,
      gst_rate      REAL DEFAULT 0,
      hsn_code      TEXT DEFAULT '',
      stock         REAL DEFAULT 0,
      min_stock     REAL DEFAULT 5,
      is_active     INTEGER DEFAULT 1,
      created_at    TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS customers (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      name         TEXT NOT NULL,
      phone        TEXT,
      email        TEXT,
      address      TEXT,
      gstin        TEXT,
      credit_limit REAL DEFAULT 0,
      balance      REAL DEFAULT 0,
      points       INTEGER DEFAULT 0,
      is_active    INTEGER DEFAULT 1,
      created_at   TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS bills (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_number    TEXT UNIQUE NOT NULL,
      customer_id    INTEGER REFERENCES customers(id),
      customer_name  TEXT,
      customer_phone TEXT,
      subtotal       REAL DEFAULT 0,
      discount       REAL DEFAULT 0,
      discount_type  TEXT DEFAULT 'flat',
      gst_amount     REAL DEFAULT 0,
      cgst           REAL DEFAULT 0,
      sgst           REAL DEFAULT 0,
      igst           REAL DEFAULT 0,
      round_off      REAL DEFAULT 0,
      total          REAL DEFAULT 0,
      paid_amount    REAL DEFAULT 0,
      change_amount  REAL DEFAULT 0,
      payment_mode   TEXT DEFAULT 'cash',
      payment_ref    TEXT,
      is_gst_bill    INTEGER DEFAULT 0,
      notes          TEXT,
      status         TEXT DEFAULT 'completed',
      created_at     TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS bill_items (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_id     INTEGER REFERENCES bills(id) ON DELETE CASCADE,
      product_id  INTEGER REFERENCES products(id),
      product_name TEXT NOT NULL,
      barcode     TEXT,
      hsn_code    TEXT,
      quantity    REAL NOT NULL,
      unit        TEXT DEFAULT 'piece',
      purchase_price REAL DEFAULT 0,
      sell_price  REAL NOT NULL,
      gst_rate    REAL DEFAULT 0,
      discount    REAL DEFAULT 0,
      total       REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS purchases (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_name TEXT,
      bill_number   TEXT,
      total_amount  REAL DEFAULT 0,
      payment_mode  TEXT DEFAULT 'cash',
      paid_status   TEXT DEFAULT 'paid',
      notes         TEXT,
      created_at    TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS purchase_items (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id    INTEGER REFERENCES purchases(id) ON DELETE CASCADE,
      product_id     INTEGER REFERENCES products(id),
      product_name   TEXT NOT NULL,
      quantity       REAL NOT NULL,
      purchase_price REAL NOT NULL,
      sell_price     REAL DEFAULT 0,
      total          REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      date        TEXT NOT NULL,
      category    TEXT DEFAULT 'other',
      description TEXT NOT NULL,
      amount      REAL NOT NULL,
      payment_mode TEXT DEFAULT 'cash',
      notes       TEXT,
      created_at  TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS staff (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      name         TEXT NOT NULL,
      phone        TEXT,
      role         TEXT DEFAULT 'cashier',
      pin          TEXT,
      salary       REAL DEFAULT 0,
      joining_date TEXT,
      is_active    INTEGER DEFAULT 1,
      created_at   TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS attendance (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      staff_id   INTEGER REFERENCES staff(id),
      date       TEXT NOT NULL,
      status     TEXT DEFAULT 'present',
      notes      TEXT,
      UNIQUE(staff_id, date)
    );

    CREATE TABLE IF NOT EXISTS stock_adjustments (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER REFERENCES products(id),
      type       TEXT NOT NULL,
      quantity   REAL NOT NULL,
      reason     TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);
}

// ── IPC: Database operations ──
ipcMain.handle('db:query', (event, { sql, params = [] }) => {
  try {
    const db   = getDb();
    const stmt = db.prepare(sql);
    if (sql.trim().toUpperCase().startsWith('SELECT')) {
      return { success: true, data: stmt.all(...params) };
    } else {
      const result = stmt.run(...params);
      return { success: true, data: result };
    }
  } catch (err) {
    console.error('DB Error:', err.message, '\nSQL:', sql);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('db:transaction', (event, operations) => {
  try {
    const db = getDb();
    const run = db.transaction(() => {
      const results = [];
      for (const op of operations) {
        const stmt = db.prepare(op.sql);
        if (op.sql.trim().toUpperCase().startsWith('SELECT')) {
          results.push(stmt.all(...(op.params||[])));
        } else {
          results.push(stmt.run(...(op.params||[])));
        }
      }
      return results;
    });
    return { success: true, data: run() };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ── IPC: Settings ──
ipcMain.handle('settings:get', (event, key) => {
  try {
    const db  = getDb();
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return row ? JSON.parse(row.value) : null;
  } catch { return null; }
});

ipcMain.handle('settings:set', (event, key, value) => {
  try {
    const db = getDb();
    db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, JSON.stringify(value));
    return true;
  } catch { return false; }
});

ipcMain.handle('settings:getAll', () => {
  try {
    const db   = getDb();
    const rows = db.prepare('SELECT key, value FROM settings').all();
    const obj  = {};
    rows.forEach(r => { try { obj[r.key] = JSON.parse(r.value); } catch { obj[r.key] = r.value; } });
    return obj;
  } catch { return {}; }
});

// ── IPC: Print receipt ──
ipcMain.handle('print:receipt', async (event, html) => {
  try {
    const win = new BrowserWindow({ show:false, webPreferences:{ nodeIntegration:false } });
    await win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
    await win.webContents.print({ silent:true, printBackground:true });
    win.destroy();
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ── IPC: App info ──
ipcMain.handle('app:version', () => app.getVersion());
ipcMain.handle('app:platform', () => process.platform);
ipcMain.handle('app:openExternal', (event, url) => shell.openExternal(url));

// ── IPC: Export data ──
ipcMain.handle('dialog:saveFile', async (event, options) => {
  const result = await dialog.showSaveDialog(mainWindow, options);
  return result;
});

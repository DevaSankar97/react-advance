import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { format, isToday, parseISO, differenceInDays, startOfDay } from 'date-fns';

const FREE_HABIT_LIMIT = 5;

const useStore = create(
  persist(
    (set, get) => ({

      // ── Habits ──
      habits: [],
      completions: {}, // { 'habitId_YYYY-MM-DD': true }
      isPro: false,
      language: 'en',
      darkMode: true,
      notificationsEnabled: true,
      onboardingDone: false,
      userName: '',

      // ── Habit CRUD ──
      addHabit: (habit) => {
        const { habits, isPro } = get();
        if (!isPro && habits.length >= FREE_HABIT_LIMIT) return false;
        set({ habits: [...habits, {
          id:        Date.now().toString(),
          name:      habit.name,
          emoji:     habit.emoji || '🎯',
          color:     habit.color || '#6366f1',
          frequency: habit.frequency || 'daily',
          reminder:  habit.reminder || null, // { hour, minute }
          createdAt: new Date().toISOString(),
          order:     habits.length,
          archived:  false,
        }]});
        return true;
      },

      updateHabit: (id, updates) => {
        set(state => ({
          habits: state.habits.map(h => h.id === id ? { ...h, ...updates } : h)
        }));
      },

      deleteHabit: (id) => {
        set(state => ({
          habits: state.habits.filter(h => h.id !== id),
          completions: Object.fromEntries(
            Object.entries(state.completions).filter(([k]) => !k.startsWith(id + '_'))
          )
        }));
      },

      reorderHabits: (newOrder) => {
        set({ habits: newOrder.map((h, i) => ({ ...h, order: i })) });
      },

      // ── Completions ──
      toggleCompletion: (habitId, date = new Date()) => {
        const key = `${habitId}_${format(date, 'yyyy-MM-dd')}`;
        set(state => {
          const updated = { ...state.completions };
          if (updated[key]) delete updated[key];
          else updated[key] = true;
          return { completions: updated };
        });
      },

      isCompleted: (habitId, date = new Date()) => {
        const key = `${habitId}_${format(date, 'yyyy-MM-dd')}`;
        return !!get().completions[key];
      },

      // ── Stats ──
      getCurrentStreak: (habitId) => {
        const { completions } = get();
        let streak = 0;
        const d = new Date();
        while (true) {
          const key = `${habitId}_${format(d, 'yyyy-MM-dd')}`;
          if (completions[key]) { streak++; d.setDate(d.getDate() - 1); }
          else break;
        }
        return streak;
      },

      getBestStreak: (habitId) => {
        const { completions, habits } = get();
        const habit = habits.find(h => h.id === habitId);
        if (!habit) return 0;
        let best = 0, current = 0;
        const created = parseISO(habit.createdAt);
        const today   = new Date();
        const d = new Date(created);
        while (d <= today) {
          const key = `${habitId}_${format(d, 'yyyy-MM-dd')}`;
          if (completions[key]) { current++; best = Math.max(best, current); }
          else current = 0;
          d.setDate(d.getDate() + 1);
        }
        return best;
      },

      getTotalCompletions: (habitId) => {
        return Object.keys(get().completions).filter(k => k.startsWith(habitId + '_')).length;
      },

      getCompletionRate: (habitId, days = 30) => {
        const { completions } = get();
        let done = 0;
        for (let i = 0; i < days; i++) {
          const d = new Date(); d.setDate(d.getDate() - i);
          const key = `${habitId}_${format(d, 'yyyy-MM-dd')}`;
          if (completions[key]) done++;
        }
        return Math.round((done / days) * 100);
      },

      getTodayProgress: () => {
        const { habits, completions } = get();
        const active = habits.filter(h => !h.archived);
        const today  = format(new Date(), 'yyyy-MM-dd');
        const done   = active.filter(h => completions[`${h.id}_${today}`]).length;
        return { done, total: active.length, pct: active.length ? Math.round((done / active.length) * 100) : 0 };
      },

      // Last 28 days heatmap data per habit
      getHeatmapData: (habitId) => {
        const { completions } = get();
        const data = [];
        for (let i = 27; i >= 0; i--) {
          const d = new Date(); d.setDate(d.getDate() - i);
          const key = `${habitId}_${format(d, 'yyyy-MM-dd')}`;
          data.push({ date: format(d, 'yyyy-MM-dd'), done: !!completions[key] });
        }
        return data;
      },

      getWeekData: (habitId) => {
        const { completions } = get();
        const days = [];
        for (let i = 6; i >= 0; i--) {
          const d = new Date(); d.setDate(d.getDate() - i);
          const key = `${habitId}_${format(d, 'yyyy-MM-dd')}`;
          days.push({ date: d, done: !!completions[key], label: format(d, 'EEE') });
        }
        return days;
      },

      // ── Settings ──
      setLanguage: (lang) => set({ language: lang }),
      setDarkMode: (val) => set({ darkMode: val }),
      setNotifications: (val) => set({ notificationsEnabled: val }),
      setUserName: (name) => set({ userName: name }),
      setOnboardingDone: () => set({ onboardingDone: true }),

      // ── Premium ──
      setPro: (val) => set({ isPro: val }),
      canAddHabit: () => {
        const { habits, isPro } = get();
        return isPro || habits.filter(h => !h.archived).length < FREE_HABIT_LIMIT;
      },
    }),

    {
      name:    'streakin-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

export default useStore;

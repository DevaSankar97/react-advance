import React, { useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Animated, Vibration, Dimensions, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { useTranslation } from 'react-i18next';
import { format } from 'date-fns';
import useStore from '../context/store';
import { DARK_THEME as T, FONT, COLORS } from '../utils/theme';

const { width } = Dimensions.get('window');

// ── Progress Ring ──
function ProgressRing({ pct, done, total, T }) {
  const size  = 120;
  const r     = 50;
  const circ  = 2 * Math.PI * r;
  const dash  = (pct / 100) * circ;
  const color = pct === 100 ? COLORS.success : COLORS.primary;

  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', width: size, height: size }}>
      {/* SVG-style via View hack — use react-native-svg in real app */}
      <View style={{
        width: size, height: size, borderRadius: size/2,
        borderWidth: 8, borderColor: T.border,
        alignItems: 'center', justifyContent: 'center',
        borderTopColor: color, borderRightColor: pct > 50 ? color : T.border,
        transform: [{ rotate: '-90deg' }],
        position: 'absolute',
      }}/>
      <Text style={{ fontSize: FONT.sizes.xxl, fontWeight: '800', color: color }}>{pct}%</Text>
      <Text style={{ fontSize: FONT.sizes.xs, color: T.textMuted }}>{done}/{total}</Text>
    </View>
  );
}

// ── Habit Row ──
function HabitRow({ habit, onToggle, isCompleted, currentStreak, T }) {
  const scale = useRef(new Animated.Value(1)).current;

  const handlePress = useCallback(() => {
    // Bounce animation
    Animated.sequence([
      Animated.spring(scale, { toValue: 0.92, useNativeDriver: true, speed: 50 }),
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 30 }),
    ]).start();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    onToggle();
  }, [onToggle]);

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <TouchableOpacity
        style={[styles.habitRow, { backgroundColor: T.card, borderColor: isCompleted ? habit.color + '60' : T.border }]}
        onPress={handlePress}
        activeOpacity={0.85}
      >
        {/* Check circle */}
        <View style={[styles.checkCircle, {
          backgroundColor: isCompleted ? habit.color : 'transparent',
          borderColor: isCompleted ? habit.color : T.border,
        }]}>
          <Text style={{ fontSize: 18, color: isCompleted ? '#fff' : 'transparent' }}>✓</Text>
        </View>

        {/* Info */}
        <View style={styles.habitInfo}>
          <Text style={[styles.habitName, {
            color: isCompleted ? T.textMuted : T.text,
            textDecorationLine: isCompleted ? 'line-through' : 'none',
          }]}>
            {habit.emoji} {habit.name}
          </Text>
          {currentStreak > 0 && (
            <Text style={{ fontSize: FONT.sizes.xs, color: COLORS.warning, marginTop: 2 }}>
              🔥 {currentStreak} day streak
            </Text>
          )}
        </View>

        {/* Color dot */}
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: habit.color }}/>
      </TouchableOpacity>
    </Animated.View>
  );
}

export default function HomeScreen({ navigation }) {
  const { t } = useTranslation();
  const store  = useStore();
  const { habits, toggleCompletion, isCompleted, getCurrentStreak, getTodayProgress, userName, darkMode } = store;
  const theme  = T; // always dark for now — can toggle

  const hour    = new Date().getHours();
  const greeting = hour < 12 ? t('goodMorning') : hour < 17 ? t('goodAfternoon') : t('goodEvening');
  const today   = format(new Date(), 'EEEE, d MMMM yyyy');
  const progress = getTodayProgress();
  const activeHabits = habits.filter(h => !h.archived).sort((a,b) => a.order - b.order);

  // Random daily quote
  const quotes  = [t('quote1'),t('quote2'),t('quote3'),t('quote4'),t('quote5')];
  const quote   = quotes[new Date().getDate() % quotes.length];

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>

        {/* Header */}
        <LinearGradient colors={['#1e1b4b','#312e81','#1e293b']} style={styles.header}>
          <Text style={[styles.greeting, { color: theme.textSub }]}>{greeting} {userName ? `, ${userName}` : ''}👋</Text>
          <Text style={[styles.todayDate, { color: theme.textMuted }]}>{today}</Text>

          {/* Progress */}
          <View style={styles.progressRow}>
            <ProgressRing pct={progress.pct} done={progress.done} total={progress.total} T={theme}/>
            <View style={styles.progressStats}>
              <View style={styles.statBox}>
                <Text style={[styles.statNum, { color: COLORS.success }]}>{progress.done}</Text>
                <Text style={[styles.statLabel, { color: theme.textMuted }]}>{t('completed')}</Text>
              </View>
              <View style={[styles.statDivider, { backgroundColor: theme.border }]}/>
              <View style={styles.statBox}>
                <Text style={[styles.statNum, { color: COLORS.warning }]}>{progress.total - progress.done}</Text>
                <Text style={[styles.statLabel, { color: theme.textMuted }]}>{t('remaining')}</Text>
              </View>
            </View>
          </View>

          {progress.pct === 100 && (
            <View style={styles.allDoneBanner}>
              <Text style={styles.allDoneText}>{t('allDone')}</Text>
            </View>
          )}
        </LinearGradient>

        {/* Quote */}
        <View style={[styles.quoteBox, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <Text style={[styles.quoteText, { color: theme.textSub }]}>✨ "{quote}"</Text>
        </View>

        {/* Habits list */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>
              {t('habits')} ({activeHabits.length})
            </Text>
            <TouchableOpacity
              style={[styles.addBtn, { backgroundColor: COLORS.primary }]}
              onPress={() => navigation.navigate('AddHabit')}
            >
              <Text style={{ color: '#fff', fontSize: 20, lineHeight: 22 }}>+</Text>
            </TouchableOpacity>
          </View>

          {activeHabits.length === 0 ? (
            <TouchableOpacity
              style={[styles.emptyState, { backgroundColor: theme.card, borderColor: theme.border }]}
              onPress={() => navigation.navigate('AddHabit')}
            >
              <Text style={{ fontSize: 48, marginBottom: 12 }}>🌱</Text>
              <Text style={[styles.emptyText, { color: theme.textSub }]}>{t('noHabits')}</Text>
            </TouchableOpacity>
          ) : (
            activeHabits.map(habit => (
              <HabitRow
                key={habit.id}
                habit={habit}
                isCompleted={isCompleted(habit.id)}
                currentStreak={getCurrentStreak(habit.id)}
                onToggle={() => toggleCompletion(habit.id)}
                T={theme}
              />
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  header:       { padding: 24, paddingTop: 60, paddingBottom: 28, borderBottomLeftRadius: 24, borderBottomRightRadius: 24 },
  greeting:     { fontSize: FONT.sizes.lg, fontWeight: '600', marginBottom: 2 },
  todayDate:    { fontSize: FONT.sizes.sm, marginBottom: 20 },
  progressRow:  { flexDirection: 'row', alignItems: 'center', gap: 28 },
  progressStats:{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 0 },
  statBox:      { flex: 1, alignItems: 'center' },
  statNum:      { fontSize: FONT.sizes.xxxl, fontWeight: '800' },
  statLabel:    { fontSize: FONT.sizes.xs, marginTop: 2, textTransform: 'uppercase', letterSpacing: 0.5 },
  statDivider:  { width: 1, height: 40 },
  allDoneBanner:{ marginTop: 16, backgroundColor: 'rgba(34,197,94,.15)', borderRadius: 12, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: COLORS.success + '40' },
  allDoneText:  { color: COLORS.success, fontWeight: '700', fontSize: FONT.sizes.md },
  quoteBox:     { margin: 16, padding: 14, borderRadius: 12, borderWidth: 1 },
  quoteText:    { fontSize: FONT.sizes.sm, lineHeight: 20, fontStyle: 'italic', textAlign: 'center' },
  section:      { paddingHorizontal: 16 },
  sectionHeader:{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: FONT.sizes.lg, fontWeight: '700' },
  addBtn:       { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  habitRow:     { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 14, marginBottom: 10, borderWidth: 1.5, gap: 12 },
  checkCircle:  { width: 40, height: 40, borderRadius: 20, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  habitInfo:    { flex: 1 },
  habitName:    { fontSize: FONT.sizes.md, fontWeight: '600' },
  emptyState:   { padding: 40, borderRadius: 16, borderWidth: 1, borderStyle: 'dashed', alignItems: 'center', marginTop: 8 },
  emptyText:    { fontSize: FONT.sizes.md, textAlign: 'center', lineHeight: 24 },
});

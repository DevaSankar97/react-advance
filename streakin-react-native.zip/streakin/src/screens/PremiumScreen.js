import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTranslation } from 'react-i18next';
import useStore from '../context/store';
import { DARK_THEME as T, FONT, COLORS } from '../utils/theme';

const { width } = Dimensions.get('window');

const FEATURES = [
  { icon:'♾️',  key:'proFeature1' },
  { icon:'📊',  key:'proFeature2' },
  { icon:'🔔',  key:'proFeature3' },
  { icon:'↕️',  key:'proFeature4' },
  { icon:'📱',  key:'proFeature5' },
  { icon:'🗣️', key:'proFeature6' },
];

export default function PremiumScreen({ navigation }) {
  const { t } = useTranslation();
  const { isPro, setPro } = useStore();
  const [selected, setSelected] = useState('yearly');
  const [loading, setLoading]   = useState(false);

  const handlePurchase = async () => {
    setLoading(true);
    try {
      // ── RevenueCat integration ──
      // In production, use react-native-purchases:
      //
      // import Purchases from 'react-native-purchases';
      // await Purchases.configure({ apiKey: 'YOUR_REVENUECAT_KEY' });
      // const offerings = await Purchases.getOfferings();
      // const package_ = selected === 'yearly'
      //   ? offerings.current.annual
      //   : offerings.current.monthly;
      // const { customerInfo } = await Purchases.purchasePackage(package_);
      // if (customerInfo.entitlements.active['pro']) { setPro(true); }

      // For demo — simulate purchase
      setTimeout(() => {
        setPro(true);
        setLoading(false);
        Alert.alert('🎉 Welcome to Pro!', 'All features unlocked. Enjoy!', [
          { text: 'Start Tracking!', onPress: () => navigation.goBack() }
        ]);
      }, 1500);
    } catch (err) {
      setLoading(false);
      if (!err.userCancelled) Alert.alert('Purchase failed', err.message);
    }
  };

  if (isPro) {
    return (
      <View style={[styles.container, { backgroundColor: T.bg, justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ fontSize: 72, marginBottom: 16 }}>🎉</Text>
        <Text style={[styles.proTitle, { color: T.text }]}>{t('alreadyPro')}</Text>
        <Text style={{ color: T.textSub, textAlign: 'center', marginTop: 8 }}>All features are unlocked!</Text>
        <TouchableOpacity style={[styles.primaryBtn, { marginTop: 32 }]} onPress={() => navigation.goBack()}>
          <Text style={styles.primaryBtnText}>Back to App</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: T.bg }]}>
      {/* Close */}
      <TouchableOpacity style={styles.closeBtn} onPress={() => navigation.goBack()}>
        <Text style={{ color: T.textMuted, fontSize: 22 }}>✕</Text>
      </TouchableOpacity>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        {/* Hero */}
        <LinearGradient colors={['#1e1b4b', '#4c1d95', '#312e81']} style={styles.hero}>
          <Text style={{ fontSize: 56 }}>✨</Text>
          <Text style={styles.heroTitle}>{t('proTitle')}</Text>
          <Text style={styles.heroSub}>{t('proSubtitle')}</Text>

          {/* Feature list */}
          <View style={styles.featureList}>
            {FEATURES.map(f => (
              <View key={f.key} style={styles.featureRow}>
                <View style={styles.featureCheck}>
                  <Text style={{ color: COLORS.success, fontSize: 13, fontWeight: '800' }}>✓</Text>
                </View>
                <Text style={{ color: 'rgba(255,255,255,.9)', fontSize: FONT.sizes.md, flex: 1 }}>{t(f.key)}</Text>
                <Text style={{ fontSize: 20 }}>{f.icon}</Text>
              </View>
            ))}
          </View>
        </LinearGradient>

        {/* Pricing cards */}
        <View style={{ padding: 20 }}>
          <Text style={[styles.pricingTitle, { color: T.textSub }]}>CHOOSE PLAN</Text>

          <View style={styles.plansRow}>
            {/* Monthly */}
            <TouchableOpacity onPress={() => setSelected('monthly')}
              style={[styles.planCard, { backgroundColor: T.card, borderColor: selected==='monthly' ? COLORS.primary : T.border }]}>
              <Text style={[styles.planName, { color: T.textSub }]}>Monthly</Text>
              <Text style={[styles.planPrice, { color: T.text }]}>₹99</Text>
              <Text style={[styles.planPeriod, { color: T.textMuted }]}>per month</Text>
              {selected==='monthly' && <View style={[styles.selectedDot, { backgroundColor: COLORS.primary }]}/>}
            </TouchableOpacity>

            {/* Yearly — recommended */}
            <TouchableOpacity onPress={() => setSelected('yearly')}
              style={[styles.planCard, styles.planCardLarge, { backgroundColor: COLORS.primary + '15', borderColor: COLORS.primary, borderWidth: 2 }]}>
              <View style={styles.badgeWrap}>
                <View style={[styles.badge, { backgroundColor: COLORS.warning }]}>
                  <Text style={{ color: '#fff', fontSize: 10, fontWeight: '800' }}>SAVE 41%</Text>
                </View>
              </View>
              <Text style={[styles.planName, { color: COLORS.accent }]}>Yearly</Text>
              <Text style={[styles.planPrice, { color: T.text }]}>₹699</Text>
              <Text style={[styles.planPeriod, { color: T.textMuted }]}>per year</Text>
              <Text style={{ color: COLORS.success, fontSize: FONT.sizes.xs, marginTop: 4 }}>= ₹58/mo only!</Text>
              {selected==='yearly' && <View style={[styles.selectedDot, { backgroundColor: COLORS.primary }]}/>}
            </TouchableOpacity>
          </View>

          {/* CTA */}
          <TouchableOpacity style={styles.primaryBtn} onPress={handlePurchase} disabled={loading}>
            <LinearGradient colors={['#6366f1', '#4f46e5']} style={styles.primaryBtnGrad}>
              <Text style={styles.primaryBtnText}>
                {loading ? 'Processing...' : `Get Pro — ${selected === 'yearly' ? '₹699/year' : '₹99/month'}`}
              </Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginTop: 12, alignItems: 'center' }}>
            <Text style={{ color: T.textMuted, fontSize: FONT.sizes.sm }}>{t('startFree')}</Text>
          </TouchableOpacity>

          <Text style={{ color: T.textMuted, fontSize: FONT.sizes.xs, textAlign: 'center', marginTop: 16, lineHeight: 18 }}>
            Payment processed securely via Google Play / App Store.{'\n'}
            Cancel anytime. Restoring purchases: tap in Profile.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1 },
  closeBtn:       { position: 'absolute', top: 56, right: 20, zIndex: 10, width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  hero:           { paddingTop: 80, paddingBottom: 32, paddingHorizontal: 24, alignItems: 'center' },
  heroTitle:      { color: '#fff', fontSize: FONT.sizes.xxxl, fontWeight: '800', marginTop: 10, marginBottom: 4 },
  heroSub:        { color: 'rgba(255,255,255,.65)', fontSize: FONT.sizes.md, marginBottom: 24, textAlign: 'center' },
  featureList:    { width: '100%', gap: 10 },
  featureRow:     { flexDirection: 'row', alignItems: 'center', gap: 10 },
  featureCheck:   { width: 22, height: 22, borderRadius: 11, backgroundColor: COLORS.success + '20', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: COLORS.success },
  pricingTitle:   { fontSize: FONT.sizes.xs, fontWeight: '700', letterSpacing: 0.5, marginBottom: 12, textAlign: 'center' },
  plansRow:       { flexDirection: 'row', gap: 12, marginBottom: 20 },
  planCard:       { flex: 1, borderRadius: 16, padding: 16, alignItems: 'center', borderWidth: 1.5, position: 'relative' },
  planCardLarge:  { transform: [{ scale: 1.03 }] },
  badgeWrap:      { position: 'absolute', top: -12 },
  badge:          { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 10 },
  planName:       { fontSize: FONT.sizes.sm, fontWeight: '600', marginBottom: 4 },
  planPrice:      { fontSize: FONT.sizes.xxxl, fontWeight: '800' },
  planPeriod:     { fontSize: FONT.sizes.xs },
  selectedDot:    { width: 8, height: 8, borderRadius: 4, marginTop: 8 },
  primaryBtn:     { borderRadius: 16, overflow: 'hidden' },
  primaryBtnGrad: { paddingVertical: 18, alignItems: 'center', borderRadius: 16 },
  primaryBtnText: { color: '#fff', fontSize: FONT.sizes.lg, fontWeight: '800' },
  proTitle:       { fontSize: FONT.sizes.xxl, fontWeight: '800' },
});

import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Switch, Alert, Platform,
} from 'react-native';
import { useTranslation } from 'react-i18next';
import useStore from '../context/store';
import { DARK_THEME as T, FONT, COLORS, HABIT_EMOJIS } from '../utils/theme';
import * as Notifications from 'expo-notifications';

const PRESET_HABITS = [
  { key:'preset_water',      emoji:'💧', color:'#0ea5e9' },
  { key:'preset_exercise',   emoji:'🏃', color:'#22c55e' },
  { key:'preset_meditation', emoji:'🧘', color:'#8b5cf6' },
  { key:'preset_reading',    emoji:'📚', color:'#f59e0b' },
  { key:'preset_sleep',      emoji:'😴', color:'#6366f1' },
  { key:'preset_journal',    emoji:'✍️', color:'#ec4899' },
  { key:'preset_noSugar',    emoji:'🥗', color:'#22c55e' },
  { key:'preset_walk',       emoji:'🚶', color:'#14b8a6' },
  { key:'preset_vitamins',   emoji:'💊', color:'#ef4444' },
  { key:'preset_gratitude',  emoji:'🙏', color:'#f97316' },
  { key:'preset_coldShower', emoji:'🛁', color:'#0ea5e9' },
  { key:'preset_noPhone',    emoji:'📵', color:'#64748b' },
];

const HABIT_COLORS = [
  '#6366f1','#22c55e','#f59e0b','#ef4444',
  '#0ea5e9','#ec4899','#14b8a6','#f97316',
  '#8b5cf6','#84cc16','#06b6d4','#e879f9',
];

export default function AddHabitScreen({ navigation, route }) {
  const { t } = useTranslation();
  const { addHabit, canAddHabit, isPro } = useStore();
  const editHabit = route.params?.habit;

  const [name, setName]             = useState(editHabit?.name || '');
  const [emoji, setEmoji]           = useState(editHabit?.emoji || '🎯');
  const [color, setColor]           = useState(editHabit?.color || '#6366f1');
  const [frequency, setFrequency]   = useState(editHabit?.frequency || 'daily');
  const [reminderOn, setReminderOn] = useState(!!editHabit?.reminder);
  const [reminderHour, setHour]     = useState(editHabit?.reminder?.hour ?? 8);
  const [reminderMin, setMin]       = useState(editHabit?.reminder?.minute ?? 0);
  const [tab, setTab]               = useState('preset'); // preset | custom

  const scheduleReminder = async (habitId, hour, minute, habitName) => {
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') return;
      await Notifications.scheduleNotificationAsync({
        content: {
          title: `⏰ ${habitName}`,
          body:  `Don't forget your habit! Keep your streak going 🔥`,
          sound: true,
        },
        trigger: {
          hour, minute,
          repeats: true,
        },
      });
    } catch (err) { console.log('Notification error:', err); }
  };

  const handleSave = useCallback(() => {
    if (!name.trim()) {
      Alert.alert('Error', t('habitName') + ' is required');
      return;
    }

    if (!canAddHabit()) {
      navigation.navigate('Premium');
      return;
    }

    const success = addHabit({
      name: name.trim(), emoji, color, frequency,
      reminder: reminderOn ? { hour: reminderHour, minute: reminderMin } : null,
    });

    if (success) {
      if (reminderOn) scheduleReminder(Date.now().toString(), reminderHour, reminderMin, name);
      navigation.goBack();
    }
  }, [name, emoji, color, frequency, reminderOn, reminderHour, reminderMin]);

  const pickPreset = (preset) => {
    setName(t(preset.key));
    setEmoji(preset.emoji);
    setColor(preset.color);
    setTab('custom');
  };

  const hours   = Array.from({length:24},(_,i)=>i);
  const minutes = [0,15,30,45];

  return (
    <View style={[styles.container, { backgroundColor: T.bg }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: T.card, borderBottomColor: T.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{ color: COLORS.primary, fontSize: FONT.sizes.md }}>✕</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: T.text }]}>{t('addHabit')}</Text>
        <TouchableOpacity onPress={handleSave}>
          <Text style={{ color: COLORS.primary, fontSize: FONT.sizes.md, fontWeight: '700' }}>{t('save')}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>

        {/* Tab switcher */}
        <View style={[styles.tabRow, { backgroundColor: T.card2 }]}>
          {['preset','custom'].map(tab2 => (
            <TouchableOpacity key={tab2} onPress={() => setTab(tab2)}
              style={[styles.tabBtn, tab === tab2 && { backgroundColor: COLORS.primary }]}>
              <Text style={{ color: tab === tab2 ? '#fff' : T.textSub, fontWeight: '600', fontSize: FONT.sizes.sm }}>
                {tab2 === 'preset' ? t('presets') : t('custom')}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {tab === 'preset' ? (
          /* ── Presets grid ── */
          <View>
            <Text style={[styles.label, { color: T.textSub }]}>Tap to use a preset habit</Text>
            <View style={styles.presetGrid}>
              {PRESET_HABITS.map(p => (
                <TouchableOpacity key={p.key} style={[styles.presetCard, { backgroundColor: T.card, borderColor: T.border }]}
                  onPress={() => pickPreset(p)}>
                  <View style={[styles.presetIcon, { backgroundColor: p.color + '20' }]}>
                    <Text style={{ fontSize: 26 }}>{p.emoji}</Text>
                  </View>
                  <Text style={[styles.presetName, { color: T.text }]} numberOfLines={2}>{t(p.key)}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ) : (
          /* ── Custom form ── */
          <View>
            {/* Name input */}
            <Text style={[styles.label, { color: T.textSub }]}>{t('habitName')} *</Text>
            <View style={[styles.inputRow, { backgroundColor: T.card, borderColor: T.border }]}>
              <Text style={{ fontSize: 22, marginRight: 10 }}>{emoji}</Text>
              <TextInput
                style={[styles.input, { color: T.text }]}
                placeholder={t('habitNameHint')}
                placeholderTextColor={T.textMuted}
                value={name}
                onChangeText={setName}
                maxLength={40}
                autoFocus
              />
            </View>

            {/* Emoji picker */}
            <Text style={[styles.label, { color: T.textSub }]}>{t('icon')}</Text>
            <View style={styles.emojiGrid}>
              {HABIT_EMOJIS.map(e => (
                <TouchableOpacity key={e} onPress={() => setEmoji(e)}
                  style={[styles.emojiBtn, { backgroundColor: emoji===e ? COLORS.primary+'30' : T.card, borderColor: emoji===e ? COLORS.primary : T.border }]}>
                  <Text style={{ fontSize: 22 }}>{e}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Color picker */}
            <Text style={[styles.label, { color: T.textSub }]}>{t('color')}</Text>
            <View style={styles.colorRow}>
              {HABIT_COLORS.map(c => (
                <TouchableOpacity key={c} onPress={() => setColor(c)}
                  style={[styles.colorDot, { backgroundColor: c, borderWidth: color===c ? 3 : 0, borderColor: '#fff', transform: [{scale: color===c ? 1.2 : 1}] }]}/>
              ))}
            </View>

            {/* Frequency */}
            <Text style={[styles.label, { color: T.textSub }]}>{t('frequency')}</Text>
            <View style={styles.freqRow}>
              {['daily','weekly'].map(f => (
                <TouchableOpacity key={f} onPress={() => setFrequency(f)}
                  style={[styles.freqBtn, { backgroundColor: frequency===f ? COLORS.primary : T.card, borderColor: frequency===f ? COLORS.primary : T.border }]}>
                  <Text style={{ color: frequency===f ? '#fff' : T.textSub, fontWeight: '600' }}>
                    {f === 'daily' ? t('daily') : t('weekly')}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Reminder */}
            <View style={[styles.reminderRow, { backgroundColor: T.card, borderColor: T.border }]}>
              <View>
                <Text style={[styles.reminderTitle, { color: T.text }]}>{t('reminder')}</Text>
                <Text style={{ color: T.textMuted, fontSize: FONT.sizes.sm }}>
                  {reminderOn ? `${String(reminderHour).padStart(2,'0')}:${String(reminderMin).padStart(2,'0')}` : t('setReminder')}
                </Text>
              </View>
              <Switch value={reminderOn} onValueChange={setReminderOn} trackColor={{ false: T.border, true: COLORS.primary }} thumbColor="#fff"/>
            </View>

            {reminderOn && (
              <View style={[styles.timeRow, { backgroundColor: T.card, borderColor: T.border }]}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {hours.map(h => (
                    <TouchableOpacity key={h} onPress={() => setHour(h)}
                      style={[styles.timeBtn, { backgroundColor: reminderHour===h ? COLORS.primary : T.card2, marginRight: 6 }]}>
                      <Text style={{ color: reminderHour===h ? '#fff' : T.textSub, fontSize: FONT.sizes.sm }}>
                        {String(h).padStart(2,'0')}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                <Text style={{ color: T.textMuted, marginHorizontal: 8 }}>:</Text>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  {minutes.map(m => (
                    <TouchableOpacity key={m} onPress={() => setMin(m)}
                      style={[styles.timeBtn, { backgroundColor: reminderMin===m ? COLORS.primary : T.card2 }]}>
                      <Text style={{ color: reminderMin===m ? '#fff' : T.textSub, fontSize: FONT.sizes.sm }}>
                        {String(m).padStart(2,'0')}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}

            {/* Preview */}
            {name.length > 0 && (
              <View style={[styles.preview, { backgroundColor: color + '15', borderColor: color + '40' }]}>
                <Text style={{ fontSize: 24 }}>{emoji}</Text>
                <Text style={{ color: T.text, fontWeight: '600', fontSize: FONT.sizes.md, flex: 1, marginLeft: 10 }}>{name}</Text>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }}/>
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  header:       { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal:16, paddingTop:60, paddingBottom:16, borderBottomWidth:1 },
  headerTitle:  { fontSize:FONT.sizes.lg, fontWeight:'700' },
  tabRow:       { flexDirection:'row', borderRadius:10, padding:4, marginBottom:20 },
  tabBtn:       { flex:1, paddingVertical:8, borderRadius:8, alignItems:'center' },
  label:        { fontSize:FONT.sizes.sm, fontWeight:'600', textTransform:'uppercase', letterSpacing:0.5, marginBottom:8, marginTop:16 },
  inputRow:     { flexDirection:'row', alignItems:'center', borderRadius:12, padding:14, borderWidth:1.5 },
  input:        { flex:1, fontSize:FONT.sizes.md, outline:'none' },
  emojiGrid:    { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:4 },
  emojiBtn:     { width:44, height:44, borderRadius:10, borderWidth:1.5, alignItems:'center', justifyContent:'center' },
  colorRow:     { flexDirection:'row', flexWrap:'wrap', gap:10, marginBottom:4 },
  colorDot:     { width:32, height:32, borderRadius:16 },
  freqRow:      { flexDirection:'row', gap:10 },
  freqBtn:      { flex:1, paddingVertical:12, borderRadius:12, borderWidth:1.5, alignItems:'center' },
  reminderRow:  { flexDirection:'row', justifyContent:'space-between', alignItems:'center', borderRadius:12, padding:14, borderWidth:1, marginTop:16 },
  reminderTitle:{ fontSize:FONT.sizes.md, fontWeight:'600', marginBottom:2 },
  timeRow:      { flexDirection:'row', alignItems:'center', borderRadius:12, padding:12, borderWidth:1, marginTop:8, flexWrap:'wrap' },
  timeBtn:      { paddingHorizontal:10, paddingVertical:6, borderRadius:8 },
  preview:      { flexDirection:'row', alignItems:'center', borderRadius:14, padding:14, borderWidth:1, marginTop:20 },
  presetGrid:   { flexDirection:'row', flexWrap:'wrap', gap:10 },
  presetCard:   { width:'47%', borderRadius:14, padding:14, borderWidth:1, alignItems:'center', gap:8 },
  presetIcon:   { width:52, height:52, borderRadius:26, alignItems:'center', justifyContent:'center' },
  presetName:   { fontSize:FONT.sizes.sm, fontWeight:'600', textAlign:'center' },
});

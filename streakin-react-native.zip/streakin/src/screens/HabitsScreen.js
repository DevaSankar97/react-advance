import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import DraggableFlatList, { ScaleDecorator } from 'react-native-draggable-flatlist';
import { useTranslation } from 'react-i18next';
import useStore from '../context/store';
import { DARK_THEME as T, FONT, COLORS } from '../utils/theme';

export default function HabitsScreen({ navigation }) {
  const { t } = useTranslation();
  const { habits, deleteHabit, reorderHabits, isPro } = useStore();
  const active = habits.filter(h => !h.archived).sort((a, b) => a.order - b.order);

  const handleDelete = (id, name) => {
    Alert.alert(
      t('delete') + ' ' + name + '?',
      t('deleteConfirm'),
      [
        { text: t('cancel'), style: 'cancel' },
        { text: t('delete'), style: 'destructive', onPress: () => deleteHabit(id) },
      ]
    );
  };

  const renderItem = ({ item, drag, isActive }) => (
    <ScaleDecorator>
      <TouchableOpacity
        style={[styles.habitRow, {
          backgroundColor: isActive ? T.card2 : T.card,
          borderColor: isActive ? COLORS.primary : T.border,
          opacity: isActive ? 0.95 : 1,
        }]}
        onLongPress={drag}
        delayLongPress={200}
        onPress={() => navigation.navigate('EditHabit', { habit: item })}
      >
        {/* Drag handle */}
        <View style={styles.dragHandle}>
          <View style={[styles.dragDot, { backgroundColor: T.border }]}/>
          <View style={[styles.dragDot, { backgroundColor: T.border }]}/>
          <View style={[styles.dragDot, { backgroundColor: T.border }]}/>
          <View style={[styles.dragDot, { backgroundColor: T.border }]}/>
          <View style={[styles.dragDot, { backgroundColor: T.border }]}/>
          <View style={[styles.dragDot, { backgroundColor: T.border }]}/>
        </View>

        {/* Color dot + emoji */}
        <View style={[styles.emojiCircle, { backgroundColor: item.color + '20' }]}>
          <Text style={{ fontSize: 20 }}>{item.emoji}</Text>
        </View>

        {/* Info */}
        <View style={styles.info}>
          <Text style={[styles.name, { color: T.text }]}>{item.name}</Text>
          <Text style={[styles.freq, { color: T.textMuted }]}>
            {item.frequency === 'daily' ? t('daily') : t('weekly')}
            {item.reminder ? ` · ⏰ ${String(item.reminder.hour).padStart(2,'0')}:${String(item.reminder.minute).padStart(2,'0')}` : ''}
          </Text>
        </View>

        {/* Actions */}
        <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(item.id, item.name)}>
          <Text style={{ color: COLORS.danger, fontSize: 16 }}>🗑</Text>
        </TouchableOpacity>
      </TouchableOpacity>
    </ScaleDecorator>
  );

  return (
    <View style={[styles.container, { backgroundColor: T.bg }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: T.card, borderBottomColor: T.border }]}>
        <View>
          <Text style={[styles.headerTitle, { color: T.text }]}>{t('habits')}</Text>
          <Text style={[styles.headerSub, { color: T.textMuted }]}>
            {active.length} habits {!isPro ? `· ${active.length}/5 free` : '· Pro unlimited'}
          </Text>
        </View>
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: COLORS.primary }]}
          onPress={() => navigation.navigate('AddHabit')}
        >
          <Text style={{ color: '#fff', fontSize: 24, lineHeight: 28 }}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Pro reorder tip */}
      {isPro && active.length > 1 && (
        <View style={[styles.tip, { backgroundColor: COLORS.primary + '15', borderColor: COLORS.primary + '30' }]}>
          <Text style={{ color: COLORS.accent, fontSize: FONT.sizes.sm }}>
            💡 Long press and drag to reorder habits
          </Text>
        </View>
      )}

      {active.length === 0 ? (
        <TouchableOpacity style={styles.emptyState} onPress={() => navigation.navigate('AddHabit')}>
          <Text style={{ fontSize: 56, marginBottom: 12 }}>🌱</Text>
          <Text style={[styles.emptyText, { color: T.textSub }]}>{t('noHabits')}</Text>
        </TouchableOpacity>
      ) : (
        <DraggableFlatList
          data={active}
          onDragEnd={({ data }) => { if (isPro) reorderHabits(data); }}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
        />
      )}

      {/* Free limit bar */}
      {!isPro && (
        <TouchableOpacity
          style={[styles.limitBar, { backgroundColor: T.card, borderTopColor: T.border }]}
          onPress={() => navigation.navigate('Premium')}
        >
          <View style={styles.limitBarInner}>
            <View style={styles.limitProgress}>
              <View style={[styles.limitFill, { width: `${(active.length/5)*100}%`, backgroundColor: active.length>=5 ? COLORS.danger : COLORS.primary }]}/>
            </View>
            <Text style={{ color: T.textSub, fontSize: FONT.sizes.sm, flex: 1 }}>
              {active.length}/5 habits used
            </Text>
            <Text style={{ color: COLORS.primary, fontSize: FONT.sizes.sm, fontWeight: '700' }}>
              Upgrade →
            </Text>
          </View>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  header:       { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal:16, paddingTop:60, paddingBottom:16, borderBottomWidth:1 },
  headerTitle:  { fontSize:FONT.sizes.xl, fontWeight:'800' },
  headerSub:    { fontSize:FONT.sizes.sm, marginTop:2 },
  addBtn:       { width:40, height:40, borderRadius:20, alignItems:'center', justifyContent:'center' },
  tip:          { marginHorizontal:16, marginTop:10, padding:10, borderRadius:10, borderWidth:1 },
  habitRow:     { flexDirection:'row', alignItems:'center', padding:14, borderRadius:14, marginBottom:10, borderWidth:1.5, gap:10 },
  dragHandle:   { flexDirection:'column', flexWrap:'wrap', width:10, height:20, gap:3 },
  dragDot:      { width:3, height:3, borderRadius:1.5 },
  emojiCircle:  { width:44, height:44, borderRadius:22, alignItems:'center', justifyContent:'center' },
  info:         { flex:1 },
  name:         { fontSize:FONT.sizes.md, fontWeight:'600', marginBottom:2 },
  freq:         { fontSize:FONT.sizes.xs },
  deleteBtn:    { padding:6 },
  emptyState:   { flex:1, alignItems:'center', justifyContent:'center', paddingBottom:80 },
  emptyText:    { fontSize:FONT.sizes.md, textAlign:'center', lineHeight:24 },
  limitBar:     { position:'absolute', bottom:0, left:0, right:0, borderTopWidth:1, padding:12 },
  limitBarInner:{ flexDirection:'row', alignItems:'center', gap:10 },
  limitProgress:{ width:60, height:6, borderRadius:3, backgroundColor:'#334155', overflow:'hidden' },
  limitFill:    { height:'100%', borderRadius:3 },
});

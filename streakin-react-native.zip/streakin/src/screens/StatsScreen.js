import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { useTranslation } from 'react-i18next';
import useStore from '../context/store';
import { DARK_THEME as T, FONT, COLORS } from '../utils/theme';
import { format, subDays } from 'date-fns';

const { width } = Dimensions.get('window');

// ── Mini heatmap ──
function Heatmap({ data, color }) {
  const weeks = [];
  for (let w = 0; w < 4; w++) {
    const week = data.slice(w * 7, (w + 1) * 7);
    weeks.push(week);
  }
  return (
    <View style={{ flexDirection: 'row', gap: 3 }}>
      {weeks.map((week, wi) => (
        <View key={wi} style={{ flexDirection: 'column', gap: 3 }}>
          {week.map((day, di) => (
            <View key={di} style={{
              width: 14, height: 14, borderRadius: 3,
              backgroundColor: day.done ? color : T.border,
              opacity: day.done ? 1 : 0.4,
            }}/>
          ))}
        </View>
      ))}
    </View>
  );
}

// ── Week bar chart ──
function WeekBar({ days, color }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8, height: 50 }}>
      {days.map((d, i) => (
        <View key={i} style={{ flex: 1, alignItems: 'center', gap: 3 }}>
          <View style={{
            width: '100%', height: d.done ? 36 : 6,
            backgroundColor: d.done ? color : T.border,
            borderRadius: 4, opacity: d.done ? 1 : 0.4,
          }}/>
          <Text style={{ color: T.textMuted, fontSize: 9 }}>{d.label.slice(0,1)}</Text>
        </View>
      ))}
    </View>
  );
}

function HabitStatCard({ habit, store }) {
  const streak  = store.getCurrentStreak(habit.id);
  const best    = store.getBestStreak(habit.id);
  const total   = store.getTotalCompletions(habit.id);
  const rate    = store.getCompletionRate(habit.id, 30);
  const heatmap = store.getHeatmapData(habit.id);
  const week    = store.getWeekData(habit.id);

  return (
    <View style={[styles.statCard, { backgroundColor: T.card, borderColor: habit.color + '40' }]}>
      <View style={styles.statCardHeader}>
        <Text style={{ fontSize: 24 }}>{habit.emoji}</Text>
        <Text style={[styles.statCardName, { color: T.text }]}>{habit.name}</Text>
        {streak > 0 && (
          <View style={[styles.streakBadge, { backgroundColor: COLORS.warning + '20' }]}>
            <Text style={{ color: COLORS.warning, fontSize: FONT.sizes.xs, fontWeight: '700' }}>🔥 {streak}</Text>
          </View>
        )}
      </View>

      {/* 4 stats */}
      <View style={styles.statsRow}>
        {[
          { label: 'Current', value: streak, color: COLORS.primary },
          { label: 'Best',    value: best,   color: COLORS.success },
          { label: 'Total',   value: total,  color: COLORS.warning },
          { label: '30d Rate',value: `${rate}%`, color: COLORS.accent },
        ].map(s => (
          <View key={s.label} style={styles.statCell}>
            <Text style={[styles.statCellNum, { color: s.color }]}>{s.value}</Text>
            <Text style={[styles.statCellLabel, { color: T.textMuted }]}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Week chart */}
      <WeekBar days={week} color={habit.color}/>

      {/* Heatmap */}
      <View style={{ marginTop: 10 }}>
        <Text style={{ color: T.textMuted, fontSize: FONT.sizes.xs, marginBottom: 6 }}>Last 28 days</Text>
        <Heatmap data={heatmap} color={habit.color}/>
      </View>
    </View>
  );
}

export default function StatsScreen() {
  const { t } = useTranslation();
  const store  = useStore();
  const { habits } = store;
  const active  = habits.filter(h => !h.archived);
  const progress= store.getTodayProgress();

  // Overall stats
  const totalDoneAllTime = active.reduce((s, h) => s + store.getTotalCompletions(h.id), 0);
  const avgStreak        = active.length ? Math.round(active.reduce((s,h) => s + store.getCurrentStreak(h.id), 0) / active.length) : 0;
  const bestStreakAll    = active.reduce((b, h) => Math.max(b, store.getBestStreak(h.id)), 0);

  return (
    <View style={[styles.container, { backgroundColor: T.bg }]}>
      <View style={[styles.header, { backgroundColor: T.card, borderBottomColor: T.border }]}>
        <Text style={[styles.headerTitle, { color: T.text }]}>{t('statistics')}</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>

        {/* Overall */}
        <View style={[styles.overallCard, { backgroundColor: T.card, borderColor: T.border }]}>
          <Text style={[styles.overallTitle, { color: T.textSub }]}>OVERALL</Text>
          <View style={styles.overallRow}>
            {[
              { icon:'✅', label:'Today',      value:`${progress.done}/${progress.total}`, color:COLORS.success },
              { icon:'🔥', label:'Avg Streak', value:avgStreak,                            color:COLORS.warning },
              { icon:'🏆', label:'Best Ever',  value:bestStreakAll,                        color:COLORS.primary },
              { icon:'📊', label:'All Time',   value:totalDoneAllTime,                    color:COLORS.accent  },
            ].map(s => (
              <View key={s.label} style={styles.overallCell}>
                <Text style={{ fontSize: 20 }}>{s.icon}</Text>
                <Text style={[styles.overallNum, { color: s.color }]}>{s.value}</Text>
                <Text style={[styles.overallLabel, { color: T.textMuted }]}>{s.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Per habit */}
        {active.length === 0 ? (
          <View style={styles.empty}>
            <Text style={{ fontSize: 48, marginBottom: 12 }}>📊</Text>
            <Text style={{ color: T.textSub, textAlign: 'center' }}>{t('noStats')}</Text>
          </View>
        ) : (
          active.map(habit => (
            <HabitStatCard key={habit.id} habit={habit} store={store}/>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:     { flex: 1 },
  header:        { paddingHorizontal: 16, paddingTop: 60, paddingBottom: 16, borderBottomWidth: 1 },
  headerTitle:   { fontSize: FONT.sizes.xl, fontWeight: '800' },
  overallCard:   { borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1 },
  overallTitle:  { fontSize: FONT.sizes.xs, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 12 },
  overallRow:    { flexDirection: 'row', justifyContent: 'space-around' },
  overallCell:   { alignItems: 'center', gap: 3 },
  overallNum:    { fontSize: FONT.sizes.xl, fontWeight: '800' },
  overallLabel:  { fontSize: FONT.sizes.xs },
  statCard:      { borderRadius: 16, padding: 16, marginBottom: 14, borderWidth: 1.5 },
  statCardHeader:{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 },
  statCardName:  { flex: 1, fontSize: FONT.sizes.md, fontWeight: '700' },
  streakBadge:   { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
  statsRow:      { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14 },
  statCell:      { alignItems: 'center' },
  statCellNum:   { fontSize: FONT.sizes.xl, fontWeight: '800' },
  statCellLabel: { fontSize: FONT.sizes.xs, marginTop: 2 },
  empty:         { alignItems: 'center', paddingVertical: 60 },
});

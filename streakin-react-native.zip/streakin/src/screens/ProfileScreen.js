import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Share, Alert } from 'react-native';
import { useTranslation } from 'react-i18next';
import * as StoreReview from 'expo-store-review';
import useStore from '../context/store';
import { DARK_THEME as T, FONT, COLORS } from '../utils/theme';
import { LANGUAGES } from '../i18n';
import i18n from '../i18n';

function SettingRow({ icon, label, value, onPress, rightElement }) {
  return (
    <TouchableOpacity style={[styles.row, { backgroundColor: T.card, borderBottomColor: T.border }]}
      onPress={onPress} disabled={!onPress && !rightElement}>
      <Text style={{ fontSize: 20, marginRight: 12 }}>{icon}</Text>
      <Text style={[styles.rowLabel, { color: T.text }]}>{label}</Text>
      <View style={styles.rowRight}>
        {rightElement || (value && <Text style={{ color: T.textMuted, fontSize: FONT.sizes.sm }}>{value}</Text>)}
        {onPress && !rightElement && <Text style={{ color: T.textMuted }}>›</Text>}
      </View>
    </TouchableOpacity>
  );
}

export default function ProfileScreen({ navigation }) {
  const { t } = useTranslation();
  const { isPro, darkMode, notificationsEnabled, language, setLanguage, setDarkMode, setNotifications, habits, getTodayProgress } = useStore();
  const progress = getTodayProgress();
  const activeHabits = habits.filter(h => !h.archived);

  const changeLanguage = () => {
    Alert.alert(
      t('language'),
      'Select Language / भाषा चुनें / மொழி தேர்வு',
      LANGUAGES.map(lang => ({
        text: `${lang.native} (${lang.name})`,
        onPress: () => {
          setLanguage(lang.code);
          i18n.changeLanguage(lang.code);
        },
      })).concat([{ text: t('cancel'), style: 'cancel' }])
    );
  };

  const shareApp = async () => {
    try {
      await Share.share({
        message: `📱 I'm using StreakIn to build good habits! Free download:\n\n🤖 Android: https://play.google.com/store/apps/details?id=com.devasankar.streakin\n🍎 iOS: https://apps.apple.com/app/streakin\n\n#StreakIn #HabitTracker #MadeInIndia`,
        title: 'StreakIn — Build Habits That Stick',
      });
    } catch {}
  };

  const rateApp = async () => {
    if (await StoreReview.hasAction()) await StoreReview.requestReview();
  };

  const currentLang = LANGUAGES.find(l => l.code === language);

  return (
    <View style={[styles.container, { backgroundColor: T.bg }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: T.card, borderBottomColor: T.border }]}>
        <Text style={[styles.headerTitle, { color: T.text }]}>{t('myProfile')}</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>

        {/* Profile card */}
        <View style={[styles.profileCard, { backgroundColor: 'linear-gradient(135deg,#1e1b4b,#312e81)' }]}>
          <View style={styles.avatarRing}>
            <Text style={{ fontSize: 32 }}>🎯</Text>
          </View>
          <Text style={[styles.profileName, { color: T.text }]}>StreakIn User</Text>
          <View style={styles.profileStats}>
            <View style={styles.pStat}>
              <Text style={[styles.pStatNum, { color: COLORS.primary }]}>{activeHabits.length}</Text>
              <Text style={[styles.pStatLabel, { color: T.textMuted }]}>Habits</Text>
            </View>
            <View style={styles.pStat}>
              <Text style={[styles.pStatNum, { color: COLORS.success }]}>{progress.done}</Text>
              <Text style={[styles.pStatLabel, { color: T.textMuted }]}>Today</Text>
            </View>
            <View style={styles.pStat}>
              <Text style={[styles.pStatNum, { color: isPro ? COLORS.warning : T.textMuted }]}>
                {isPro ? 'PRO' : 'FREE'}
              </Text>
              <Text style={[styles.pStatLabel, { color: T.textMuted }]}>Plan</Text>
            </View>
          </View>
        </View>

        {/* Premium banner */}
        {!isPro && (
          <TouchableOpacity style={styles.premiumBanner} onPress={() => navigation.navigate('Premium')}>
            <View>
              <Text style={styles.premiumTitle}>✨ {t('upgrade')}</Text>
              <Text style={styles.premiumSub}>Unlimited habits + Stats + Widgets</Text>
            </View>
            <View style={styles.premiumBadge}>
              <Text style={{ color: COLORS.primary, fontWeight: '800', fontSize: FONT.sizes.sm }}>₹99/mo</Text>
            </View>
          </TouchableOpacity>
        )}

        {/* Settings sections */}
        <Text style={[styles.sectionLabel, { color: T.textMuted }]}>PREFERENCES</Text>
        <View style={[styles.section, { borderColor: T.border }]}>
          <SettingRow icon="🌐" label={t('language')} value={`${currentLang?.native} ${currentLang?.name}`} onPress={changeLanguage}/>
          <SettingRow icon="🌙" label={t('darkMode')}
            rightElement={<Switch value={darkMode} onValueChange={setDarkMode} trackColor={{ true: COLORS.primary }} thumbColor="#fff"/>}/>
          <SettingRow icon="🔔" label={t('notifications')}
            rightElement={<Switch value={notificationsEnabled} onValueChange={setNotifications} trackColor={{ true: COLORS.primary }} thumbColor="#fff"/>}/>
        </View>

        <Text style={[styles.sectionLabel, { color: T.textMuted }]}>SUPPORT</Text>
        <View style={[styles.section, { borderColor: T.border }]}>
          <SettingRow icon="⭐" label={t('rateApp')}   onPress={rateApp}/>
          <SettingRow icon="📤" label={t('shareApp')}  onPress={shareApp}/>
          <SettingRow icon="🔄" label={t('restorePurchase')} onPress={() => Alert.alert('Restore', 'Checking for purchases...')}/>
        </View>

        <Text style={[styles.sectionLabel, { color: T.textMuted }]}>ABOUT</Text>
        <View style={[styles.section, { borderColor: T.border }]}>
          <SettingRow icon="📱" label={t('version')} value="1.0.0"/>
          <SettingRow icon="🇮🇳" label="Made in India" value="Chennai"/>
          <SettingRow icon="💌" label="Contact" value="ddeva8560@gmail.com"/>
        </View>

        <Text style={{ color: T.textMuted, textAlign: 'center', fontSize: FONT.sizes.xs, marginTop: 24, marginBottom: 8 }}>
          StreakIn v1.0.0 • Made with ❤️ in Chennai, India 🇮🇳
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:     { flex: 1 },
  header:        { paddingHorizontal: 16, paddingTop: 60, paddingBottom: 16, borderBottomWidth: 1 },
  headerTitle:   { fontSize: FONT.sizes.xl, fontWeight: '800' },
  profileCard:   { margin: 16, padding: 20, borderRadius: 20, alignItems: 'center', backgroundColor: '#1e293b' },
  avatarRing:    { width: 72, height: 72, borderRadius: 36, backgroundColor: '#312e81', alignItems: 'center', justifyContent: 'center', marginBottom: 10, borderWidth: 3, borderColor: COLORS.primary + '60' },
  profileName:   { fontSize: FONT.sizes.lg, fontWeight: '700', marginBottom: 14 },
  profileStats:  { flexDirection: 'row', gap: 24 },
  pStat:         { alignItems: 'center' },
  pStatNum:      { fontSize: FONT.sizes.xxl, fontWeight: '800' },
  pStatLabel:    { fontSize: FONT.sizes.xs, marginTop: 2 },
  premiumBanner: { marginHorizontal: 16, marginBottom: 16, borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORS.primary + '15', borderWidth: 1, borderColor: COLORS.primary + '40' },
  premiumTitle:  { color: COLORS.primary, fontWeight: '700', fontSize: FONT.sizes.md, marginBottom: 2 },
  premiumSub:    { color: COLORS.accent, fontSize: FONT.sizes.sm },
  premiumBadge:  { backgroundColor: COLORS.primary + '20', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  sectionLabel:  { fontSize: FONT.sizes.xs, fontWeight: '700', letterSpacing: 0.5, marginLeft: 16, marginTop: 20, marginBottom: 6 },
  section:       { marginHorizontal: 16, borderRadius: 14, overflow: 'hidden', borderWidth: 1 },
  row:           { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 0.5 },
  rowLabel:      { flex: 1, fontSize: FONT.sizes.md, fontWeight: '500' },
  rowRight:      { flexDirection: 'row', alignItems: 'center', gap: 8 },
});

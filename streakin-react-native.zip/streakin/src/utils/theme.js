export const COLORS = {
  primary:  '#6366f1',
  primary2: '#4f46e5',
  accent:   '#a78bfa',
  success:  '#22c55e',
  warning:  '#f59e0b',
  danger:   '#ef4444',
  orange:   '#f97316',

  // Habit colors — vibrant for Indian taste
  habitColors: [
    '#6366f1', '#22c55e', '#f59e0b', '#ef4444',
    '#0ea5e9', '#ec4899', '#14b8a6', '#f97316',
    '#8b5cf6', '#84cc16', '#06b6d4', '#e879f9',
  ],
};

export const DARK_THEME = {
  bg:       '#0f172a',
  card:     '#1e293b',
  card2:    '#263347',
  border:   '#334155',
  text:     '#f1f5f9',
  textSub:  '#94a3b8',
  textMuted:'#64748b',
  icon:     '#94a3b8',
  tabBar:   '#1e293b',
  ...COLORS,
};

export const LIGHT_THEME = {
  bg:       '#f8fafc',
  card:     '#ffffff',
  card2:    '#f1f5f9',
  border:   '#e2e8f0',
  text:     '#0f172a',
  textSub:  '#475569',
  textMuted:'#94a3b8',
  icon:     '#64748b',
  tabBar:   '#ffffff',
  ...COLORS,
};

export const HABIT_EMOJIS = [
  '💧','🏃','📚','🧘','💪','🥗','😴','✍️',
  '🎯','🧹','💊','🚴','🎨','🎵','🌿','☀️',
  '🧠','💰','🙏','🫁','🥤','🥦','🛁','🌙',
  '📱','🎸','🏊','⚽','🧘','🫶','🌸','🏆',
];

export const FONT = {
  regular: 'System',
  medium:  'System',
  bold:    'System',
  sizes: {
    xs:   11, sm: 13, md: 15, lg: 17,
    xl:   20, xxl: 24, xxxl: 32, huge: 48,
  },
};

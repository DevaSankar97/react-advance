# 📱 StreakIn — Build Habits That Stick

> The habit tracker built for India. 5 languages. No annoying ads. No slow loading.

---

## 🎯 Why StreakIn Beats the Competition

| Feature | Tickit (1Cr+ downloads) | StreakIn |
|---------|------------------------|---------|
| Load speed | ❌ 5-10 seconds | ✅ Instant (offline first) |
| Ad interruptions | ❌ After every check-in | ✅ No ads on free |
| Habit reordering | ❌ Not available | ✅ Drag & drop (Pro) |
| Indian languages | ❌ English only | ✅ Tamil+Hindi+Telugu+Kannada+English |
| WhatsApp reminders | ❌ No | ✅ Coming soon |
| Made in India | ❌ Hong Kong | ✅ Chennai 🇮🇳 |

---

## ✨ Features

### Free (5 habits)
- ✅ Daily habit check-off with animations
- ✅ Streak tracking (current + best)
- ✅ 12 preset habits (water, exercise, meditation...)
- ✅ 5 Indian languages (EN/TA/HI/TE/KN)
- ✅ Weekly progress view
- ✅ Daily motivational quotes
- ✅ Works 100% offline
- ✅ No ads

### Pro (₹99/month or ₹699/year)
- 👑 Unlimited habits
- 👑 Detailed statistics + 28-day heatmap
- 👑 Drag-to-reorder habits
- 👑 Smart daily reminders
- 👑 Home screen widget
- 👑 All 5 Indian languages

---

## 🛠️ Tech Stack

| Layer | Tech |
|-------|------|
| Framework | React Native (Expo) |
| Navigation | React Navigation v6 |
| State | Zustand + AsyncStorage |
| i18n | i18next (5 languages) |
| Payments | RevenueCat |
| Animations | React Native Reanimated |
| Drag & Drop | react-native-draggable-flatlist |
| Notifications | Expo Notifications |

---

## 🚀 Getting Started

```bash
npm install
npx expo start

# iOS
npx expo start --ios

# Android
npx expo start --android
```

## 📦 Build for Stores

```bash
# Setup EAS first
npm install -g eas-cli
eas login
eas build:configure

# Build Android APK/AAB
eas build --platform android

# Build iOS IPA
eas build --platform ios

# Both
eas build --platform all
```

---

## 💰 Monetization Setup (RevenueCat)

1. Go to [revenuecat.com](https://revenuecat.com) — free account
2. Create project → Add Android + iOS app
3. Create "Pro" entitlement
4. Create offerings:
   - `monthly`: ₹99/month → product ID: `streakin_pro_monthly`
   - `yearly`:  ₹699/year → product ID: `streakin_pro_yearly`
5. Add RevenueCat API key in `src/screens/PremiumScreen.js`
6. Set up products in Google Play Console + App Store Connect

---

## 🌍 Languages

| Code | Language | Status |
|------|----------|--------|
| en   | English  | ✅ Complete |
| ta   | Tamil தமிழ் | ✅ Complete |
| hi   | Hindi हिंदी | ✅ Complete |
| te   | Telugu తెలుగు | ✅ Complete |
| kn   | Kannada ಕನ್ನಡ | ✅ Complete |

---

## 📁 Project Structure

```
streakin/
├── App.js                    ← Navigation setup
├── src/
│   ├── screens/
│   │   ├── HomeScreen.js     ← Today's habits
│   │   ├── HabitsScreen.js   ← Habits list + reorder
│   │   ├── StatsScreen.js    ← Analytics + heatmap
│   │   ├── ProfileScreen.js  ← Settings + language
│   │   ├── AddHabitScreen.js ← Add/edit with presets
│   │   └── PremiumScreen.js  ← Paywall
│   ├── context/
│   │   └── store.js          ← Zustand global state
│   ├── i18n/
│   │   └── index.js          ← 5 languages
│   └── utils/
│       └── theme.js          ← Colors + fonts
└── app.json                  ← Expo config
```

---

## 📊 Revenue Projection

| Paying Users | Monthly Revenue |
|-------------|----------------|
| 100 | ₹9,900 |
| 500 | ₹49,500 |
| 1,000 | ₹99,000 |
| 5,000 | ₹4,95,000 |
| 10,000 | ₹9,90,000 |

> At 4% conversion from 1 lakh downloads → 4,000 paid users = **₹3,96,000/month** 🔥

---

Made with ❤️ in Chennai, India 🇮🇳 by Deva Sankar

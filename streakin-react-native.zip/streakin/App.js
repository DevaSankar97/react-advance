import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator }     from '@react-navigation/stack';
import { GestureHandlerRootView }   from 'react-native-gesture-handler';
import { SafeAreaProvider }         from 'react-native-safe-area-context';
import { Text, View }               from 'react-native';
import * as SplashScreen            from 'expo-splash-screen';
import * as Notifications           from 'expo-notifications';
import { StatusBar }                from 'expo-status-bar';

// i18n — must import before screens
import './src/i18n';

import HomeScreen    from './src/screens/HomeScreen';
import HabitsScreen  from './src/screens/HabitsScreen';
import StatsScreen   from './src/screens/StatsScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import AddHabitScreen from './src/screens/AddHabitScreen';
import PremiumScreen from './src/screens/PremiumScreen';

import { DARK_THEME as T, FONT, COLORS } from './src/utils/theme';
import useStore from './src/context/store';

SplashScreen.preventAutoHideAsync();

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge:  false,
  }),
});

const Tab   = createBottomTabNavigator();
const Stack = createStackNavigator();

const TAB_ICONS = {
  Home:    { active: '🏠', inactive: '🏠' },
  Habits:  { active: '✅', inactive: '☑️'  },
  Stats:   { active: '📊', inactive: '📈' },
  Profile: { active: '👤', inactive: '👤' },
};

function TabLabel({ name, focused }) {
  const { getTodayProgress } = useStore();
  const progress = name === 'Home' ? getTodayProgress() : null;

  return (
    <View style={{ alignItems: 'center' }}>
      <Text style={{ fontSize: 22 }}>{focused ? TAB_ICONS[name].active : TAB_ICONS[name].inactive}</Text>
      {progress && progress.pct > 0 && progress.pct < 100 && (
        <View style={{
          position: 'absolute', top: -4, right: -8,
          width: 16, height: 16, borderRadius: 8,
          backgroundColor: COLORS.primary,
          alignItems: 'center', justifyContent: 'center',
        }}>
          <Text style={{ color: '#fff', fontSize: 8, fontWeight: '800' }}>{progress.pct}%</Text>
        </View>
      )}
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: T.tabBar,
          borderTopColor:  T.border,
          borderTopWidth:  1,
          height:          70,
          paddingBottom:   10,
        },
        tabBarLabel: ({ focused }) => (
          <Text style={{ color: focused ? COLORS.primary : T.textMuted, fontSize: FONT.sizes.xs, marginTop: 2, fontWeight: focused ? '700' : '400' }}>
            {route.name}
          </Text>
        ),
        tabBarIcon: ({ focused }) => <TabLabel name={route.name} focused={focused}/>,
        tabBarActiveTintColor:   COLORS.primary,
        tabBarInactiveTintColor: T.textMuted,
      })}
    >
      <Tab.Screen name="Home"    component={HomeScreen}/>
      <Tab.Screen name="Habits"  component={HabitsScreen}/>
      <Tab.Screen name="Stats"   component={StatsScreen}/>
      <Tab.Screen name="Profile" component={ProfileScreen}/>
    </Tab.Navigator>
  );
}

export default function App() {
  useEffect(() => {
    SplashScreen.hideAsync();
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light"/>
        <NavigationContainer theme={{
          dark:   true,
          colors: {
            primary:    COLORS.primary,
            background: T.bg,
            card:       T.card,
            text:       T.text,
            border:     T.border,
            notification: COLORS.danger,
          },
        }}>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Main"      component={MainTabs}/>
            <Stack.Screen name="AddHabit"  component={AddHabitScreen} options={{ presentation: 'modal' }}/>
            <Stack.Screen name="EditHabit" component={AddHabitScreen} options={{ presentation: 'modal' }}/>
            <Stack.Screen name="Premium"   component={PremiumScreen}  options={{ presentation: 'modal' }}/>
          </Stack.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
